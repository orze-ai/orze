
import os,sys
if 'orze.cli' in getattr(sys,'orig_argv',()):
    from orze import extensions
    def forbidden(*a,**k):
        raise AssertionError('CPU controller touched GPU/provider/legacy boundary')
    extensions.has_pro=forbidden
    extensions._find_pro_key=forbidden
    try:
        from orze_pro import _gate
        _gate.require_license=lambda:None
    except ImportError:pass
    from orze.hardware import gpu
    gpu.detect_all_gpus=forbidden
    from orze.core import gpu_lease
    gpu_lease.acquire_gpu_leases=forbidden
    gpu_lease.assert_gpu_scope_idle=forbidden
    from orze import lifecycle
    lifecycle.do_stop=forbidden
    if os.environ.get('CPU_STOP_FAULT')=='unsettled':
        from orze.core import cpu_action_budget
        cpu_action_budget.settle=lambda *a,**k:'settled'
    if os.environ.get('CPU_STOP_FAULT')=='orphan_reservation':
        from orze.engine import cpu_phase
        from orze.core import cpu_action_budget
        actual_start=cpu_phase.start
        def start(engine):
            actual_start(engine)
            cpu_action_budget.reserve(engine.lake,engine._cpu_scope,'orphan-0001',1)
        cpu_phase.start=start
    if os.environ.get('CPU_STOP_FAULT')=='close_response_lost':
        from orze.idea_lake import IdeaLake
        actual_close=IdeaLake.close
        def close(self):
            actual_close(self)
            raise OSError('fixture: Lake close response lost')
        IdeaLake.close=close
