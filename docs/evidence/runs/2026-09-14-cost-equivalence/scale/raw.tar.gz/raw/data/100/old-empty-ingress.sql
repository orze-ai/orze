SELECT idea_id FROM ideas
