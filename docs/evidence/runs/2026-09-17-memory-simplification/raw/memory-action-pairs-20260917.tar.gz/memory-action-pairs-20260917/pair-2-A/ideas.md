# Ideas




## idea-52fc63: Extend long job window to deadline 9, start at 3: prepare + gate + long + finish
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-diagnostic-1-1
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-diagnostic-1-1 shows a feasible schedule with value 23 (prepare, gate, long, early, finish). The long job (duration 5, value 11) fits within its deadline 9 when started at tick 3. By removing early (value 7, deadline 6) and instead scheduling long alone after gate, we preserve feasibility while testing whether the tight deadline on early is the binding constraint. This isolates long's contribution and avoids the capacity overload seen in idea-evaluate-diagnostic-1-0.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


