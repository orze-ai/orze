# Ideas


## idea-52fc63: Schedule long job with reduced optional set
- **Priority**: high
- **Category**: job_selection
- **Approach Family**: other
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-seed-valid achieved feasible value 14 with prepare, gate, finish only. Adding long (value 11, duration 5) is valuable but requires careful timing. Schedule prepare(0), gate(2), long(3), finish(9) respects long's 5-unit duration window [3,9) and achieves minimum value 1+1+11+1=14; if feasible, this is a bridge toward higher value than seed-valid.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

