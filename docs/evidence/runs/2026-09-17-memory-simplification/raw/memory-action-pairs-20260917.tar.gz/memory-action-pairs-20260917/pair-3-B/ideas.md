# Ideas


## idea-52fc63: Attempt long job instead of early and middle to maximize single high-value optional
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-seed-valid
- **Research Cycle**: 1
- **Hypothesis**: The valid seed schedules prepare, gate, and finish. Instead of packing early+middle (combined value 15), try long (value 11, duration 5, deadline 9) alone. Long must start by tick 4 to finish by deadline 9. Schedule long at tick 3 (finishes at tick 8), then finish at tick 9. This respects all constraints and avoids the overload that failed idea-seed-overload. Total value: 1+1+11+1=14 (equal to baseline but tests feasibility of the long path).
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

