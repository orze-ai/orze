# Ideas


## idea-52fc63: Greedy high-value schedule avoiding early overcommit
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 1
- **Hypothesis**: idea-evaluate-seed-valid achieved score 14 by scheduling prepare→gate→finish (mandatory chain, total value 3). The valid candidate omitted all optional jobs. Long (value 11, duration 5, deadline 12) conflicts with finish window but could fit if early and middle are skipped. Test scheduling prepare(0-2), gate(2-3), long(3-8), finish(9-10) to capture the high-value optional without overloading capacity.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




