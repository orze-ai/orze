# Ideas


## idea-52fc63: Schedule long job at start of window, front-load high-value work
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: optimization
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 2
- **Hypothesis**: The overload candidate failed due to capacity constraints. The valid candidate (score 14) scheduled prepare→gate→finish with optional jobs in gaps. By starting 'long' (value 11, duration 5) immediately after gate completes at tick 3, and before early/middle/late, we maximize value within the capacity=1 constraint. Long ends at tick 8, within deadline 9. This front-loads the highest-value optional job and respects all dependencies.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


