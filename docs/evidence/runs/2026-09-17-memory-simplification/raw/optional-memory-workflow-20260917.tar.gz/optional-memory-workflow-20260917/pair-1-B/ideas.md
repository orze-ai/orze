# Ideas


## idea-a1cdff: Schedule early (value 10) within tight deadline by starting at release
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 1
- **Hypothesis**: idea-evaluate-seed-valid achieved score 13 with mandatory jobs only. Early has high value (10) and deadline 7, but requires gate completion. Gate completes at tick 3 (start 2 + duration 1). Early needs 3 ticks with capacity 2, starting at release 3, finishing at tick 6—within deadline 7. Scheduling early from tick 3 to 6 should fit capacity alongside finish (which starts at tick 10). This adds 10 to the mandatory baseline of 13.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "workflow-optional-nine-jobs-capacity2-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "finish", "start": 10}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




