You are solving a finite scheduling research task, not training a neural network.
Maximize the sum of values of scheduled jobs while respecting all mandatory jobs, release/deadline windows,
job durations, prerequisite inclusion and finish-before-start dependencies, and capacity at each integer tick.
Use the actual evaluation history to revise hypotheses and avoid repeating an already invalid schedule.
Each round requests two distinct candidate schedules. Propose your own complete schedules, not built-in generators.
If all useful distinct candidates are exhausted, returning an empty batch is allowed and remains in the experiment.
Both arms have the same ordinary history access. Use only the interfaces actually offered in the prompt.
Persistent notes, when offered, are optional: do not manufacture evidence or write merely to satisfy this experiment.

Submit the usual JSON array of ideas with title, hypothesis, parent, and config. Use parent "none" for an independent
candidate, or an eligible ID from the supplied evidence when following up. The config must have exactly two keys:
"kind": "native_cpu_action" and "domain_request": the object below. Keep the fixed envelope fields unchanged.
Replace payload.artifact_utf8 with a JSON-encoded STRING containing your complete candidate:
{"instance_id": "the actual instance ID", "schedule": [{"job_id": "an actual job ID", "start": 0}, ...]}.
Use integer starts. Omit unselected optional jobs. Always include artifact_utf8; the "baseline" label is only
an envelope field and must not select a canned solution. Do not compute or invent an authoritative score.
The independent evaluator will compute feasibility and value from your exact candidate bytes.

DOMAIN_REQUEST_SHAPE:
{"input_artifact_ids": [], "inputs": {}, "outputs": {"candidate": {"max_bytes": 16384, "path": "candidate.json"}}, "payload": {"artifact_utf8": "REPLACE_WITH_JSON_STRING", "candidate": "baseline", "operation": "produce"}, "purpose": "produce scheduling candidate", "timeout_seconds": 2, "version": 1}

INSTANCE:
{"capacity": 1, "horizon": 14, "instance_id": "workflow-optional-nine-jobs-capacity1-v1", "jobs": [{"after": [], "deadline": 2, "demand": 1, "duration": 2, "id": "prepare", "release": 0, "required": true, "value": 1}, {"after": ["prepare"], "deadline": 4, "demand": 1, "duration": 1, "id": "gate", "release": 2, "required": true, "value": 1}, {"after": ["gate"], "deadline": 14, "demand": 1, "duration": 1, "id": "finish", "release": 12, "required": true, "value": 1}, {"after": ["gate"], "deadline": 11, "demand": 1, "duration": 6, "id": "long", "release": 3, "required": false, "value": 13}, {"after": ["gate"], "deadline": 6, "demand": 1, "duration": 2, "id": "early", "release": 3, "required": false, "value": 7}, {"after": ["gate"], "deadline": 10, "demand": 1, "duration": 3, "id": "middle", "release": 5, "required": false, "value": 10}, {"after": ["gate"], "deadline": 13, "demand": 1, "duration": 3, "id": "late", "release": 8, "required": false, "value": 11}, {"after": ["gate"], "deadline": 9, "demand": 1, "duration": 1, "id": "short", "release": 4, "required": false, "value": 4}, {"after": ["gate"], "deadline": 14, "demand": 1, "duration": 2, "id": "tail", "release": 10, "required": false, "value": 8}]}

Follow the genealogy contract using exact eligible IDs. Emit bare JSON without surrounding prose.
Keep domain_request.payload.candidate exactly "baseline"; this is a fixed interface field, not a strategy name.
