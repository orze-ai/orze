# Ideas


## idea-251797: Schedule long job within deadline
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-seed-valid
- **Research Cycle**: 1
- **Hypothesis**: The overload attempt (idea-seed-overload) failed due to capacity violation when 'early' was scheduled at t=4. The valid baseline (idea-seed-valid) omitted 'long' (value 13) to fit remaining optional jobs. Scheduling 'long' at t=3 (its release) through t=9 respects its deadline of 11, precedes 'finish' at t=12, and preserves capacity. This prioritizes the highest-value optional job while maintaining feasibility.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "workflow-optional-nine-jobs-capacity1-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 12}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




