# Ideas




## idea-ee11c9: Schedule early and middle jobs, skip long and late
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-diagnostic-1-1
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-diagnostic-1-1 achieved value 27 by scheduling early (2 ticks, value 7) and middle (2 ticks, value 8) after gate, both fitting within their deadlines (6 and 9 respectively). This proposal extends that pattern by adding late (2 ticks, value 9) which has release=7 and deadline=11, fitting after middle without violating capacity or windows.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-52fc63: Schedule long job alone with mandatory tasks, skip optional jobs
- **Priority**: medium
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-seed-valid achieved value 14 by scheduling only the three mandatory jobs (prepare, gate, finish) plus long (5 ticks, value 11) within its deadline=9. Long requires release=3 and 5 ticks; starting at tick 3 completes at tick 7 (before deadline 9). This avoids all optional job conflicts and respects capacity=1 throughout.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

