# Ideas




## idea-52fc63: Schedule long job with no optional overlap to test value trade-off
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-seed-valid
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-seed-valid achieved score=14 with only mandatory jobs (prepare, gate, finish). idea-evaluate-diagnostic-1-1 achieved score=18 by including early and middle. To test whether long (value=11) can beat early+middle (value=15) without overlapping, schedule prepare@0, gate@2, long@3, finish@9, omitting all other optional jobs. long occupies ticks 3-7, finish starts at 9, respecting all constraints. Total value = 1+1+11+1 = 14. If feasible, this isolates long's contribution; if infeasible, capacity constraint at finish time window must be the blocker.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

