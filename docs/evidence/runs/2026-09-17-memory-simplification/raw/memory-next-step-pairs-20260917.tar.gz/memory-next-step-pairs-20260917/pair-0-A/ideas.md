# Ideas


## idea-52fc63: Schedule long job earliest, exclude early job
- **Priority**: high
- **Category**: constraint-repair
- **Approach Family**: data
- **Parent**: idea-seed-overload
- **Research Cycle**: 1
- **Hypothesis**: The overload counterexample (idea-evaluate-seed-overload) failed because long (duration 5, starts at 3) and early (duration 2, starts at 4) overlap at ticks 4–5, violating capacity=1. Moving long to start at 3 and excluding early avoids this conflict entirely. The valid seed (idea-seed-valid) achieved score 14 by scheduling prepare→gate→finish with value 1+1+1=3. Adding long (value 11) without early should yield 14, matching or exceeding the valid baseline.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




