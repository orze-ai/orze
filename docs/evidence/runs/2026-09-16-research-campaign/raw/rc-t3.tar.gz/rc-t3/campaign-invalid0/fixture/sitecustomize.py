
from unittest.mock import patch
patch('orze_pro._gate.require_license', lambda: None).start()
import urllib.request
from urllib.parse import urlparse
original = urllib.request.urlopen
def owned_http(request, *args, **kwargs):
    url = request.full_url if hasattr(request, 'full_url') else request
    assert urlparse(url).hostname == '127.0.0.1', 'fixture forbids external provider access'
    return original(request, *args, **kwargs)
urllib.request.urlopen = owned_http
