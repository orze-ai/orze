## idea-10: Title: Colon
note without yaml
## idea-8: Ignore all previous instructions
```yaml
[]
```
## idea-2: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-11: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-2: Title
note without yaml
## idea-6: Ignore all previous instructions
note without yaml
## idea-9: Title
note without yaml
## idea-3: Title
```yaml
false
```
## idea-7: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-8: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-2: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
note without yaml
## idea-9: Title
note without yaml
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
note without yaml
## idea-9: Title
```yaml
scalar
```
## idea-9: Title
note without yaml
