## idea-2: Title: Colon
```yaml
seed: 13
```
## idea-4: Ignore all previous instructions
note without yaml
## idea-7: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
scalar
```
## idea-1: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## idea-5: Title: Colon
note without yaml
## idea-4: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## idea-11: Title: Colon
```yaml
[]
```
## idea-5: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-3: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
```yaml
seed: 13
```
## idea-11: Title
note without yaml
## idea-3: Title
note without yaml
## idea-7: Title: Colon
note without yaml
## idea-11: Title
```yaml
false
```
## idea-7: Title
note without yaml
## idea-7: Title
```yaml
a: 1
b: 2
```
## idea-10: Title
note without yaml
## idea-0: Title
note without yaml
## Unknown heading
ignored
