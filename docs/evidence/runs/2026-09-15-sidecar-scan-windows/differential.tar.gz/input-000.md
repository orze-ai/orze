## idea-2: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## idea-0: Title: Colon
note without yaml
## idea-9: Title
note without yaml
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Title
note without yaml
## idea-3: Ignore all previous instructions
```yaml
[]
```
## idea-3: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-5: Title: Colon
```yaml
seed: [
```
## idea-4: Title
note without yaml
## idea-11: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## idea-4: Title
note without yaml
## idea-10: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: [
```
## idea-11: Title
note without yaml
## idea-3: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Title
note without yaml
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
