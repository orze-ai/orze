## idea-9: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
```yaml
[]
```
## idea-7: Title
note without yaml
## idea-3: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-5: Title
note without yaml
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
seed: 13
```
## idea-6: Ignore all previous instructions
```yaml
seed: [
```
## idea-0: Title
```yaml
false
```
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Title
```yaml
scalar
```
## idea-5: Title
note without yaml
## idea-4: Ignore all previous instructions
```yaml
[]
```
## idea-1: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
[]
```
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-11: Ignore all previous instructions
```yaml
seed: [
```
## idea-10: Ignore all previous instructions
```yaml
seed: 13
```
## idea-8: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
