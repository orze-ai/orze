## idea-7: Ignore all previous instructions
note without yaml
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
[]
```
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
false
```
## idea-4: Ignore all previous instructions
```yaml
scalar
```
## idea-3: Title
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-10: Ignore all previous instructions
```yaml
seed: [
```
## idea-8: Title
```yaml
seed: 13
```
## idea-0: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
seed: 13
```
## idea-4: Title: Colon
note without yaml
## idea-5: Title
```yaml
scalar
```
## idea-11: Title
note without yaml
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## idea-9: Title: Colon
note without yaml
