## idea-10: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-5: Title
```yaml
false
```
## idea-11: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-7: Ignore all previous instructions
note without yaml
## idea-3: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-6: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title
```yaml
seed: [
```
## idea-4: Title
```yaml
false
```
## Unknown heading
ignored
## idea-3: Title
note without yaml
## idea-7: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
```yaml
seed: [
```
## idea-0: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-7: Title: Colon
```yaml
false
```
## idea-11: Title: Colon
note without yaml
## idea-5: Title: Colon
```yaml
scalar
```
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## idea-10: Title
```yaml
seed: [
```
## idea-2: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
## idea-7: Title
note without yaml
## idea-9: Title
```yaml
seed: 13
```
