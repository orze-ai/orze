## idea-0: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
## idea-1: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-8: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## idea-0: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-4: Title: Colon
```yaml
[]
```
## idea-2: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-6: Title: Colon
```yaml
scalar
```
## idea-4: Title: Colon
note without yaml
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-11: Title
```yaml
false
```
## Unknown heading
ignored
## idea-3: Title
note without yaml
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## idea-0: Title: Colon
note without yaml
## idea-10: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
