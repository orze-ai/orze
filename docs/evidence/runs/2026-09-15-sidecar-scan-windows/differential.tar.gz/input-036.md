## idea-2: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Title
```yaml
seed: 13
```
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
false
```
## idea-0: Title
note without yaml
## idea-5: Title
note without yaml
## idea-2: Title: Colon
note without yaml
## idea-0: Title
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
[]
```
## idea-5: Title
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-9: Title: Colon
```yaml
scalar
```
## idea-3: Title
note without yaml
## idea-8: Title: Colon
note without yaml
## idea-8: Ignore all previous instructions
```yaml
[]
```
## idea-6: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
seed: [
```
## idea-8: Title: Colon
```yaml
scalar
```
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-1: Title
```yaml
scalar
```
## idea-6: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
a: 1
b: 2
```
