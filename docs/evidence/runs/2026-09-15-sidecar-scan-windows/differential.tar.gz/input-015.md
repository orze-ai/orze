## idea-8: Title
```yaml
a: 1
b: 2
```
## idea-4: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
false
```
## idea-9: Title
```yaml
seed: 13
```
## idea-11: Title: Colon
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Title
```yaml
false
```
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
scalar
```
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-11: Title
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
seed: [
```
## idea-8: Title: Colon
```yaml
false
```
## idea-9: Ignore all previous instructions
note without yaml
## idea-8: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
```yaml
seed: [
```
## idea-3: Ignore all previous instructions
note without yaml
## idea-7: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
