## idea-7: Title
```yaml
seed: 13
```
## idea-3: Title
note without yaml
## idea-10: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-4: Title
note without yaml
## idea-4: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-1: Title
note without yaml
## idea-0: Title
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
[]
```
## idea-1: Ignore all previous instructions
```yaml
[]
```
## idea-3: Title
```yaml
[]
```
## idea-3: Title
note without yaml
## idea-8: Title: Colon
```yaml
scalar
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-6: Title
```yaml
false
```
## idea-1: Title
note without yaml
## idea-8: Title: Colon
```yaml
seed: 13
```
## idea-3: Title
```yaml
scalar
```
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
note without yaml
## idea-8: Title
```yaml
scalar
```
## idea-6: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
note without yaml
## idea-6: Title: Colon
note without yaml
