## idea-6: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Title
```yaml
a: 1
b: 2
```
## idea-7: Ignore all previous instructions
```yaml
seed: 13
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-8: Title
```yaml
false
```
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
## idea-2: Title
note without yaml
## idea-10: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-5: Title: Colon
note without yaml
## idea-3: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-2: Title
```yaml
seed: [
```
## idea-7: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
scalar
```
## idea-8: Title
note without yaml
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-1: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## idea-5: Title
```yaml
seed: [
```
## idea-3: Title: Colon
```yaml
seed: [
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-1: Title
```yaml
a: 1
b: 2
```
