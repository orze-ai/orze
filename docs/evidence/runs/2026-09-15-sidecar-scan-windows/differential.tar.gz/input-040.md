## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-6: Title
```yaml
false
```
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
seed: [
```
## idea-8: Title: Colon
```yaml
a: 1
b: 2
```
## idea-7: Title: Colon
note without yaml
## idea-10: Title: Colon
note without yaml
## idea-9: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-1: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title
```yaml
[]
```
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Title
note without yaml
## Unknown heading
ignored
## idea-0: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
false
```
## idea-7: Title
```yaml
[]
```
## idea-2: Title
note without yaml
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
