## idea-8: Title: Colon
note without yaml
## idea-1: Title: Colon
note without yaml
## idea-5: Title
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## idea-11: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
seed: [
```
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-2: Title
```yaml
scalar
```
## idea-11: Title
note without yaml
## idea-6: Title
note without yaml
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
```yaml
[]
```
## idea-8: Title
```yaml
scalar
```
## idea-2: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-6: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-6: Title
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-9: Title
```yaml
seed: 13
```
