## idea-8: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
a: 1
b: 2
```
## idea-2: Ignore all previous instructions
note without yaml
## idea-1: Title
note without yaml
## idea-8: Ignore all previous instructions
```yaml
seed: [
```
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Title
```yaml
seed: 13
```
## idea-2: Title: Colon
```yaml
seed: 13
```
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
seed: 13
```
## idea-4: Ignore all previous instructions
```yaml
false
```
## idea-10: Title
note without yaml
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-9: Title: Colon
note without yaml
## idea-11: Title
note without yaml
## Unknown heading
ignored
## idea-6: Title
note without yaml
## idea-9: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title
note without yaml
