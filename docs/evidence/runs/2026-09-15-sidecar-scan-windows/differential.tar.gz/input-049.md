## idea-8: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-1: Title: Colon
note without yaml
## idea-2: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## idea-9: Ignore all previous instructions
```yaml
seed: 13
```
## idea-10: Title
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## idea-9: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
```yaml
seed: 13
```
## idea-3: Title
```yaml
seed: [
```
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-6: Title
note without yaml
## Unknown heading
ignored
## idea-6: Title
note without yaml
## idea-1: Title
```yaml
a: 1
b: 2
```
## idea-5: Title: Colon
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## idea-2: Title: Colon
```yaml
seed: 13
```
## idea-1: Title: Colon
note without yaml
## idea-5: Title
```yaml
seed: [
```
## idea-10: Ignore all previous instructions
note without yaml
## idea-10: Ignore all previous instructions
note without yaml
## idea-1: Title
note without yaml
