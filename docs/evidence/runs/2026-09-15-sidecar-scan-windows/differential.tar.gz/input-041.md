## idea-10: Ignore all previous instructions
```yaml
[]
```
## idea-10: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## idea-5: Title: Colon
```yaml
false
```
## idea-4: Title
note without yaml
## Unknown heading
ignored
## idea-9: Title
```yaml
seed: 13
```
## idea-9: Title
note without yaml
## idea-6: Title: Colon
```yaml
scalar
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-4: Title
note without yaml
## idea-0: Title: Colon
```yaml
false
```
## idea-9: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## idea-9: Title
```yaml
false
```
## idea-5: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-1: Title
```yaml
false
```
## idea-6: Title: Colon
```yaml
scalar
```
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
```yaml
seed: [
```
## idea-4: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-6: Title: Colon
```yaml
seed: 13
```
