## idea-10: Title: Colon
note without yaml
## idea-1: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## idea-2: Title: Colon
note without yaml
## idea-8: Title
note without yaml
## idea-11: Title
```yaml
false
```
## idea-10: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-9: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
false
```
## idea-2: Title
note without yaml
## idea-2: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
```yaml
seed: [
```
## idea-11: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
note without yaml
## idea-3: Ignore all previous instructions
```yaml
false
```
## idea-2: Title: Colon
```yaml
scalar
```
