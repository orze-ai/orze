## idea-5: Title: Colon
```yaml
false
```
## idea-10: Title: Colon
```yaml
scalar
```
## idea-5: Title
```yaml
scalar
```
## idea-3: Title: Colon
note without yaml
## idea-1: Title
```yaml
seed: 13
```
## idea-3: Title: Colon
note without yaml
## idea-3: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
note without yaml
## idea-1: Title
note without yaml
## idea-11: Title
note without yaml
## idea-11: Ignore all previous instructions
```yaml
seed: 13
```
## idea-5: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-10: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Title
```yaml
a: 1
b: 2
```
## idea-11: Title
```yaml
a: 1
b: 2
```
## idea-4: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## idea-11: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-1: Title
note without yaml
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
```yaml
seed: 13
```
