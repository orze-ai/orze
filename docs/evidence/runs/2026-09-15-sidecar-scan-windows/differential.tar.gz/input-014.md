## idea-3: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
```yaml
false
```
## idea-4: Title
```yaml
false
```
## Unknown heading
ignored
## idea-4: Title
```yaml
a: 1
b: 2
```
## idea-8: Title
note without yaml
## idea-0: Title
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## idea-7: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Title
```yaml
false
```
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## idea-6: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-6: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
scalar
```
## idea-7: Title: Colon
```yaml
[]
```
## idea-11: Title
```yaml
seed: [
```
## idea-2: Title
```yaml
false
```
## idea-9: Title
note without yaml
## idea-6: Title
```yaml
seed: 13
```
## Unknown heading
ignored
