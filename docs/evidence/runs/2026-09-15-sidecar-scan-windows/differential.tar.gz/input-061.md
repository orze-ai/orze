## idea-5: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
```yaml
false
```
## idea-3: Title: Colon
note without yaml
## idea-10: Title: Colon
```yaml
false
```
## idea-0: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-0: Title: Colon
```yaml
scalar
```
## idea-3: Title
```yaml
a: 1
b: 2
```
## idea-11: Title: Colon
```yaml
seed: 13
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
```yaml
false
```
## idea-8: Title: Colon
```yaml
a: 1
b: 2
```
## idea-0: Title
```yaml
seed: 13
```
## idea-11: Title: Colon
```yaml
a: 1
b: 2
```
## idea-4: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-11: Title: Colon
```yaml
seed: [
```
## idea-10: Ignore all previous instructions
note without yaml
## idea-9: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-3: Ignore all previous instructions
note without yaml
## idea-0: Title
note without yaml
## idea-6: Title: Colon
```yaml
false
```
## idea-0: Title: Colon
```yaml
seed: 13
```
## idea-6: Title: Colon
note without yaml
