## idea-3: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-7: Title
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-7: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-5: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
[]
```
## idea-9: Title: Colon
note without yaml
## idea-9: Title
note without yaml
## idea-11: Title
note without yaml
## idea-2: Title
```yaml
[]
```
## idea-8: Title: Colon
note without yaml
## idea-5: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-8: Title
```yaml
[]
```
## idea-5: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-11: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
```yaml
false
```
## idea-7: Ignore all previous instructions
note without yaml
