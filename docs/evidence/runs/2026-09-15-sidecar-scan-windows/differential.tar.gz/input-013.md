## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Title
```yaml
scalar
```
## idea-8: Title
```yaml
seed: 13
```
## idea-5: Title
note without yaml
## idea-6: Title
note without yaml
## idea-2: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
false
```
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
seed: [
```
## idea-10: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-9: Ignore all previous instructions
```yaml
scalar
```
## idea-8: Title
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-11: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## idea-8: Title
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
note without yaml
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## idea-1: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-5: Title
```yaml
seed: [
```
## idea-9: Title
```yaml
[]
```
