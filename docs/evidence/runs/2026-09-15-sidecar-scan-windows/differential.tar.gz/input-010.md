## idea-1: Title
```yaml
scalar
```
## idea-6: Title
note without yaml
## idea-1: Title
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## idea-5: Title: Colon
```yaml
scalar
```
## idea-8: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## idea-11: Title: Colon
note without yaml
## idea-2: Ignore all previous instructions
```yaml
[]
```
## idea-3: Title
```yaml
scalar
```
## idea-8: Title
```yaml
false
```
## idea-5: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-8: Title
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-0: Title
note without yaml
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
[]
```
## idea-7: Title: Colon
note without yaml
## idea-10: Title: Colon
```yaml
a: 1
b: 2
```
## idea-1: Ignore all previous instructions
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
