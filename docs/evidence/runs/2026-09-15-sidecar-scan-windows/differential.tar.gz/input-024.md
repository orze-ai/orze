## idea-1: Title
note without yaml
## idea-1: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
scalar
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-1: Title
note without yaml
## idea-4: Title
```yaml
[]
```
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
note without yaml
## idea-9: Title
```yaml
false
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-11: Title
```yaml
[]
```
## idea-3: Ignore all previous instructions
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
note without yaml
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-6: Title
note without yaml
## idea-4: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-5: Title
note without yaml
## idea-7: Title: Colon
note without yaml
## idea-3: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
