## idea-5: Title: Colon
note without yaml
## idea-6: Ignore all previous instructions
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## idea-11: Title
```yaml
[]
```
## idea-1: Ignore all previous instructions
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-4: Title
```yaml
seed: 13
```
## idea-3: Ignore all previous instructions
```yaml
scalar
```
## idea-9: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-11: Title
```yaml
false
```
## idea-11: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
note without yaml
## idea-5: Title
note without yaml
## idea-5: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Title
note without yaml
## idea-5: Title
note without yaml
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## idea-9: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-11: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
