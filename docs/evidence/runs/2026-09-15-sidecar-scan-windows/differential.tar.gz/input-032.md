## idea-3: Title: Colon
```yaml
seed: [
```
## idea-1: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
[]
```
## idea-9: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
```yaml
seed: [
```
## idea-5: Ignore all previous instructions
```yaml
false
```
## idea-11: Title
```yaml
false
```
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## idea-2: Title
```yaml
seed: [
```
## idea-9: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-7: Title: Colon
note without yaml
## idea-8: Title
```yaml
seed: 13
```
## idea-0: Title
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## idea-5: Title
```yaml
false
```
## idea-0: Title: Colon
```yaml
seed: 13
```
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## idea-10: Title
note without yaml
