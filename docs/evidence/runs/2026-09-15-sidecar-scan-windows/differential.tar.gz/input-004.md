## idea-10: Title: Colon
```yaml
scalar
```
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title
note without yaml
## idea-1: Title
note without yaml
## idea-0: Ignore all previous instructions
note without yaml
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-10: Title
note without yaml
## idea-2: Title
```yaml
scalar
```
## idea-7: Ignore all previous instructions
```yaml
[]
```
## idea-6: Title
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## idea-4: Title
note without yaml
## idea-5: Title
```yaml
false
```
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-1: Title
```yaml
false
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Title
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
```yaml
[]
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-8: Title: Colon
```yaml
[]
```
## idea-8: Title: Colon
note without yaml
## idea-7: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
