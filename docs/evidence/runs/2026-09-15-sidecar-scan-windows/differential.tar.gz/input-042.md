## idea-7: Title
```yaml
[]
```
## idea-6: Title: Colon
note without yaml
## idea-10: Title
```yaml
false
```
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-5: Title: Colon
```yaml
seed: [
```
## idea-8: Title
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
a: 1
b: 2
```
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-2: Title: Colon
```yaml
seed: [
```
## idea-2: Ignore all previous instructions
```yaml
seed: [
```
## idea-9: Title: Colon
```yaml
a: 1
b: 2
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## idea-4: Ignore all previous instructions
```yaml
[]
```
## idea-7: Title: Colon
```yaml
[]
```
## idea-8: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-0: Title
```yaml
false
```
## idea-9: Ignore all previous instructions
```yaml
seed: [
```
## idea-1: Title
note without yaml
## idea-9: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-10: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
