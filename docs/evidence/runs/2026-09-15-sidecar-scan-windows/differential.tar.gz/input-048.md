## idea-8: Ignore all previous instructions
note without yaml
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## idea-2: Title: Colon
```yaml
scalar
```
## idea-10: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-2: Title
note without yaml
## idea-2: Title: Colon
```yaml
scalar
```
## idea-11: Ignore all previous instructions
```yaml
seed: [
```
## idea-0: Title
```yaml
false
```
## Unknown heading
ignored
## idea-2: Title
note without yaml
## idea-6: Title
```yaml
false
```
## idea-4: Title: Colon
```yaml
seed: 13
```
## idea-2: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## idea-1: Title: Colon
```yaml
seed: 13
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
```yaml
seed: 13
```
## idea-2: Ignore all previous instructions
note without yaml
## idea-3: Title: Colon
note without yaml
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
scalar
```
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
