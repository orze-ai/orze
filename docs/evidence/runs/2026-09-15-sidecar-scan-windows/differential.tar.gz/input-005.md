## idea-9: Ignore all previous instructions
note without yaml
## idea-2: Title
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## idea-6: Title
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-10: Title
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title
note without yaml
## idea-1: Title
```yaml
seed: [
```
## idea-8: Title: Colon
```yaml
[]
```
## idea-0: Title
```yaml
a: 1
b: 2
```
## idea-3: Title
note without yaml
## idea-3: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-0: Title: Colon
```yaml
seed: 13
```
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
seed: 13
```
## idea-3: Ignore all previous instructions
```yaml
false
```
## idea-8: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-1: Title: Colon
note without yaml
## idea-8: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-4: Title
note without yaml
