## idea-6: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
```yaml
[]
```
## idea-9: Title
note without yaml
## idea-7: Title: Colon
```yaml
a: 1
b: 2
```
## idea-11: Title: Colon
note without yaml
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-0: Ignore all previous instructions
note without yaml
## idea-8: Title
```yaml
false
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
```yaml
false
```
## idea-7: Ignore all previous instructions
note without yaml
## idea-7: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-0: Title: Colon
note without yaml
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-11: Title
note without yaml
## Unknown heading
ignored
## idea-10: Title
```yaml
false
```
## idea-11: Title
```yaml
false
```
## idea-4: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Title
```yaml
false
```
## Unknown heading
ignored
## idea-10: Title: Colon
```yaml
a: 1
b: 2
```
