## idea-11: Title
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
note without yaml
## idea-9: Ignore all previous instructions
note without yaml
## idea-0: Title: Colon
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-2: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Title: Colon
```yaml
seed: [
```
## idea-10: Title: Colon
```yaml
scalar
```
## idea-7: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-11: Title: Colon
note without yaml
## idea-5: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
scalar
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
```yaml
a: 1
b: 2
```
## idea-6: Title: Colon
```yaml
[]
```
## idea-9: Title: Colon
```yaml
false
```
