## idea-8: Title
note without yaml
## idea-2: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-2: Ignore all previous instructions
```yaml
seed: 13
```
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title
```yaml
false
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-11: Title
```yaml
false
```
## idea-2: Title: Colon
```yaml
[]
```
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-0: Ignore all previous instructions
```yaml
[]
```
## idea-2: Title: Colon
```yaml
seed: [
```
## idea-3: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
note without yaml
## idea-5: Title
note without yaml
## idea-4: Title: Colon
```yaml
seed: [
```
## idea-1: Title
```yaml
seed: [
```
