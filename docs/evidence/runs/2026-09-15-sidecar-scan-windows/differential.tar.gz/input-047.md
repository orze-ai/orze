## idea-4: Title: Colon
```yaml
scalar
```
## idea-2: Ignore all previous instructions
```yaml
[]
```
## idea-10: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
seed: [
```
## idea-1: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-11: Title: Colon
```yaml
[]
```
## idea-0: Title
```yaml
scalar
```
## idea-8: Ignore all previous instructions
```yaml
seed: [
```
## idea-0: Ignore all previous instructions
```yaml
scalar
```
## idea-1: Title
note without yaml
## idea-7: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-0: Ignore all previous instructions
```yaml
[]
```
## idea-3: Title
```yaml
false
```
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-0: Title
```yaml
[]
```
## idea-3: Title
```yaml
seed: 13
```
## idea-7: Title
```yaml
seed: [
```
## idea-1: Title: Colon
note without yaml
## idea-1: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-7: Title
note without yaml
