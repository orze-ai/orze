## idea-5: Ignore all previous instructions
note without yaml
## idea-2: Title
note without yaml
## idea-6: Title
```yaml
false
```
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
scalar
```
## idea-11: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-1: Ignore all previous instructions
```yaml
scalar
```
## idea-7: Ignore all previous instructions
```yaml
[]
```
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
```yaml
[]
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-6: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-0: Title
```yaml
a: 1
b: 2
```
## idea-0: Title
note without yaml
## idea-3: Title: Colon
```yaml
[]
```
## idea-0: Title: Colon
note without yaml
## idea-8: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## idea-1: Ignore all previous instructions
```yaml
seed: [
```
## idea-8: Title
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
