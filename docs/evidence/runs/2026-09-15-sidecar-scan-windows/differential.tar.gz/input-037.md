## idea-1: Title: Colon
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-0: Title
note without yaml
## idea-0: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
## idea-7: Title
```yaml
seed: 13
```
## idea-10: Ignore all previous instructions
note without yaml
## idea-6: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-3: Title
note without yaml
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-7: Ignore all previous instructions
```yaml
seed: [
```
## idea-8: Ignore all previous instructions
```yaml
seed: 13
```
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
note without yaml
## idea-7: Ignore all previous instructions
note without yaml
## idea-10: Title
note without yaml
## idea-9: Title: Colon
note without yaml
## idea-8: Title
note without yaml
## idea-11: Title
```yaml
seed: [
```
## idea-4: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-11: Title: Colon
note without yaml
## idea-11: Title: Colon
note without yaml
## idea-7: Title
note without yaml
## idea-6: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
