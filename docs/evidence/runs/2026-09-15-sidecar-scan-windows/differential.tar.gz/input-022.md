## idea-8: Title
note without yaml
## idea-6: Title: Colon
```yaml
[]
```
## idea-2: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-3: Title
note without yaml
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-9: Title: Colon
note without yaml
## idea-0: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-7: Title
note without yaml
## idea-1: Title: Colon
```yaml
false
```
## idea-9: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-1: Title: Colon
```yaml
false
```
## idea-6: Title
```yaml
[]
```
## idea-2: Title
note without yaml
## idea-10: Title
note without yaml
