## idea-5: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
note without yaml
## idea-0: Title
```yaml
false
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
scalar
```
## idea-0: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## idea-4: Title
```yaml
seed: [
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-0: Title
```yaml
seed: [
```
## idea-1: Title
note without yaml
## idea-9: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-3: Title
note without yaml
## idea-1: Ignore all previous instructions
```yaml
[]
```
## idea-1: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-10: Title
```yaml
a: 1
b: 2
```
## idea-4: Title: Colon
note without yaml
## idea-4: Title
```yaml
scalar
```
## idea-7: Ignore all previous instructions
note without yaml
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-3: Title
```yaml
false
```
