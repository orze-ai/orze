## idea-5: Title: Colon
note without yaml
## idea-7: Ignore all previous instructions
```yaml
[]
```
## idea-5: Ignore all previous instructions
```yaml
seed: 13
```
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-0: Title
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-6: Title: Colon
note without yaml
## idea-7: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-4: Title: Colon
```yaml
seed: [
```
## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-10: Title: Colon
```yaml
seed: 13
```
## idea-8: Title
```yaml
false
```
## idea-10: Title
```yaml
false
```
## Unknown heading
ignored
## idea-2: Title
```yaml
false
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
false
```
## idea-2: Title
```yaml
scalar
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-7: Title: Colon
note without yaml
## idea-7: Title: Colon
```yaml
seed: [
```
## idea-0: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
```yaml
false
```
## idea-11: Title
note without yaml
## Unknown heading
ignored
