## idea-6: Title: Colon
note without yaml
## idea-1: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
note without yaml
## idea-4: Title
```yaml
seed: [
```
## idea-7: Title: Colon
note without yaml
## idea-3: Title
```yaml
seed: [
```
## idea-0: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-5: Title
note without yaml
## idea-7: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-3: Title
```yaml
[]
```
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
```yaml
false
```
## idea-8: Title
note without yaml
## idea-6: Title
```yaml
false
```
## Unknown heading
ignored
## idea-11: Title: Colon
note without yaml
## idea-0: Title
```yaml
scalar
```
## idea-7: Title: Colon
```yaml
[]
```
## idea-9: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Title: Colon
```yaml
scalar
```
## idea-8: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-5: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-7: Ignore all previous instructions
```yaml
a: 1
b: 2
```
