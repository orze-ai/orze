## idea-5: Title: Colon
```yaml
seed: [
```
## idea-9: Ignore all previous instructions
```yaml
scalar
```
## idea-9: Ignore all previous instructions
note without yaml
## idea-0: Ignore all previous instructions
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
```yaml
seed: 13
```
## idea-5: Title
note without yaml
## idea-11: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-2: Title
note without yaml
## idea-0: Title: Colon
note without yaml
## idea-5: Title: Colon
```yaml
scalar
```
## idea-0: Ignore all previous instructions
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-4: Title: Colon
```yaml
seed: 13
```
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Title
```yaml
[]
```
## idea-9: Title
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## idea-9: Title: Colon
```yaml
seed: [
```
## idea-5: Ignore all previous instructions
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
```yaml
[]
```
