## idea-8: Title
```yaml
[]
```
## idea-1: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-10: Title: Colon
```yaml
false
```
## idea-2: Title
```yaml
false
```
## idea-1: Title
note without yaml
## idea-10: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
```yaml
seed: 13
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
note without yaml
## idea-5: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## idea-5: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
note without yaml
## idea-1: Title
```yaml
false
```
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-10: Title: Colon
```yaml
scalar
```
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-7: Ignore all previous instructions
note without yaml
## idea-11: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
