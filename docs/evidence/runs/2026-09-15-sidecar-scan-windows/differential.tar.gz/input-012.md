## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-3: Title
```yaml
false
```
## idea-3: Title: Colon
```yaml
[]
```
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-2: Title
note without yaml
## idea-6: Title
```yaml
seed: 13
```
## idea-6: Title
```yaml
scalar
```
## idea-6: Title: Colon
note without yaml
## idea-3: Ignore all previous instructions
```yaml
false
```
## idea-2: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-5: Title
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## idea-11: Title
note without yaml
## idea-8: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-8: Title: Colon
note without yaml
## idea-9: Ignore all previous instructions
note without yaml
## idea-3: Ignore all previous instructions
```yaml
false
```
## idea-11: Title
```yaml
false
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-2: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-9: Title: Colon
note without yaml
