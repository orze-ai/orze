## idea-6: Title
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## idea-8: Ignore all previous instructions
```yaml
false
```
## idea-8: Ignore all previous instructions
```yaml
[]
```
## idea-10: Title
```yaml
false
```
## idea-4: Title: Colon
note without yaml
## idea-8: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-2: Title: Colon
note without yaml
## idea-4: Title: Colon
```yaml
a: 1
b: 2
```
## idea-11: Title: Colon
```yaml
false
```
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-0: Title
note without yaml
## idea-1: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-6: Title
```yaml
false
```
## Unknown heading
ignored
## idea-11: Title: Colon
```yaml
seed: [
```
## idea-1: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-9: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-4: Title
note without yaml
## Unknown heading
ignored
## idea-4: Title
```yaml
scalar
```
## idea-6: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## idea-11: Title
note without yaml
