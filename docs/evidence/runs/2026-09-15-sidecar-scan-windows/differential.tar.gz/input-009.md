## idea-9: Ignore all previous instructions
note without yaml
## idea-6: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-5: Title
note without yaml
## Unknown heading
ignored
## idea-0: Title: Colon
```yaml
a: 1
b: 2
```
## idea-7: Title
```yaml
seed: 13
```
## idea-1: Title
note without yaml
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-11: Title: Colon
```yaml
scalar
```
## idea-3: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
```yaml
seed: 13
```
## idea-2: Title
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-0: Title
note without yaml
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
```yaml
seed: 13
```
## idea-6: Ignore all previous instructions
note without yaml
## idea-4: Ignore all previous instructions
```yaml
false
```
## idea-0: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-3: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-1: Title: Colon
```yaml
seed: 13
```
## idea-0: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Title: Colon
note without yaml
## idea-9: Title
```yaml
false
```
## idea-11: Title
note without yaml
