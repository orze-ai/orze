## idea-7: Title
```yaml
false
```
## idea-11: Title: Colon
note without yaml
## idea-6: Title
```yaml
seed: 13
```
## idea-3: Ignore all previous instructions
note without yaml
## idea-1: Ignore all previous instructions
```yaml
scalar
```
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-8: Title: Colon
note without yaml
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-4: Title
```yaml
seed: [
```
## Unknown heading
ignored
## idea-7: Title: Colon
note without yaml
## idea-6: Title
```yaml
[]
```
## idea-9: Title: Colon
```yaml
false
```
## Unknown heading
ignored
## idea-10: Title
note without yaml
## idea-0: Ignore all previous instructions
```yaml
seed: [
```
## idea-8: Title: Colon
note without yaml
## idea-1: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-8: Title
```yaml
seed: 13
```
## idea-8: Ignore all previous instructions
```yaml
seed: [
```
## idea-9: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-0: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-8: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-10: Title
```yaml
seed: 13
```
## Unknown heading
ignored
## idea-1: Ignore all previous instructions
```yaml
scalar
```
## idea-7: Ignore all previous instructions
note without yaml
