## idea-4: Title: Colon
note without yaml
## idea-8: Title
note without yaml
## idea-0: Title: Colon
note without yaml
## idea-4: Ignore all previous instructions
note without yaml
## idea-2: Ignore all previous instructions
note without yaml
## idea-10: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-4: Ignore all previous instructions
note without yaml
## idea-2: Title
```yaml
scalar
```
## Unknown heading
ignored
## idea-6: Title
note without yaml
## idea-8: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-6: Ignore all previous instructions
```yaml
[]
```
## idea-5: Title: Colon
```yaml
false
```
## idea-3: Ignore all previous instructions
```yaml
[]
```
## idea-11: Title
```yaml
seed: 13
```
## idea-10: Title
note without yaml
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-11: Title
```yaml
[]
```
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
```yaml
seed: 13
```
## idea-7: Title: Colon
```yaml
seed: [
```
## idea-1: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-7: Title
```yaml
[]
```
