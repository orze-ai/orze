## idea-10: Ignore all previous instructions
```yaml
[]
```
## Unknown heading
ignored
## idea-9: Title
note without yaml
## idea-6: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title
note without yaml
## idea-2: Title: Colon
note without yaml
## idea-8: Title
```yaml
seed: [
```
## idea-9: Title
note without yaml
## Unknown heading
ignored
## idea-11: Ignore all previous instructions
```yaml
[]
```
## idea-0: Ignore all previous instructions
note without yaml
## idea-11: Ignore all previous instructions
```yaml
a: 1
b: 2
```
## idea-8: Ignore all previous instructions
```yaml
false
```
## Unknown heading
ignored
## idea-3: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## idea-1: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-11: Title
note without yaml
## idea-4: Title
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
note without yaml
## idea-8: Ignore all previous instructions
```yaml
scalar
```
## idea-6: Title: Colon
```yaml
a: 1
b: 2
```
## Unknown heading
ignored
## idea-11: Title
note without yaml
## idea-4: Title
note without yaml
## idea-3: Title: Colon
```yaml
false
```
## idea-1: Ignore all previous instructions
note without yaml
## idea-6: Title
```yaml
false
```
