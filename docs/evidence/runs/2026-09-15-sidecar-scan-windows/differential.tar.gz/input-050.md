## idea-3: Ignore all previous instructions
```yaml
seed: [
```
## idea-4: Title: Colon
```yaml
seed: [
```
## Unknown heading
ignored
## idea-9: Ignore all previous instructions
note without yaml
## idea-5: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-5: Ignore all previous instructions
```yaml
scalar
```
## idea-11: Title
```yaml
[]
```
## idea-5: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-6: Title: Colon
```yaml
false
```
## idea-8: Ignore all previous instructions
note without yaml
## idea-10: Title
```yaml
false
```
## idea-8: Ignore all previous instructions
```yaml
scalar
```
## idea-3: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Title
```yaml
[]
```
## idea-10: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-0: Title
note without yaml
## idea-2: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-5: Title: Colon
```yaml
scalar
```
## Unknown heading
ignored
## idea-4: Title
note without yaml
## idea-7: Title
note without yaml
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## idea-11: Ignore all previous instructions
note without yaml
## idea-0: Title: Colon
```yaml
a: 1
b: 2
```
## idea-8: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
note without yaml
