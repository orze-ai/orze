## idea-0: Title: Colon
```yaml
scalar
```
## idea-4: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-10: Ignore all previous instructions
note without yaml
## idea-1: Title
note without yaml
## Unknown heading
ignored
## idea-0: Title: Colon
note without yaml
## idea-8: Title
```yaml
a: 1
b: 2
```
## idea-10: Title
```yaml
seed: [
```
## idea-1: Title: Colon
```yaml
scalar
```
## idea-1: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
```yaml
[]
```
## idea-2: Title
note without yaml
## idea-4: Title: Colon
```yaml
scalar
```
## idea-4: Ignore all previous instructions
note without yaml
## idea-2: Ignore all previous instructions
```yaml
seed: [
```
## Unknown heading
ignored
## idea-4: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-2: Ignore all previous instructions
```yaml
[]
```
## idea-8: Title
```yaml
[]
```
## idea-2: Title: Colon
```yaml
a: 1
b: 2
```
## idea-4: Title
```yaml
seed: 13
```
## idea-3: Title: Colon
```yaml
false
```
## idea-0: Title: Colon
note without yaml
## idea-11: Title: Colon
note without yaml
## Unknown heading
ignored
## idea-6: Ignore all previous instructions
note without yaml
## idea-10: Title
```yaml
scalar
```
