## idea-2: Ignore all previous instructions
note without yaml
## idea-3: Title
note without yaml
## idea-7: Ignore all previous instructions
```yaml
scalar
```
## idea-3: Title: Colon
note without yaml
## idea-1: Ignore all previous instructions
note without yaml
## idea-4: Title: Colon
```yaml
false
```
## idea-10: Title: Colon
```yaml
[]
```
## idea-11: Title
```yaml
a: 1
b: 2
```
## idea-4: Title
note without yaml
## idea-6: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-5: Title
note without yaml
## idea-2: Title: Colon
note without yaml
## idea-8: Title
note without yaml
## idea-7: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-3: Title
note without yaml
## idea-3: Title
note without yaml
## idea-8: Title
note without yaml
## idea-3: Ignore all previous instructions
```yaml
[]
```
## idea-2: Title
```yaml
[]
```
## Unknown heading
ignored
## idea-8: Ignore all previous instructions
note without yaml
## Unknown heading
ignored
## idea-1: Title
```yaml
seed: 13
```
## idea-5: Title
```yaml
seed: [
```
## idea-1: Ignore all previous instructions
```yaml
[]
```
## idea-9: Ignore all previous instructions
note without yaml
