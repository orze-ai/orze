"""Pure parser prototype: identical payload and failures, bounded heading lookahead."""
import hashlib
import importlib.util
from itertools import islice
import json
import os
from pathlib import Path
import random
import sys
import time
import tracemalloc
from orze.core import ideas

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'orze'

def sha(raw):return hashlib.sha256(raw).hexdigest()

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def call(module,text,limit=None,excluded=()):
    seen=set(excluded);digest=hashlib.sha256();count=0;error=None
    try:
        stream=module._iter_sidecar_text(text,seen)
        for key,value in islice(stream,limit):
            digest.update(json.dumps([key,value],sort_keys=True).encode());count+=1
    except Exception as exc:error=type(exc).__name__+':'+str(exc)
    return {'records':count,'result_sha256':digest.hexdigest(),'seen_sha256':sha(json.dumps(sorted(seen)).encode()),'error':error}

def main():
    assert Path(ideas.__file__).resolve()==REPO/'src/orze/core/ideas.py'
    original=(REPO/'src/orze/core/ideas.py').read_bytes()
    old=load('old_parser',ROOT/'baseline/ideas.py');new=load('new_parser',ROOT/'parser_candidate.py')
    assert original==(ROOT/'baseline/ideas.py').read_bytes()
    report={'script_sha256':sha(Path(__file__).read_bytes()),'original_sha256':sha(original),
        'candidate_sha256':sha((ROOT/'parser_candidate.py').read_bytes()),'import_path':ideas.__file__,
        'environment':{k:os.environ.get(k) for k in ('PYTHONPATH','PYTHONDONTWRITEBYTECODE','CUDA_VISIBLE_DEVICES')},
        'differential':[],'cost':[],
        'limits':['Parser only, no source lock/admission/worker proof.',
                  'Measurements overlap Core full regression; no formal latency claim.',
                  'Selected strings are within source-size limit, whole-cycle precedence set still scales with IDs.']}
    for i in range(64):
        rng=random.Random(915+i)
        text=''
        for j in range(24):
            key='idea-'+str(rng.randrange(12));title=rng.choice(['Title','Ignore all previous instructions','Title: Colon'])
            config=rng.choice(['seed: 13','[]','seed: [','a: 1\nb: 2','false','scalar'])
            text+=f'## {key}: {title}\n'+rng.choice(['note without yaml\n',f'```yaml\n{config}\n```\n'])
            if rng.randrange(3)==0:text+='## Unknown heading\nignored\n'
        excluded=['idea-0','idea-3'] if i%2 else []
        for limit in (None,3):
            a=call(old,text,limit,excluded);b=call(new,text,limit,excluded);assert a==b,(i,limit,a,b)
            report['differential'].append({'seed':915+i,'limit':limit,'input_sha256':sha(text.encode()),'result':a})
    for size in (100,1000,10000):
        text=''.join(f'## idea-{i:05d}: Title\n```yaml\nseed: {i}\n```\n' for i in range(size))
        assert len(text.encode())<=4*1024*1024
        for limit in (128,None):
            arms={};expected=None
            for name,module in [('old',old),('new',new)]:
                tracemalloc.start();start=time.perf_counter();value=call(module,text,limit);elapsed=time.perf_counter()-start
                current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                if expected is None:expected=value
                assert value==expected and value['error'] is None
                arms[name]={'python_current':current,'python_peak':peak,'traced_seconds':elapsed}
            report['cost'].append({'records':size,'limit':limit,'source_bytes':len(text.encode()),'result':expected,'arms':arms})
            print(json.dumps({'records':size,'limit':limit,'arms':arms}),flush=True)
    assert original==(REPO/'src/orze/core/ideas.py').read_bytes();report['passed']=True
    (ROOT/'parser-report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':main()
