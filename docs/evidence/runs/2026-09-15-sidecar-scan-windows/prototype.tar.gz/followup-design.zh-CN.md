# 接下来的有界前缀方案（分析，未实施）

名称窗口原型只减少 directory enumeration，不改变 preceding-file lstat 的两次验证。保留任意非合作文件改写检测时，不能仅凭父目录 mtime 跳过历史文件身份检查：修改已有文件内容不会必然改变父目录 namespace revision。这部分不能用名称缓存的收益掩盖。

另一个可独立验证的成本是单个多记录 sidecar。现有 _iter_sidecar_text 先收集全部 heading match，再逐条解析；同一文件的后页重读、重扫／重解析前缀。源文件新鲜读取的 4 MiB 边界仍有必要，但 heading 匹配可用相邻两项 lookahead 产生相同 raw 区间，避免先把全部匹配对象装入列表。需要覆盖 malformed heading、重复 ID、无 YAML、坏 YAML、标题注入和首个有效定义优先；不能改变 legacy public overlay 返回结果。

部分文件续页还可考虑单独的文件身份／已消费 ID／最后结束偏移提示。只在同一文件身份、scope、PID 和目录 revision 下跳过已消费定义；当前文件仍由 _read_source 新鲜读取。文件改写（包括恢复 mtime）、替换、硬链接或重定向须丢弃提示；读取期间变化须在 writer 前拒绝。仅将 generator 在 yield 后被继续请求的记录纳入可跳过前缀，避免把 _batch 的 lookahead／超字节额度记录当成已消费；页内 break/close 的边界需要专门验证。

部分文件提示与完整文件前缀共享文件／ID／字节容量，不能另建无限 ID cache。缓存内容限身份、ID 和偏移，不保存 YAML、raw 或 admission 结果；普通 writer／source ACK 仍为 authority。当前单文件的 files == [] 断言不能简单删掉，可以单独存 partial state 并保留此前测试业务条件。

seen 集合超过提示容量后的增长是另一项：可考虑超过阈值才转移至私有 SQLite 精确集合，保持先出现的合法 ID 语义，generator.close 时关闭／清理，文件异常清理及额外 I/O 必须另测。不要把这种磁盘成本转移说成总成本消失。该方案尚无实现／成本证据。

这些后续点尚未进入产品，也没有获得新的验收状态；先关闭 ingress 准备片，再建立新提交基线，按真实结果和可复核成本决定下一片范围。
