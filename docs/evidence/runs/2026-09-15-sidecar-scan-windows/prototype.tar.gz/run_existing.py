"""Run copied existing prefix tests with a process-only candidate module."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def inputs():
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for base in ("src", "tests")
            for p in (REPO / base).rglob("*") if p.is_file() and "__pycache__" not in p.parts}

if __name__ == "__main__":
    before = inputs()
    code = """import sys; from pathlib import Path; import pytest
from orze.engine import sidecar_prefix
root=Path(sys.argv[1]); repo=root.parent/'orze'
assert Path(sidecar_prefix.__file__).resolve()==repo/'src/orze/engine/sidecar_prefix.py'
sys.path.insert(0,str(repo/'tests'))
exec(compile((root/'candidate.py').read_bytes(),str(root/'candidate.py'),'exec'),sidecar_prefix.__dict__)
raise SystemExit(pytest.main([str(root/'test_existing_prefix.py'),'-q','--tb=short','-p','no:cacheprovider','--basetemp=/tmp/osnw-p1','--junitxml='+str(root/'tests.xml')]))
"""
    with (ROOT/'tests.stdout.log').open('xb') as out, (ROOT/'tests.stderr.log').open('xb') as err:
        run=subprocess.run([sys.executable,'-c',code,str(ROOT)],cwd=REPO,stdout=out,stderr=err)
    assert before==inputs()
    record={'exit_code':run.returncode,'frozen_inputs':before,'script_sha256':sha(Path(__file__).read_bytes()),
            'candidate_sha256':sha((ROOT/'candidate.py').read_bytes()),
            'files':{n:sha((ROOT/n).read_bytes()) for n in ('test_existing_prefix.py','tests.stdout.log','tests.stderr.log','tests.xml')},
            'environment':{k:__import__('os').environ.get(k) for k in ('PYTHONPATH','PYTHONDONTWRITEBYTECODE','CUDA_VISIBLE_DEVICES')},
            'command':[sys.executable,'-c',code,str(ROOT)],'cwd':str(REPO)}
    (ROOT/'tests.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'exit_code':run.returncode,'source_test_inputs_unchanged':True}))
    raise SystemExit(run.returncode)
