"""Read-only full-ingress name-window exploration with process-only class swapping."""
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch
from orze.engine import idea_ingress, sidecar_prefix
from orze.engine.orchestrator import Orze
from orze.idea_lake import IdeaLake

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def inputs():
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for base in ("src", "tests")
            for p in (REPO / base).rglob("*") if p.is_file() and "__pycache__" not in p.parts}

def main():
    assert Path(sidecar_prefix.__file__).resolve() == REPO / 'src/orze/engine/sidecar_prefix.py'
    assert Path(idea_ingress.__file__).resolve() == REPO / 'src/orze/engine/idea_ingress.py'
    spec=importlib.util.spec_from_file_location('candidate_prefix',ROOT/'candidate.py')
    candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
    before_sources=inputs()
    base=Path('/tmp/orze-sidecar-name-window-probe-v1');base.mkdir(exist_ok=False)
    report={'source_test_files':before_sources,'script_sha256':sha(Path(__file__).read_bytes()),
        'candidate_sha256':sha((ROOT/'candidate.py').read_bytes()),'cwd':str(Path.cwd()),
        'environment':{k:os.environ.get(k) for k in ('PYTHONPATH','PYTHONDONTWRITEBYTECODE','CUDA_VISIBLE_DEVICES')},
        'import_paths':{'sidecar_prefix':sidecar_prefix.__file__,'idea_ingress':idea_ingress.__file__,
                        'orchestrator':sys.modules[Orze.__module__].__file__,'idea_lake':sys.modules[IdeaLake.__module__].__file__},
        'root':str(base),'rows':[],
        'limits':['Exploratory operation counts while Core full regression runs; no ordinary latency claim.',
                  'Process-local class override; application source/tests remain unchanged.',
                  'Actual source locks, candidate payload reads and normal writers; imported history, no worker.',
                  'Name cache only; preceding file identity checks still grow with the traversal prefix.']}
    for count,layout in ((100,'many'),(1000,'many'),(5000,'many'),(1000,'one')):
        root=base/f'{count}-{layout}';root.mkdir();side=root/'ideas.d';side.mkdir()
        results=root/'results';results.mkdir();source=root/'ideas.md';source.write_text('# Ideas\n')
        cfg={'ideas_file':str(source),'results_dir':str(results),'idea_lake_db':str(root/'lake.db'),'_orze_dir':str(root/'.orze')}
        engine=Orze.__new__(Orze);engine.cfg,engine.results_dir,engine.active_roles=cfg,results,{}
        engine.lake=IdeaLake(cfg['idea_lake_db']);blocks=[]
        for i in range(count):
            key=f'idea-side-{i:05d}';text=f'## {key}: Conflicting source title\n```yaml\nseed: {i}\n```\n'
            engine.lake.conn.execute("INSERT INTO ideas(idea_id,title,config,raw_markdown,status) VALUES (?,'Stored',?,'','completed')",(key,f'seed: {i}\n'))
            if layout=='many':(side/f'{i:05d}.md').write_text(text)
            else:blocks.append(text)
        if layout=='one':(side/'all.md').write_text(''.join(blocks))
        engine.lake.conn.commit();before_db=sha('\n'.join(engine.lake.conn.iterdump()).encode())
        source_files={str(p):sha(p.read_bytes()) for p in [source,*side.iterdir()]}
        arms={}
        try:
            for name,module in (('old',sidecar_prefix),('new',candidate)):
                engine._idea_ingress_cursor=None
                counters={'scandir_calls':0,'directory_entries':0,'file_identity_checks':0,'payload_reads':0,'max_names':0}
                real_scan=os.scandir;real_stamp=module._file_stamp;real_read=idea_ingress._read_source
                @contextlib.contextmanager
                def counted_scan(path):
                    with real_scan(path) as entries:
                        if Path(path)!=side:
                            yield entries;return
                        counters['scandir_calls']+=1
                        def items():
                            for entry in entries:
                                counters['directory_entries']+=1
                                yield entry
                        yield items()
                def stamp(path):
                    counters['file_identity_checks']+=1
                    return real_stamp(path)
                def read(path):
                    if path.parent==side:counters['payload_reads']+=1
                    return real_read(path)
                total=pages=0;digest=hashlib.sha256();start=time.perf_counter()
                with patch.object(sidecar_prefix,'SidecarPrefix',module.SidecarPrefix), patch.object(module,'_file_stamp',stamp), patch.object(os,'scandir',counted_scan), patch.object(idea_ingress,'_read_source',read), patch.object(idea_ingress.logger,'warning',lambda *a,**k:None):
                    while True:
                        raw,inserted=idea_ingress.ingest_ideas_source(engine,cfg)
                        assert not inserted
                        total+=len(raw);pages+=1;digest.update(json.dumps(raw,sort_keys=True).encode())
                        counters['max_names']=max(counters['max_names'],len(getattr(engine._idea_sidecar_prefix,'name_window',())))
                        assert pages <= (count+127)//128+1
                        if engine._idea_ingress_cursor[2]==0:break
                assert total==count and counters['max_names']<=512
                arms[name]={'records':total,'pages':pages,'raw_sha256':digest.hexdigest(),'counters':counters,'instrumented_seconds':time.perf_counter()-start}
            assert {k:v for k,v in arms['old'].items() if k not in ('counters','instrumented_seconds')}=={k:v for k,v in arms['new'].items() if k not in ('counters','instrumented_seconds')}
            for k in ('payload_reads','file_identity_checks'):assert arms['old']['counters'][k]==arms['new']['counters'][k]
            assert before_db==sha('\n'.join(engine.lake.conn.iterdump()).encode())
            assert source_files=={n:sha(Path(n).read_bytes()) for n in source_files}
            row={'records':count,'layout':layout,'arms':arms,'database_sha256':before_db,'source_files':source_files}
            report['rows'].append(row)
            print(json.dumps({'records':count,'layout':layout,'counts':{k:v['counters'] for k,v in arms.items()}}),flush=True)
        finally:engine.lake.close()
    assert inputs()==before_sources;report['passed']=True
    (ROOT/'probe-report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':main()
