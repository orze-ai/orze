# 部分文件前缀：待验证设计细节

当前名称窗口与 heading lookahead 的完整普通对照尚未覆盖部分文件缓存；单个5000条文件仍反复执行 prefix YAML 解析，当前17秒量级不是已关闭项。以下只记录分析，不修改当前冻结源码或已执行的原型脚本。

可先考虑只缓存“部分文件已消费的有效 ID”，无需解析器字节偏移 API：下一批仍新鲜读取完整文件并检查同一源身份，重新扫描 heading，但在 YAML 之前用已验证 IDs 跳过旧定义；向 islice 先重放等量 (id, None) 以保持全流 offset。仅在 yield 被继续请求后记入可跳过前缀，不能把 _batch 为探测更多内容／字节溢出而取得的最后一个 lookahead 记录算作已消费。

部分 IDs 应与已有完整文件 IDs 共用 MAX_IDS／MAX_ID_BYTES 和文件容量。可以单独 bounded list 引用已消费字符串，避免每条复制整列表的 O(N²)。当前 local ids 列表仍有按单文件源大小限制的成本；一旦达到缓存容量，不能让 persistent partial state 继续引用一个随后无限增长的 local list。完整文件晋升时只迁移计数，不能重复计入已缓存部分 ID。

内容绑定是关键：当前 stream 只获得 read_text 返回的字符串，而 _read_source 实际已经验证 descriptor 前后／路径身份。若仅把字符串绑定到后来一次 lstat，可能把旧文本误绑定到新 inode；若绑定更早的 stat，又可能在读前已经换成新合法文件时无谓拒绝。因此更完整的方案是把真实 fresh reader 的 text+verified identity 通过内部 snapshot callback 传给 prefix，同时保持 legacy read_text 接口。partial.verify 可比较同样的 dev/ino/size/mtime/ctime/nlink 并要求 regular file；不能丢掉链接和重定向检查。现有 _read_source 返回权限只含低9位，不能把它伪装成完整 st_mode。

使用 cached partial IDs 之前必须确认读取版本与 cached version 一致；不一致则丢弃该提示并按当前正文重新遍历，不能先把旧 IDs 放入 seen。读取后变化必须在 writer 前使提示失效。需要验证：改写并恢复 mtime、rename/replace、hardlink/symlink、读前与读后竞争、无效／重复定义、source-byte overflow lookahead、异常 close、PID/目录换代、容量 fallback、源锁失去及新进程恢复。

该设计尚未实施，不能用作权限或性能证据。先关闭当前两项扫描改动的正式验收，再决定是否采用；原有资格和原测试断言不得为了缓存方便而删除。
