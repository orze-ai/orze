## idea-candidate: Candidate
- **Kind**: native_cpu_action
```yaml
seed: 13
```

