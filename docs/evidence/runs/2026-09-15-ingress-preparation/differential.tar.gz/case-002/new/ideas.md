## idea-candidate: Candidate
- **Kind**: train
```yaml
seed: 13
```

