## idea-fresh: Fresh
```yaml
seed: -17
```

