## idea-candidate: Candidate
- **Kind**: native_cpu_action
```yaml
seed: 13
```

## idea-fresh: Fresh
```yaml
seed: -17
```

