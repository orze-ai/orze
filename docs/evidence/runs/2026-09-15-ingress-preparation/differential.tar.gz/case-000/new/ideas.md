## idea-candidate: Candidate
- **Kind**: train
```yaml
seed: 13
```

## idea-fresh: Fresh
```yaml
seed: -17
```

