"""Isolated unused-lookup exploration while status-merge inputs remain frozen.

The instance override is only an experiment, not a proposed public API change.
Normal writer admission still executes. No application file is edited.
"""
import importlib.util
import json
from pathlib import Path
import re
import shutil
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


b = load("ingress_measure", REPO / "docs/evidence/checks/2026-09-15-ingress-benchmark.py")
allocator_path = REPO / "docs/evidence/checks/2026-09-15-status-merge-allocator.py"
allocator = load("allocator", allocator_path)


def fingerprint():
    return {str(p.relative_to(REPO)): b.sha(p.read_bytes()) for p in (REPO / "src").rglob("*.py")}


def main():
    root = ROOT / "fixtures"
    root.mkdir(exist_ok=False)
    sources = fingerprint()
    report = {"source_files": sources, "script_sha256": b.sha(Path(__file__).read_bytes()),
              "helper_sha256": b.sha(Path(b.__file__).read_bytes()), "allocator_helper_sha256": b.sha(allocator_path.read_bytes()),
              "rows": [], "limits": ["Exploration during frozen full regressions; no latency claim on this shared host.",
                 "Only one isolated instance's find method overridden, solely for ingress which discards its return value.",
                 "No application API or source change; public lookup callers must keep their return semantics.",
                 "Legacy preparation still called for nonempty normalized identities; current writer remains authority.",
                 "Imported metadata, no workers, provider, production, or scientific acceptance.",
                 "SQLite allocator excludes separately configured auxiliary pagecache and is not RSS."]}
    for history, mode in ((5000, "exact"), (1000, "crowded"), (5000, "crowded"), (20000, "crowded")):
        original_project = Path(f"/tmp/orze-status-merge-admission-v1/{history}-{mode}")
        project = root / f"{history}-{mode}"
        project.mkdir()
        results = project / "results"
        results.mkdir()
        source = project / "ideas.md"
        source.write_bytes((original_project / "ideas.md").read_bytes())
        shutil.copy2(original_project / "lake.db", project / "lake.db")
        cfg = {"ideas_file": str(source), "results_dir": str(results), "idea_lake_db": str(project / "lake.db"),
               "_orze_dir": str(project / ".orze")}
        engine = b.Orze.__new__(b.Orze)
        engine.cfg, engine.results_dir, engine.active_roles = cfg, results, {}
        engine.lake = b.IdeaLake(cfg["idea_lake_db"])
        original_find = engine.lake.find_admitted_config_hashes
        before = b.sha("\n".join(engine.lake.conn.iterdump()).encode())
        authored = source.read_bytes()

        def call(arm, observations=None):
            def lookup(identities):
                if observations is not None:
                    before_lookup = allocator.snapshot()
                if arm == "current":
                    value = original_find(identities)
                else:
                    requested = list(dict.fromkeys(value for value in identities
                        if isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)))
                    if requested:
                        engine.lake._repair_admitted_config_hashes()
                    value = {}
                if observations is not None:
                    observations.append({"before": before_lookup, "after": allocator.snapshot()})
                return value

            engine._idea_ingress_cursor = None
            engine.lake.find_admitted_config_hashes = lookup
            try:
                raw, inserted = b.idea_ingress.ingest_ideas_source(engine, cfg)
            finally:
                engine.lake.find_admitted_config_hashes = original_find
            assert not inserted and len(raw) == 128 and source.read_bytes() == authored
            return {"raw_sha256": b.sha(json.dumps(raw, sort_keys=True).encode()), "inserted": inserted}

        try:
            with patch.object(b.idea_ingress.logger, "warning", lambda *args, **kwargs: None):
                measured = b.measure({name: lambda name=name: call(name) for name in ("current", "prepare_only")}, 3, memory=True)
                phases = {}
                for arm in ("current", "prepare_only"):
                    start = allocator.snapshot(reset=True)["current"]
                    observed = []
                    assert call(arm, observed) == measured["value"]
                    phases[arm] = {"before": start, "lookup_or_preparation": observed, "after": allocator.snapshot()}
                    assert len(observed) == 1
            assert before == b.sha("\n".join(engine.lake.conn.iterdump()).encode())
            row = {"history": history, "mode": mode, **measured, "phases": phases,
                   "database_sha256": before, "source_sha256": b.sha(authored)}
            report["rows"].append(row)
            (ROOT / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
            print(json.dumps({"history": history, "mode": mode,
                "ms": {k: v["median_seconds"] * 1000 for k, v in measured["arms"].items()},
                "sqlite": phases}), flush=True)
        finally:
            engine.lake.close()
    assert fingerprint() == sources
    report["passed"] = True
    (ROOT / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
