
import os,sys
if 'orze.cli' in getattr(sys,'orig_argv',()):
    from orze import extensions
    def forbidden(*a,**k):
        raise AssertionError('CPU controller touched GPU/provider/legacy boundary')
    extensions.has_pro=forbidden
    extensions._find_pro_key=forbidden
    try:
        from orze_pro import _gate
        _gate.require_license=lambda:None
    except ImportError:pass
    from orze.hardware import gpu
    gpu.detect_all_gpus=forbidden
    from orze.core import gpu_lease
    gpu_lease.acquire_gpu_leases=forbidden
    gpu_lease.assert_gpu_scope_idle=forbidden
    from orze import lifecycle
    lifecycle.do_stop=forbidden
    if os.environ.get('CPU_STOP_FAULT')=='unsettled':
        from orze.core import cpu_action_budget
        cpu_action_budget.settle=lambda *a,**k:'settled'
    if os.environ.get('CPU_STOP_FAULT')=='orphan_reservation':
        from orze.engine import cpu_phase
        from orze.core import cpu_action_budget
        actual_start=cpu_phase.start
        def start(engine):
            actual_start(engine)
            cpu_action_budget.reserve(engine.lake,engine._cpu_scope,'orphan-0001',1)
        cpu_phase.start=start
    if os.environ.get('CPU_STOP_FAULT')=='close_response_lost':
        from orze.idea_lake import IdeaLake
        actual_close=IdeaLake.close
        def close(self):
            actual_close(self)
            raise OSError('fixture: Lake close response lost')
        IdeaLake.close=close

if 'orze.service.host' in getattr(sys, 'orig_argv', ()):
    import subprocess
    from pathlib import Path
    actual_popen = subprocess.Popen
    def popen(command, *args, **kwargs):
        if list(command[:3]) == [sys.executable, '-m', 'orze.cli']:
            with Path('controllers.log').open('ab') as stream:
                kwargs.update(stdout=stream, stderr=subprocess.STDOUT)
                return actual_popen(command, *args, **kwargs)
        raise AssertionError('service host crossed an unexpected spawn boundary')
    subprocess.Popen = popen
    from orze.engine import controller_handoff
    actual_receive = controller_handoff._receive
    def receive(channel, peer_pid, deadline):
        packet = actual_receive(channel, peer_pid, deadline)
        marker = Path('lose-started-reply')
        if packet.get('event') == 'STARTED' and marker.exists():
            marker.rename('lost-started-reply-observed')
            raise OSError('fixture: final reply lost after actual receive')
        return packet
    controller_handoff._receive = receive
if 'orze.cli' in getattr(sys, 'orig_argv', ()):
    import socket, json
    from orze.engine.supervisor_worker import process_identity
    channel = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    channel.settimeout(20)
    channel.connect(str(__import__('pathlib').Path.cwd() / 'birth.sock'))
    channel.sendall((json.dumps({'process': process_identity(os.getpid())[0],
                               'parent': os.getppid()}) + '\n').encode())
    assert channel.recv(1) == b'B'
    channel.close()
if 'orze.service.watchdog' in getattr(sys, 'orig_argv', ()):
    from orze.service import watchdog
    def forbidden(*a, **k):
        raise AssertionError('hosted watchdog reached legacy process authority')
    watchdog._read_pid = watchdog._is_pid_alive = watchdog._is_orze_running = forbidden
    watchdog._kill_stale = watchdog._launch_orze = watchdog.check_containers = forbidden

if 'orze.service.host' in getattr(sys, 'orig_argv', ()):
    import subprocess
    from orze.engine.controller_session import _Observer
    spawned = []
    original_spawn, original_observe = subprocess.Popen, _Observer.__init__
    def capture_spawn(*args, **kwargs):
        child = original_spawn(*args, **kwargs)
        spawned.append(child)
        return child
    def observe_after_child_exit(self, *args, **kwargs):
        for child in spawned:
            assert child.wait(timeout=10) == 0
        Path('observed-after-exit').touch()
        return original_observe(self, *args, **kwargs)
    subprocess.Popen, _Observer.__init__ = capture_spawn, observe_after_child_exit
