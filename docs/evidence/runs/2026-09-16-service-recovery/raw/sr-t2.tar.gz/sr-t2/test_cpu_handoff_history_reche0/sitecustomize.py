try:

    import os,sys
    if 'orze.cli' in getattr(sys,'orig_argv',()):
        from orze import extensions
        def forbidden(*a,**k):
            raise AssertionError('CPU controller touched GPU/provider/legacy boundary')
        extensions.has_pro=forbidden
        extensions._find_pro_key=forbidden
        try:
            from orze_pro import _gate
            _gate.require_license=lambda:None
        except ImportError:pass
        from orze.hardware import gpu
        gpu.detect_all_gpus=forbidden
        from orze.core import gpu_lease
        gpu_lease.acquire_gpu_leases=forbidden
        gpu_lease.assert_gpu_scope_idle=forbidden
        from orze import lifecycle
        lifecycle.do_stop=forbidden
        if os.environ.get('CPU_STOP_FAULT')=='unsettled':
            from orze.core import cpu_action_budget
            cpu_action_budget.settle=lambda *a,**k:'settled'
        if os.environ.get('CPU_STOP_FAULT')=='orphan_reservation':
            from orze.engine import cpu_phase
            from orze.core import cpu_action_budget
            actual_start=cpu_phase.start
            def start(engine):
                actual_start(engine)
                cpu_action_budget.reserve(engine.lake,engine._cpu_scope,'orphan-0001',1)
            cpu_phase.start=start
        if os.environ.get('CPU_STOP_FAULT')=='close_response_lost':
            from orze.idea_lake import IdeaLake
            actual_close=IdeaLake.close
            def close(self):
                actual_close(self)
                raise OSError('fixture: Lake close response lost')
            IdeaLake.close=close

    if 'orze.cli' in getattr(sys,'orig_argv',()):
        import json,socket,subprocess
        from pathlib import Path
        root=Path.cwd()
        successor='ORZE_CONTROLLER_HANDOFF_FD' in os.environ
        if successor:
            channel=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
            channel.settimeout(15);channel.connect(str(root/'birth.sock'))
            channel.sendall((json.dumps({'pid':os.getpid(),'parent':os.getppid()})+'\n').encode())
            assert channel.recv(1)==b'L'
            channel.close()
        actual_popen=subprocess.Popen
        def logged_popen(command,*args,**kwargs):
            if list(command[:3])==[sys.executable,'-m','orze.cli']:
                with (root/'successor.log').open('ab') as log:
                    kwargs['stdout']=log;kwargs['stderr']=subprocess.STDOUT
                    return actual_popen(command,*args,**kwargs)
            return actual_popen(command,*args,**kwargs)
        subprocess.Popen=logged_popen
        from orze.engine import cpu_phase,controller_handoff as handoff
        from orze.engine.controller_session import ControllerSession
        actual_fail=ControllerSession.fail
        def fail(self,exc):
            import traceback
            traceback.print_exception(type(exc),exc,exc.__traceback__)
            return actual_fail(self,exc)
        ControllerSession.fail=fail
        actual_start=cpu_phase.start
        def start(engine):
            marker=root/('start-'+str(os.getpid())+'.json')
            assert not marker.exists(),'CPU start called twice'
            actual_start(engine)
            marker.write_text(json.dumps({'pid':os.getpid(),'successor':successor}))
        cpu_phase.start=start
        actual_iteration=cpu_phase.iteration
        def iteration(engine):
            marker=root/('iteration-'+str(os.getpid())+'.json')
            if not marker.exists():
                if successor:
                    admission=engine._controller_session._admission
                    row=engine.lake.conn.execute('SELECT state FROM controller_handoffs WHERE grant_id=?',
                        (admission.grant_id,)).fetchone()
                    assert row[0]=='STARTED','policy reached before COMMIT'
                marker.write_text(json.dumps({'pid':os.getpid(),'successor':successor}))
            return actual_iteration(engine)
        cpu_phase.iteration=iteration
        fault=os.environ.get('CPU_HANDOFF_FAULT','')
        actual_receive=handoff._receive
        def receive(channel,peer_pid,deadline):
            packet=actual_receive(channel,peer_pid,deadline)
            event=packet['event']
            if successor and event=='COMMIT' and fault in {'orphan_at_commit','policy_stop_at_commit'}:
                from orze.engine.controller_control import current_controller
                from orze.engine.controller_session import _SESSIONS
                from orze.core import cpu_action_budget as budget
                engine=_SESSIONS[current_controller().controller_id].orze
                if fault=='orphan_at_commit':
                    assert budget.reserve(engine.lake,engine._cpu_scope,'orphan-commit',1) is not None
                else:
                    budget.record_decision(engine.lake,engine._cpu_scope,
                        {'kind':'Stop','reason':'fixture_policy_stop','wakeup':None})
                (root/'fault.json').write_text(json.dumps({'event':event,'fault':fault}))
            if not successor and event=='STARTED' and fault=='lost_started_reply':
                (root/'fault.json').write_text(json.dumps({'event':event,'fault':fault}))
                raise OSError('fixture: lost final STARTED reply after real receive')
            return packet
        handoff._receive=receive

except BaseException as exc:
    import os,sys
    print("fixture hook failed: "+repr(exc),file=sys.stderr,flush=True)
    os._exit(97)
