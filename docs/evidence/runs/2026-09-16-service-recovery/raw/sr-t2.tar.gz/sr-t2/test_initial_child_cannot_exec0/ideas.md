## idea-0001: service CPU action

```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - from pathlib import Path;Path('/tmp/sr-t2/test_initial_child_cannot_exec0/must-not-run').write_text("unexpected")
  inputs: {}
  outputs: {}
  purpose: service ownership fixture
  timeout_seconds: 60
  version: 1
kind: native_cpu_action
```
