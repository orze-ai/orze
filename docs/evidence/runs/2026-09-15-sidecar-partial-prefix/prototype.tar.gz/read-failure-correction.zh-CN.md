# 隔离原型的读取失败修正

v1 在新 `_read_sidecar` 返回空文本时仍可能重用先前 ID。读取失败没有当前首个有效定义的依据；不能把旧 ID 补入 seen 或推进 offset 后接受下一个文件。`test_read_failure_does_not_grant_precedence_to_cached_ids` 在 v1 失败。

v2 仅增加当前非空文本前提；继续核对同名、文件身份、已消费数量和当前 offset。保留 v1、构造脚本和运行原件，不修改冻结的仓库源码。此处不是正式产品验收；仍需更多读取期间变动／异常关闭／容量与 payload 上限用例及完整路径对照。
