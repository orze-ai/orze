"""Build an isolated candidate; never modify imported repository files."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / "baseline/sidecar_prefix.py").read_text()
source = source.replace("        self.files = []\n", "        self.files = []\n        self.partial = None\n        self.generation = object()\n")
source = source.replace("                    or _directory_stamp(self.directory) != self.revision):", "                    or (self.partial is not None and\n                        _file_stamp(self.directory / self.partial[0]) != self.partial[1])\n                    or _directory_stamp(self.directory) != self.revision):")
start = source.index("                ids = []\n")
end = source.index("        except Exception:\n", start)
source = source[:start] + '''                generation = self.generation
                cached = ()
                if self.partial is not None:
                    prior_name, identity, prior_ids = self.partial
                    if (prior_name == name and identity == before
                            and len(prior_ids) <= remaining
                            and _file_stamp(path) == identity):
                        cached = prior_ids
                    else:
                        self.partial = None
                ids = list(cached)
                consumed = 0
                complete = False
                try:
                    seen.update(cached)
                    for idea_id in cached:
                        remaining = max(0, remaining - 1)
                        yield idea_id, None
                        consumed += 1
                    for idea_id, idea in _iter_sidecar_text(text, seen):
                        ids.append(idea_id)
                        remaining = max(0, remaining - 1)
                        yield idea_id, idea
                        consumed += 1
                    complete = True
                finally:
                    # The lookahead record is yielded but never resumed. Only
                    # records actually consumed by the page enter the hint.
                    # clear() before stream.close() must not resurrect state.
                    if not complete and self.generation is generation:
                        self.partial = None
                        if consumed and self.extend and text and before is not None:
                            prefix = tuple(ids[:consumed])
                            amount = sum(len(key.encode()) for key in prefix)
                            if (len(self.files) < MAX_FILES
                                    and self.id_count + len(prefix) <= MAX_IDS
                                    and self.id_bytes + amount <= MAX_ID_BYTES):
                                if _file_stamp(path) != before:
                                    raise ValueError("sidecar_partial_file_changed")
                                self.partial = (name, before, prefix)
                            else:
                                self.extend = False
                self.partial = None
                amount = sum(len(key.encode()) for key in ids)
                if (not self.extend or not text or before is None
                        or len(self.files) >= MAX_FILES
                        or self.id_count + len(ids) > MAX_IDS
                        or self.id_bytes + amount > MAX_ID_BYTES):
                    self.extend = False
                    continue
                if _file_stamp(path) != before:
                    raise ValueError("sidecar_prefix_file_changed")
                self.files.append((name, before, tuple(ids)))
                self.id_count += len(ids)
                self.id_bytes += amount
''' + source[end:]
target = ROOT / "candidate-v1.py"
assert not target.exists()
target.write_text(source)
