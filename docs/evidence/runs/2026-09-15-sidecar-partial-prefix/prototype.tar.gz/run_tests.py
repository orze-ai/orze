"""Isolated process substitution; retain every command, input and raw failure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def inputs():
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for base in ("src", "tests")
            for p in (REPO / base).rglob("*") if p.is_file() and "__pycache__" not in p.parts}


if __name__ == "__main__":
    arm = sys.argv[1]
    assert arm in ("old", "v1", "v2")
    out = ROOT / ("tests-" + arm)
    out.mkdir()
    before = inputs()
    code = """import sys; from pathlib import Path; import pytest
from orze.engine import sidecar_prefix
root=Path(sys.argv[1]); repo=root.parent/'orze'; arm=sys.argv[2]
assert Path(sidecar_prefix.__file__).resolve()==repo/'src/orze/engine/sidecar_prefix.py'
sys.path.insert(0,str(repo/'tests'))
if arm!='old':exec(compile((root/('candidate-'+arm+'.py')).read_bytes(),str(root/('candidate-'+arm+'.py')),'exec'),sidecar_prefix.__dict__)
args=[str(root/'test_partial.py'),'-q','--tb=short','-p','no:cacheprovider','--basetemp=/tmp/ospp-'+arm,'--junitxml='+str(root/('tests-'+arm)/'junit.xml')]
if arm=='old':args.extend(['-k','does_not_reparse'])
else:args.append(str(root/'baseline/test_sidecar_prefix_continuation.py'))
raise SystemExit(pytest.main(args))
"""
    command = [sys.executable, "-c", code, str(ROOT), arm]
    with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
        result = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr)
    after = inputs()
    record = {"exit_code": result.returncode, "frozen": before == after, "before": before, "after": after,
              "cwd": str(REPO), "command": command, "script_sha256": sha(Path(__file__).read_bytes()),
              "environment": {k: os.environ.get(k) for k in ("PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "CUDA_VISIBLE_DEVICES")},
              "files": {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in [ROOT / "test_partial.py", ROOT / "baseline/test_sidecar_prefix_continuation.py", *out.iterdir(), *([] if arm == "old" else [ROOT / ("candidate-"+arm+".py")])]}}
    (out / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"exit_code": result.returncode, "frozen": before == after}))
    assert before == after
    raise SystemExit(result.returncode)
