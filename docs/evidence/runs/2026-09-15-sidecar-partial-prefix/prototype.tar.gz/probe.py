"""Instrument full ingress in isolated fixtures; timings are exploratory only."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"
FIXTURES = Path("/tmp/orze-sidecar-partial-probe-v1")
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inputs():
    return {str(p.relative_to(REPO)): sha(p.read_bytes()) for base in ("src", "tests")
            for p in (REPO / base).rglob("*") if p.is_file() and "__pycache__" not in p.parts}


def main():
    from orze.engine import idea_ingress, sidecar_prefix
    from orze.core import ideas
    assert Path(sidecar_prefix.__file__).resolve() == REPO / "src/orze/engine/sidecar_prefix.py"
    assert Path(idea_ingress.__file__).resolve() == REPO / "src/orze/engine/idea_ingress.py"
    baseline = load("partial_baseline", ROOT / "baseline/sidecar_prefix.py")
    candidate = load("partial_candidate", ROOT / "candidate-v2.py")
    helper = load("ingress_helper", REPO / "docs/evidence/checks/2026-09-15-ingress-benchmark.py")
    FIXTURES.mkdir()
    before = inputs()
    report = {"script_sha256": sha(Path(__file__).read_bytes()), "candidate_sha256": sha((ROOT / "candidate-v2.py").read_bytes()),
              "baseline_sha256": sha((ROOT / "baseline/sidecar_prefix.py").read_bytes()),
              "helper_sha256": sha(Path(helper.__file__).read_bytes()), "root": str(FIXTURES),
              "cwd": str(Path.cwd()), "command": [sys.executable, *sys.argv],
              "environment": {k: os.environ.get(k) for k in ("PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "CUDA_VISIBLE_DEVICES")},
              "source_test_files": before, "rows": [],
              "limits": ["Exploratory instrumented timings overlap scan-window regression/audit work.",
                         "Imported completed metadata, no worker or scientific result; same current ingress and writer.",
                         "Candidate changes only this process; no source edits or formal product acceptance."]}
    for layout, size in (("many", 100), ("many", 1000), ("one", 1000), ("one", 5000)):
        project = FIXTURES / f"{layout}-{size}"
        results = project / "results"
        results.mkdir(parents=True)
        source = project / "ideas.md"
        source.write_text("# Ideas\n")
        side = project / "ideas.d"
        side.mkdir()
        cfg = {"ideas_file": str(source), "results_dir": str(results), "idea_lake_db": str(project / "lake.db"), "_orze_dir": str(project / ".orze")}
        engine = helper.Orze.__new__(helper.Orze)
        engine.cfg, engine.results_dir, engine.active_roles = cfg, results, {}
        engine.lake = helper.IdeaLake(cfg["idea_lake_db"])
        try:
            blocks = []
            for index in range(size):
                key = f"idea-side-{index:05d}"
                engine.lake.conn.execute("INSERT INTO ideas(idea_id,title,config,raw_markdown,status) VALUES (?,?,?,'','completed')", (key, "Stored metadata", f"seed: {index}\n"))
                block = f"## {key}: Conflicting authored title\n```yaml\nseed: {index}\n```\n" + "note " * 40 + "\n"
                if layout == "many":
                    (side / f"{index:05d}.md").write_text(block)
                else:
                    blocks.append(block)
            if layout == "one":
                (side / "all.md").write_text("".join(blocks))
            engine.lake.conn.commit()
            database = sha("\n".join(engine.lake.conn.iterdump()).encode())
            sources = {str(p): sha(p.read_bytes()) for p in [source, *side.glob("*.md")]}
            arms = {}
            for arm, module in (("old", baseline), ("new", candidate)):
                counts = {"yaml_loads": 0, "payload_reads": 0, "payload_bytes": 0, "file_stamps": 0, "begins": 0, "rollbacks": 0, "max_partial_ids": 0}
                real_yaml, real_read, real_stamp = ideas.yaml.safe_load, idea_ingress._read_source, module._file_stamp
                def parsed(*args, **kwargs):
                    counts["yaml_loads"] += 1
                    return real_yaml(*args, **kwargs)
                def read(path):
                    result = real_read(path)
                    if path.parent == side:
                        counts["payload_reads"] += 1
                        counts["payload_bytes"] += len(result[0].encode())
                    return result
                def stamp(path):
                    counts["file_stamps"] += 1
                    return real_stamp(path)
                def statement(sql):
                    counts["begins"] += sql == "BEGIN IMMEDIATE"
                    counts["rollbacks"] += sql == "ROLLBACK"
                engine._idea_ingress_cursor = None
                digest = hashlib.sha256()
                records = batches = 0
                engine.lake.conn.set_trace_callback(statement)
                started = time.perf_counter()
                try:
                    with patch.object(sidecar_prefix, "SidecarPrefix", module.SidecarPrefix), patch.object(ideas.yaml, "safe_load", parsed), patch.object(idea_ingress, "_read_source", read), patch.object(module, "_file_stamp", stamp), patch.object(idea_ingress.logger, "warning", lambda *a, **k: None):
                        while True:
                            raw, inserted = idea_ingress.ingest_ideas_source(engine, cfg)
                            assert not inserted
                            records += len(raw)
                            batches += 1
                            digest.update(json.dumps(raw, sort_keys=True).encode())
                            partial = getattr(engine._idea_sidecar_prefix, "partial", None)
                            counts["max_partial_ids"] = max(counts["max_partial_ids"], len(partial[2]) if partial else 0)
                            if engine._idea_ingress_cursor[2] == 0:
                                break
                            assert batches <= (size + 127) // 128 + 1
                finally:
                    engine.lake.conn.set_trace_callback(None)
                arms[arm] = {"instrumented_seconds": time.perf_counter() - started, "counts": counts,
                             "value": {"records": records, "batches": batches, "payload_sha256": digest.hexdigest()}}
                assert records == size and counts["begins"] == counts["rollbacks"] == size
                assert database == sha("\n".join(engine.lake.conn.iterdump()).encode())
            assert arms["old"]["value"] == arms["new"]["value"]
            assert sources == {p: sha(Path(p).read_bytes()) for p in sources}
            for key in ("payload_reads", "payload_bytes", "begins", "rollbacks"):
                assert arms["old"]["counts"][key] == arms["new"]["counts"][key]
            row = {"layout": layout, "records": size, "database_sha256": database, "sources": sources, "arms": arms}
            report["rows"].append(row)
            (ROOT / "probe-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
            print(json.dumps({"layout": layout, "records": size, "arms": arms}), flush=True)
        finally:
            engine.lake.close()
    assert before == inputs()
    report.update(passed=True, frozen=True)
    (ROOT / "probe-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
