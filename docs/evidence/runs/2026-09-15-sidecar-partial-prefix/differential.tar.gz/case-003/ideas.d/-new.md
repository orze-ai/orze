## idea-side-0000: New first definition
```yaml
seed: 777
```
