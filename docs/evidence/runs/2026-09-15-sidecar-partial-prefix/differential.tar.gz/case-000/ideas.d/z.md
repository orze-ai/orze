## idea-side-0360: Current definition
```yaml
seed: 360
```
## idea-side-0361: Current definition
```yaml
seed: 361
```
## idea-side-0362: Current definition
```yaml
seed: 362
```
## idea-side-0363: Current definition
```yaml
seed: 363
```
## idea-side-0364: Current definition
```yaml
seed: 364
```
## idea-side-0365: Current definition
```yaml
seed: 365
```
## idea-side-0366: Current definition
```yaml
seed: 366
```
## idea-side-0367: Current definition
```yaml
seed: 367
```
## idea-side-0368: Current definition
```yaml
seed: 368
```
## idea-side-0369: Current definition
```yaml
seed: 369
```
## idea-side-0370: Current definition
```yaml
seed: 370
```
## idea-side-0371: Current definition
```yaml
seed: 371
```
## idea-side-0372: Current definition
```yaml
seed: 372
```
## idea-side-0373: Current definition
```yaml
seed: 373
```
## idea-side-0374: Current definition
```yaml
seed: 374
```
## idea-side-0375: Current definition
```yaml
seed: 375
```
