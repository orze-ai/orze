# Ideas
## idea-tail-duplicate: Authored CPU action
```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - import json; from pathlib import Path; Path('answer.json').write_text(json.dumps(sum([2,3,5])))
  inputs: {}
  outputs:
    answer:
      max_bytes: 128
      path: answer.json
  purpose: verify native admission after legacy identity preparation
  timeout_seconds: 4
  version: 1
kind: native_cpu_action
```
