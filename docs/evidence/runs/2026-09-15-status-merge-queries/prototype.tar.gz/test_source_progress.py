"""A first source batch must not execute the full dense-history sort."""
import pytest

from orze.idea_lake import IdeaLake


def test_first_128_source_rows_do_not_require_whole_dense_history(tmp_path):
    lake = IdeaLake(tmp_path / "lake.db")
    statuses = ("queued", "PENDING", "running", "COMPLETED")
    lake.conn.executemany(
        "INSERT INTO ideas(idea_id,title,config,raw_markdown,status) VALUES (?,?,?,'',?)",
        ((f"legacy-{n:05d}", "Metadata", f"seed: {n}\n", statuses[n % 4]) for n in range(5000)),
    )
    lake.conn.commit()
    original = lake.conn
    steps = [0]
    first = []

    def progress():
        steps[0] += 100
        return 0

    class Cursor:
        def __init__(self, cursor):
            self.cursor = cursor

        def fetchmany(self, size):
            rows = self.cursor.fetchmany(size)
            if not first:
                first.append(steps[0])
                original.set_progress_handler(None, 0)
                assert [row["idea_id"] for row in rows] == [f"legacy-{n:05d}" for n in range(128)]
                assert steps[0] < 20000, "first_source_batch_sorts_dense_history"
            return rows

        def close(self):
            original.set_progress_handler(None, 0)
            self.cursor.close()

    class Connection:
        def __getattr__(self, name):
            return getattr(original, name)

        def execute(self, sql, *args):
            source = " ".join(sql.split()).startswith("SELECT idea_id, config") and "FROM ideas" in sql
            if source:
                original.set_progress_handler(progress, 100)
            value = original.execute(sql, *args)
            return Cursor(value) if source else value

    lake.conn = Connection()
    try:
        assert lake._repair_admitted_config_hashes() == 5000
        assert len(first) == 1
        assert lake.conn.execute("SELECT COUNT(*) FROM ideas WHERE config_hash IS NULL").fetchone()[0] == 0
    finally:
        original.set_progress_handler(None, 0)
        lake.close()
