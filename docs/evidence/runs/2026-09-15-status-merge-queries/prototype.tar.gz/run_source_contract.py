"""Current query failure and isolated ordered-merge prototype; no source edits."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import pytest
import orze.core

ROOT = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in {"current", "candidate"}
if mode == "candidate":
    spec = importlib.util.spec_from_file_location("orze.core.config_identity_repair", ROOT / "config_identity_repair.py")
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    sys.modules[spec.name] = candidate
    orze.core.config_identity_repair = candidate
code = pytest.main(["-q", str(ROOT / "test_source_progress.py"), "--tb=short", "-p", "no:cacheprovider",
                    "--basetemp=/tmp/oim-" + mode + "1", "--junitxml=" + str(ROOT / (mode + "-junit.xml"))])
record = {"mode": mode, "exit_code": code,
          "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob("*.py")},
          "limits": ["Exploratory local opcode margin, not a product deadline or universal SQLite performance guarantee.",
                     "No source/test changes in the application workspace."]}
(ROOT / (mode + "-result.json")).write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
raise SystemExit(code)
