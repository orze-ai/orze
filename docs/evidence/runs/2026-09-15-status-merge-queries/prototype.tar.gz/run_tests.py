"""Isolated prototype compatibility, without editing frozen application inputs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import pytest
import orze.core

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "orze"


def fingerprint():
    return {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in ("src", "tests") for p in (REPO / folder).rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}


before = fingerprint()
spec = importlib.util.spec_from_file_location("orze.core.config_identity_repair", ROOT / "config_identity_repair.py")
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
sys.modules[spec.name] = candidate
orze.core.config_identity_repair = candidate
code = pytest.main(["-q", str(ROOT / "test_config_identity_staging.py"), "--tb=short", "-p", "no:cacheprovider",
                    "--basetemp=/tmp/oim-proto1", "--junitxml=" + str(ROOT / "junit.xml")])
assert before == fingerprint()
(ROOT / "tests.json").write_text(json.dumps({"exit_code": code, "frozen_inputs": before,
    "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob("*.py")},
    "limits": ["Prototype loaded only in this process; application files and tests untouched.",
               "Test observer copied and widened to recognize the extra ordering column."]}, indent=2, sort_keys=True) + "\n")
raise SystemExit(code)
