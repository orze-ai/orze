"""Exploratory complete repair and SQLite allocator observation, no product edit.

sqlite3_status64 and SQLITE_STATUS_MEMORY_USED are documented at:
https://www.sqlite.org/c3ref/status.html
https://www.sqlite.org/c3ref/c_status_malloc_count.html
The allocator counter excludes separately configured auxiliary page-cache memory.
It is neither Python allocation nor RSS. No latency claim on this shared host.
"""
import ctypes
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sqlite3
import _sqlite3
import time

from orze import idea_lake
from orze.core import config_identity_repair as current

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("candidate_repair", ROOT / "config_identity_repair.py")
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
lib = ctypes.CDLL(_sqlite3.__file__)
lib.sqlite3_libversion.restype = ctypes.c_char_p
assert lib.sqlite3_libversion().decode() == sqlite3.sqlite_version
status = lib.sqlite3_status64
status.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_longlong), ctypes.POINTER(ctypes.c_longlong), ctypes.c_int]
status.restype = ctypes.c_int


def memory(reset=0):
    used, peak = ctypes.c_longlong(), ctypes.c_longlong()
    assert status(0, ctypes.byref(used), ctypes.byref(peak), reset) == 0
    return {"current": used.value, "peak": peak.value}


def io():
    return {k: int(v) for k, v in (line.split(":") for line in Path("/proc/self/io").read_text().splitlines())}


def main():
    output = ROOT / "repair-fixtures"
    output.mkdir(exist_ok=False)
    report = {"sqlite_version": sqlite3.sqlite_version, "rows": [],
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "prototype_sha256": hashlib.sha256((ROOT / "config_identity_repair.py").read_bytes()).hexdigest(),
              "limits": ["Exploratory observations alongside frozen regressions; not final paired acceptance.",
                         "SQLite allocator highwater excludes auxiliary configured pagecache, Python and other RSS.",
                         "No scientific, production or global resource-bound claim."]}
    for size, payload in ((5000, 1024), (500, 8192)):
        template = Path(f"/tmp/orze-identity-repair-benchmark-v1/{size}-{payload}/input.db")
        row = {"records": size, "payload": payload, "template_sha256": hashlib.sha256(template.read_bytes()).hexdigest(),
               "arms": {"current": [], "candidate": []}, "orders": []}
        expected = None
        for repeat in range(3):
            order = ["current", "candidate"] if repeat % 2 == 0 else ["candidate", "current"]
            row["orders"].append(order)
            for name in order:
                path = output / f"{size}-{payload}-{repeat}-{name}.db"
                shutil.copy2(template, path)
                lake = idea_lake.IdeaLake(path)
                try:
                    before_mem, before_io = memory(1), io()
                    started = time.perf_counter()
                    count = {"current": current, "candidate": candidate}[name].repair_admitted_identities(
                        lake, retry=idea_lake._retry_on_busy, hasher=idea_lake.hash_config, logger=idea_lake.logger)
                    elapsed = time.perf_counter() - started
                    after_mem, after_io = memory(), io()
                    assert count == size
                    digest = hashlib.sha256("\n".join(lake.conn.iterdump()).encode()).hexdigest()
                    expected = digest if expected is None else expected
                    assert expected == digest
                    row["arms"][name].append({"seconds": elapsed, "sqlite_memory_before": before_mem["current"],
                        "sqlite_memory_after": after_mem, "io_delta": {k: after_io[k] - before_io[k] for k in before_io},
                        "database_sha256": digest, "path": str(path)})
                finally:
                    lake.close()
        report["rows"].append(row)
        print(json.dumps(row), flush=True)
        (ROOT / "repair-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    report["passed"] = True
    (ROOT / "repair-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
