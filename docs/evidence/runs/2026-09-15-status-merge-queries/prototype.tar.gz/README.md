# 下一片：旧身份源查询的排序开销（尚未安装）

本目录是 `identity-repair-staging` 全量回归期间的隔离探索。Core／Pro 的产品源码和测试保持冻结；这里的候选文件没有写入产品目录，也不能拿这些结果替代下一片正式验证。

候选仅将源 SELECT 改为四个 `status COLLATE NOCASE = ?` 分支，经 `UNION ALL ... ORDER BY source_rowid` 合并。每个分支可以从现有缺失身份索引按 rowid 读取；本机 SQLite 3.37.2 的计划为 MERGE，没有当前 `IN (...) ORDER BY rowid` 的临时 B 树。仍是一条源 SELECT、一份读快照、完整历史准备、解析后一次主库 writer；第三个 rowid 列不进入暂存数据。

初查保留：

- 100 行、5,000 行混合大小写状态、100,000 行稀疏历史，完整有序输出与当前查询相同。
- 首批 128 行本地 SQLite opcode 对照：5,000 行的有效候选为 4,285 条，约 34,900→3,400；100 行反而约 1,100→2,200。没有把首批改善解释为完整修补提速。
- 复制了本片 12 项事务／失败检查，仅将 source cursor 观察器识别条件扩大到第三个排序列；隔离候选通过。产品测试文件没有改动。
- 单独的 5,000 行密集源进度检查，当前版失败于 40,600 ≥ 20,000 条指令，候选通过。这个裕度依赖本地 SQLite 实现，需审视跨版本测试适用性。
- 完整暂存修补三次交替，5,000 条约 1 KiB 配置约 4.658→4.659 秒，500 条约 8 KiB 配置约 2.700→2.685 秒。与回归有重叠，不能据此声称时间收益。
- 同一进程 SQLite allocator highwater，5,000 条约 4.94→2.81 MB，500 条大配置约 5.01→2.85 MB；进程写入分别约 34.12→28.79 MB、21.86→17.74 MB。它不是 Python 分配或 RSS，也不包含另行配置的辅助 page cache。定义见 [sqlite3_status64](https://www.sqlite.org/c3ref/status.html) 和 [SQLITE_STATUS_MEMORY_USED](https://www.sqlite.org/c3ref/c_status_malloc_count.html)。

下一步先完成并提交当前 `identity-repair-staging` 片，再保存新提交为基线。对候选做正式混合状态／rowid 顺序／并发／重试检查、完整修补与稀疏／小输入负对照（普通耗时与 allocator／Python 观测分开）、实际 CPU 入口与重启、两仓全量与独立进程核验。不要直接把查询计划或本目录的探索结果视作交付完成。

本目录所有 fixture 只属于这次探索；原始输入引用前一片不可变归档对应的 `/tmp` 文件，修补写入本目录独立副本。失败、候选文件、执行脚本与 JSON／XML／日志均保留。
