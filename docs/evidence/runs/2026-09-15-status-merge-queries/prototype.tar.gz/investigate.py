"""Exploratory SQL reads during another slice's frozen regressions; no product edit."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

from orze.idea_lake import IdeaLake
from orze.core import config_identity_repair as current

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("candidate_repair", ROOT / "config_identity_repair.py")
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
QUERIES = {"current": "SELECT idea_id, config " + current._MISSING + "ORDER BY rowid",
           "candidate": candidate._ORDERED_MISSING}


def main():
    root = ROOT / "fixtures"
    root.mkdir(exist_ok=False)
    result = {"sqlite_version": sqlite3.sqlite_version, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "prototype_sha256": hashlib.sha256((ROOT / "config_identity_repair.py").read_bytes()).hexdigest(),
              "cases": [], "limits": ["SQL exploration, not final paired benchmark or product acceptance.",
                 "Runs alongside frozen regressions, so no latency claim.",
                 "Opcode observations apply to this local SQLite runtime.",
                 "Application source and tests untouched; prototype not installed."]}
    for size, stride in ((100, 1), (5000, 1), (100000, 200)):
        lake = IdeaLake(root / f"{size}-{stride}.db")
        expected_ids = []
        try:
            for n in range(size):
                state = current._STATUSES[n % 4].upper() if n % stride == 0 else "archived"
                # Both missing variants must stay in original rowid order.
                identity, source = (None, "recorded") if n % 3 else ("recorded", None)
                if n % 7 == 0:
                    identity, source = "recorded", "recorded"
                lake.conn.execute(
                    "INSERT INTO ideas(idea_id,title,config,raw_markdown,status,config_hash,config_source_sha256) VALUES (?,?,?,'',?,?,?)",
                    (f"idea-{n:07d}", "Imported metadata", f"seed: {n}\n", state, identity, source))
                if state != "archived" and n % 7:
                    expected_ids.append(f"idea-{n:07d}")
            lake.conn.commit()
            arms = {}
            for name, query in QUERIES.items():
                statements = [0]

                def step():
                    statements[0] += 100
                    return 0

                lake.conn.set_progress_handler(step, 100)
                cursor = lake.conn.execute(query, current._STATUSES)
                first = cursor.fetchmany(128)
                lake.conn.set_progress_handler(None, 0)
                cursor.close()
                ids, digest = [], hashlib.sha256()
                cursor = lake.conn.execute(query, current._STATUSES)
                while batch := cursor.fetchmany(128):
                    for row in batch:
                        ids.append(row["idea_id"])
                        digest.update(json.dumps([row["idea_id"], row["config"]], sort_keys=True).encode())
                cursor.close()
                assert ids == expected_ids
                arms[name] = {"first_ids": [r["idea_id"] for r in first], "vm_steps_rounded_down_to_100": statements[0],
                              "records": len(ids), "ordered_output_sha256": digest.hexdigest(),
                              "plan": [list(row) for row in lake.conn.execute("EXPLAIN QUERY PLAN " + query, current._STATUSES)]}
            assert arms["current"]["first_ids"] == arms["candidate"]["first_ids"]
            assert arms["current"]["ordered_output_sha256"] == arms["candidate"]["ordered_output_sha256"]
            result["cases"].append({"total_rows": size, "eligible_stride": stride, "arms": arms})
            print(json.dumps({"total": size, "stride": stride, "records": len(expected_ids),
                              "steps": {k: v["vm_steps_rounded_down_to_100"] for k, v in arms.items()}}), flush=True)
        finally:
            lake.close()
    result["passed"] = True
    (ROOT / "report.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
