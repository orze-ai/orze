"""Auto-generate parameter variation ideas when the queue is empty.

CALLING SPEC:
    generate_variations(results_dir, cfg, lake, max_ideas=5) -> int
        Reads the top completed experiment, generates +-perturbations
        of its numeric config values, and appends them to ideas.md.
        Returns number of ideas generated.

    This is the FREE research loop — no LLM needed, just systematic
    exploration around the current best. orze-pro replaces this with
    intelligent, hypothesis-driven research agents.
"""

import json
import logging
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

import yaml

logger = logging.getLogger("orze")


def _get_best_config(results_dir: Path, cfg: dict,
                     child_counts: Optional[Dict[str, int]] = None,
                     fanout_cap: int = 0) -> Optional[dict]:
    """Find the best completed experiment and return its config.

    Selection is medal-tier first (gold > silver > bronze > above_median > ...),
    then by raw primary metric in the configured sort direction. This avoids
    picking a wrong-direction RMSE (e.g. 12.5) over a 1.0 accuracy gold just
    because the raw value is larger. Reuses orze.core.medal.

    When ``fanout_cap`` > 0, candidates whose existing child-count already
    meets the cap are skipped, so the free loop stops piling every variation
    onto one champion hub and instead branches to other winners / deepens
    lineages — the single biggest lever on research efficiency (Evo Score)."""
    from orze.core.medal import medal_rank
    report_cfg = cfg.get("report", {})
    primary = report_cfg.get("primary_metric", "score")
    sort_asc = report_cfg.get("sort", "descending") == "ascending"
    child_counts = child_counts or {}

    best_key = None  # (medal_rank, primary_val_signed)
    best_cfg = None

    for d in results_dir.iterdir():
        if not d.is_dir() or not d.name.startswith("idea-"):
            continue
        if fanout_cap and child_counts.get(d.name, 0) >= fanout_cap:
            continue
        mf = d / "metrics.json"
        cf = d / "idea_config.yaml"
        if not mf.exists() or not cf.exists():
            continue
        try:
            m = json.loads(mf.read_text())
            if m.get("status") != "COMPLETED":
                continue
            val = m.get(primary)
            if val is None or not isinstance(val, (int, float)):
                continue
            mr = medal_rank(m)
            signed = -val if sort_asc else val
            key = (mr, signed)
            if best_key is None or key > best_key:
                best_key = key
                best_cfg = yaml.safe_load(cf.read_text()) or {}
                best_cfg["_idea_id"] = d.name
                best_cfg["_primary_val"] = val
        except Exception:
            continue

    return best_cfg


# Keys that are safe to perturb (numeric hyperparameters)
_PERTURBABLE = {
    "lora_scale", "lora_rank", "lora_alpha",
    "learning_rate", "lr", "weight_decay",
    "max_new_tokens", "temperature", "top_p",
    "epochs", "num_train_steps", "grad_accum",
    "batch_size", "max_samples",
}

# Keys to never perturb (paths, prompts, identifiers). Projects can extend this
# via cfg["perturb_skip_keys"]; the engine names no domain-specific paths here.
_SKIP = {
    "model_path", "eval_data_dir", "lora_path", "train_data",
    "user_prompt", "system_prompt", "text_normalizer",
    "_idea_id", "_primary_val",
}


def _perturbations(key: str, value) -> List:
    """Generate perturbation values for a config key."""
    if not isinstance(value, (int, float)):
        return []
    if key in _SKIP:
        return []
    if value == 0:
        return []

    # Boolean-like (0/1)
    if isinstance(value, bool):
        return [not value]

    # Scale factors (0-2 range)
    if "scale" in key:
        candidates = [round(value - 0.05, 3), round(value + 0.05, 3)]
        return [c for c in candidates if 0.0 < c <= 2.0 and c != value]

    # Learning rate (log scale)
    if key in ("learning_rate", "lr"):
        return [value * 0.5, value * 2.0]

    # Integer params
    if isinstance(value, int):
        if value >= 4:
            return [max(1, value // 2), value * 2]
        return []

    # Generic float
    return [round(value * 0.8, 6), round(value * 1.2, 6)]


def generate_variations(results_dir: Path, cfg: dict,
                        lake=None, max_ideas: int = 5) -> int:
    """Generate parameter variation ideas from the best experiment."""
    from orze.core.research_policy import batch_decision_contract_required
    if batch_decision_contract_required(cfg):
        logger.info(
            "Decision-contract policy disables contractless auto-variations")
        return 0
    # Fan-out cap: don't keep perturbing an already-saturated parent. Skipping
    # saturated hubs spreads search across winners and deepens lineages, which
    # is the highest-leverage fix for research efficiency (Evo Score). 0/absent
    # disables. Co-located with the Evo Score config under report.search_path.
    fanout_cap = int(
        ((cfg.get("report", {}) or {}).get("search_path", {}) or {})
        .get("fanout_cap", 12) or 0
    )
    child_counts = lake.child_counts() if (lake and fanout_cap) else {}
    best = _get_best_config(results_dir, cfg,
                            child_counts=child_counts, fanout_cap=fanout_cap)
    if best is None:
        # Every candidate is capped out (or none completed). Fall back to the
        # uncapped best so the loop still makes progress.
        if fanout_cap:
            best = _get_best_config(results_dir, cfg)
        if best is None:
            return 0

    parent_id = best.pop("_idea_id", "?")
    parent_val = best.pop("_primary_val", "?")

    # Find perturbable keys
    skip_keys = set(_SKIP) | {str(k) for k in (cfg.get("perturb_skip_keys") or [])}
    variations = []
    for key, value in best.items():
        if key in skip_keys:
            continue
        if key not in _PERTURBABLE and not isinstance(value, (int, float)):
            continue
        for new_val in _perturbations(key, value):
            var = dict(best)
            var[key] = new_val
            variations.append((key, value, new_val, var))

    if not variations:
        logger.debug("No perturbable parameters found in best config")
        return 0

    # Deduplicate against existing ideas in the lake
    if lake:
        existing = lake.get_all_ids()
    else:
        existing = set()

    # Generate idea markdown
    ideas_path = Path(cfg.get("ideas_file", "ideas.md"))
    generated = 0
    lines = []

    for key, old_val, new_val, var_cfg in variations[:max_ideas]:
        # Create a unique idea ID
        import hashlib
        cfg_hash = hashlib.md5(
            json.dumps(var_cfg, sort_keys=True).encode()
        ).hexdigest()[:6]
        idea_id = f"idea-v{cfg_hash}"

        if idea_id in existing:
            continue

        direction = "+" if new_val > old_val else "-"
        title = f"Variation: {key}={new_val} ({direction} from {old_val}, parent: {parent_id})"

        # Every variation must carry a rationale (the evolution contract): state
        # the concrete change vs the parent and why it is worth testing.
        rationale = (
            f"Perturb `{key}` from {old_val} to {new_val} ({direction}) on the "
            f"current best config ({parent_id}, primary={parent_val}). Tests the "
            f"sensitivity of the result to `{key}`; a single-parameter change keeps "
            f"the effect attributable."
        )

        # Remove non-config keys
        clean_cfg = {k: v for k, v in var_cfg.items()
                     if not k.startswith("_")}

        lines.append(f"\n## {idea_id}: {title}")
        lines.append(f"- **Priority**: low")
        lines.append(f"- **Approach Family**: optimization")
        lines.append(f"- **Parent**: {parent_id}")
        lines.append(f"- **Hypothesis**: {rationale}")
        lines.append(f"```yaml")
        lines.append(yaml.dump(clean_cfg, default_flow_style=False).rstrip())
        lines.append(f"```")
        lines.append("")
        generated += 1

    if lines:
        with open(ideas_path, "a", encoding="utf-8") as f:
            f.write("\n".join(lines))
        logger.info("Auto-generated %d parameter variations from %s (%.4f)",
                    generated, parent_id, parent_val)

    return generated
