"""GPU management utilities via nvidia-smi.

CALLING SPEC:
    get_gpu_memory_used(gpu_id: int) -> Optional[int]
        Query memory used in MiB for a single GPU. Returns None on failure.

    _eval_already_running(idea_id: str, cfg: dict = None) -> bool
        Check via pgrep whether an eval process is already running for the
        given idea_id. Uses cfg['eval_script'] to determine the process
        name pattern.

    _query_gpu_details() -> List[dict]
        Query nvidia-smi for all GPUs. Returns list of dicts with keys:
        index, name, memory_used_mib, memory_total_mib, utilization_pct,
        temperature_c. Returns [] on failure.
"""
import subprocess
import logging
from typing import List, Optional

logger = logging.getLogger("orze")


def get_gpu_memory_used(gpu_id: int) -> Optional[int]:
    """Get GPU memory used in MiB. Returns None on failure."""
    from orze.engine.controller_probe import ControllerProbeHOLD, run_probe

    try:
        result = run_probe(
            ["nvidia-smi", "--query-gpu=memory.used",
             "--format=csv,noheader,nounits", f"--id={gpu_id}"],
            capture_output=True, text=True, timeout=10,
        )
        return int(result.stdout.strip())
    except ControllerProbeHOLD:
        raise
    except Exception:
        return None


def _eval_already_running(idea_id: str, cfg: dict = None) -> bool:
    """Check if an eval process is already running for this idea."""
    from orze.engine.controller_probe import ControllerProbeHOLD, run_probe

    eval_script = "eval"
    if cfg:
        script_path = cfg.get("eval_script", "")
        if script_path:
            from pathlib import Path
            eval_script = Path(script_path).stem
    try:
        result = run_probe(
            ["pgrep", "-f", f"{eval_script}.*{idea_id}"],
            capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0
    except ControllerProbeHOLD:
        raise
    except Exception:
        return False


def detect_all_gpus(gpu_ids: Optional[List[int]] = None) -> List[int]:
    """Detect available GPU indices, optionally within an exact scope."""
    from orze.engine.controller_probe import ControllerProbeHOLD, run_probe

    try:
        command = [
            "nvidia-smi", "--query-gpu=index", "--format=csv,noheader",
        ]
        if gpu_ids is not None:
            scoped = sorted(set(gpu_ids))
            if not scoped:
                return []
            command.append("--id=" + ",".join(str(gpu) for gpu in scoped))
        result = run_probe(
            command,
            capture_output=True, text=True, timeout=10,
        )
        allowed = set(gpu_ids) if gpu_ids is not None else None
        return [
            int(value) for value in result.stdout.strip().splitlines()
            if value.strip()
            and (allowed is None or int(value.strip()) in allowed)
        ]
    except ControllerProbeHOLD:
        raise
    except Exception:
        return []


def get_free_gpus(gpu_ids: List[int], active: dict,
                  mem_threshold: int = 2000) -> List[int]:
    """Return GPUs not in active dict and with low memory usage."""
    free = []
    for g in gpu_ids:
        if g in active:
            continue
        mem_used = get_gpu_memory_used(g)
        if mem_used is not None and mem_used > mem_threshold:
            continue
        free.append(g)
    return free


def _query_gpu_details(gpu_ids: Optional[List[int]] = None) -> List[dict]:
    """Query per-GPU stats, restricted to ``gpu_ids`` when supplied."""
    from orze.engine.controller_probe import ControllerProbeHOLD, run_probe

    try:
        command = [
            "nvidia-smi",
            "--query-gpu=index,name,memory.used,memory.total,utilization.gpu,temperature.gpu",
            "--format=csv,noheader,nounits",
        ]
        if gpu_ids is not None:
            scoped = sorted(set(gpu_ids))
            if not scoped:
                return []
            command.append("--id=" + ",".join(str(gpu) for gpu in scoped))
        result = run_probe(
            command,
            capture_output=True, text=True, timeout=10,
        )
        allowed = set(gpu_ids) if gpu_ids is not None else None
        gpus = []
        for line in result.stdout.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 6 and (
                    allowed is None or int(parts[0]) in allowed):
                gpus.append({
                    "index": int(parts[0]),
                    "name": parts[1],
                    "memory_used_mib": int(parts[2]),
                    "memory_total_mib": int(parts[3]),
                    "utilization_pct": int(parts[4]),
                    "temperature_c": int(parts[5]),
                })
        return gpus
    except ControllerProbeHOLD:
        raise
    except Exception:
        return []
