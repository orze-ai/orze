"""CPU phase of Orze's existing foreground loop (no second runner).

The queue policy is deliberately small. Its decisions and execution envelopes
are durable; no ML roles, GPU discovery, implicit evaluations or auto-repair
are hidden inside this resource adapter. Unknown work is retained, not adopted.
"""
from __future__ import annotations

import atexit
import copy
import logging
from pathlib import Path
import signal
import socket
import threading
import time
import uuid

import yaml

from orze.core.cpu_execution import (
    CPUExecutionError, action_policy, cpu_execution, execution_fingerprint,
    runtime_lease_seconds,
)

logger = logging.getLogger("orze")


class _ShutdownHandler:
    """Invocation-owned hook; retired predecessors never revive an engine."""

    def __init__(self, engine):
        self.engine = engine
        self.previous = {}

    def __call__(self, signum, frame):
        if self.engine is not None:
            self.engine._shutdown(signum, frame)

    def predecessor(self, sig):
        previous = self.previous[sig]
        while type(previous) is _ShutdownHandler and previous.engine is None:
            previous = previous.previous[sig]
        return previous


class QueuePolicy:
    """A real policy consumer, not a scientific convergence judgment."""
    def __init__(self, declaration):
        self.declaration = dict(declaration)

    def decide(self, snapshot, budget):
        now = snapshot["now"]
        if budget["stopped"]:
            return {"kind": "Stop", "reason": "scope_stopped", "wakeup": None}
        if snapshot["queue"]:
            remaining = budget["remaining_wall_seconds"]
            eligible = next((task for task in snapshot["queue"] if
                remaining is None or task["action"]["timeout_seconds"] <= remaining), None)
            if eligible is not None and budget["free_slots"] > 0:
                return {"kind": "Execute", "task_id": eligible["idea_id"]}
            if eligible is None and budget["active_reservations"] == 0:
                return {"kind": "Stop", "reason": "wall_envelope_exhausted", "wakeup": None}
            return {"kind": "Wait", "reason": "cpu_resource_or_budget_unavailable",
                    "wakeup": now + self.declaration["wait_seconds"]}
        scope_active = snapshot["active"] or budget["active_reservations"] > 0
        if not scope_active and self.declaration["idle"] == "stop":
            return {"kind": "Stop", "reason": "queue_drained", "wakeup": None}
        return {"kind": "Wait", "reason": "actions_running" if scope_active else "queue_empty",
                "wakeup": now + self.declaration["wait_seconds"]}


def initialize(engine, gpu_ids, cfg, once):
    from orze.core.config import _validate_config
    from orze.core.control_outcome import require_controller_start_allowed
    from orze.idea_lake import IdeaLake
    from orze.core.research_interfaces import BoundPolicy, capture_interfaces
    if type(gpu_ids) is not list or gpu_ids:
        raise CPUExecutionError("execution: CPU actions require an empty physical GPU scope")
    errors, _ = _validate_config(cfg)
    if errors:
        raise CPUExecutionError("execution: invalid CPU configuration: " + "; ".join(errors))
    engine.cfg = cfg
    engine.once = once
    engine.results_dir = Path(cfg["results_dir"]).absolute()
    require_controller_start_allowed(engine.results_dir)
    engine._cpu_cfg_fingerprint = execution_fingerprint(cfg)
    engine.gpu_ids = []
    engine.active = {}
    engine.active_evals = {}
    engine.active_roles = {}
    engine._gpu_leases = None
    engine._controller_profile_enabled = False
    engine._hostname = socket.gethostname()
    engine._instance_uuid = uuid.uuid4().hex
    engine.running = True
    engine.iteration = 0
    engine._stop_event = threading.Event()
    engine._cpu_handles = {}
    engine._cpu_closed = False
    engine._cpu_scope = None
    engine._cpu_wait_until = 0.0
    engine._cpu_once_dispatched = False
    _release_evidence_scan(engine)
    try:
        engine._cpu_interfaces = capture_interfaces(cfg)
        engine._cpu_policy = (QueuePolicy(action_policy(cfg)) if engine._cpu_interfaces is None
                              else BoundPolicy(engine._cpu_interfaces))
    except Exception as exc:
        raise CPUExecutionError("execution: interface initialization rejected") from exc
    engine.results_dir.mkdir(parents=True, exist_ok=True)
    # CPU execution cannot downgrade to text-only lifecycle or copy an old DB.
    if not cfg.get("idea_lake_db"):
        raise CPUExecutionError("execution: CPU actions require an IdeaLake path")
    engine.lake = IdeaLake(cfg["idea_lake_db"])
    engine._cpu_signal_handlers = {}
    handler = _ShutdownHandler(engine)
    for sig in (signal.SIGINT, signal.SIGTERM):
        previous = signal.signal(sig, handler)
        handler.previous[sig] = previous
        engine._cpu_signal_handlers[sig] = (previous, handler)

    # unregister compares callbacks by equality. A unique wrapper is an
    # invocation-owned token, unlike another caller's equal bound method.
    def cleanup():
        engine._atexit_cleanup()

    engine._cpu_exit_callback = cleanup
    atexit.register(cleanup)


def require_admission(engine):
    from orze.core.control_outcome import require_controller_start_allowed
    from orze.core.cpu_action_budget import snapshot
    if not engine.running or engine._stop_event.is_set():
        raise CPUExecutionError("execution: controller is stopping")
    if (cpu_execution(engine.cfg) is None or execution_fingerprint(engine.cfg)
            != engine._cpu_cfg_fingerprint):
        raise CPUExecutionError("execution: CPU invocation changed")
    require_controller_start_allowed(engine.results_dir)
    if engine._cpu_scope is not None and snapshot(engine.lake, engine._cpu_scope)["stopped"]:
        raise CPUExecutionError("execution: CPU policy has stopped this scope")


def start(engine):
    from orze.core.cpu_action_budget import initialize as initialize_budget, reconcile_confirmed_terminals
    from orze.engine.health import HealthMonitor
    require_admission(engine)
    engine._cpu_scope = initialize_budget(engine.lake, engine.results_dir, cpu_execution(engine.cfg))
    engine._cpu_recovery = reconcile_confirmed_terminals(engine.lake, engine._cpu_scope)
    engine._health_monitor = HealthMonitor(engine.results_dir)
    logger.info("Orze CPU actions: %s, declared slots=%s (no GPU resource allocation)",
                engine.results_dir, engine._cpu_execution["slots"])


def iteration(engine):
    """One existing-loop iteration; waiting uses the shared interruptible event."""
    from orze.core import cpu_action_budget as budget
    from orze.core.cpu_action_contract import validate_action
    from orze.core.control_outcome import ControllerStopHOLD, require_controller_start_allowed
    from orze.engine import native_cpu_action as executor
    from orze.engine.health import check_disk_space
    from orze.engine.idea_ingress import ingest_ideas_source
    from orze.engine.scheduler import claim
    from orze.core.research_interfaces import parse_domain_task, prepare_domain_run

    for key, (handle, permit) in list(engine._cpu_handles.items()):
        terminal = executor.harvest(handle, engine.results_dir, engine.cfg,
                                   lake=engine.lake, permit=permit)
        if terminal is not None:
            del engine._cpu_handles[key]
            logger.info("CPU action %s: %s", handle.idea_id, terminal.get("outcome"))
    try:
        require_controller_start_allowed(engine.results_dir)
    except ControllerStopHOLD:
        budget.record_decision(engine.lake, engine._cpu_scope,
            {"kind": "Stop", "reason": "operator_stop", "wakeup": None})
        return False
    if engine.once and engine._cpu_once_dispatched:
        if not engine._cpu_handles:
            return False
        engine._stop_event.wait(0.05)
        return True
    if not engine._health_monitor.check_before_write():
        delay = engine._health_monitor.retry_delay
        engine._stop_event.wait(min(delay, 0.05) if engine._cpu_handles else delay)
        return True
    # A durable Wait is not a lease expiry or permission to repeat an action.
    remaining = engine._cpu_wait_until - time.monotonic()
    if remaining > 0:
        engine._stop_event.wait(min(remaining, 0.05) if engine._cpu_handles else remaining)
        return True
    if len(engine._cpu_handles) >= engine._cpu_execution["slots"]:
        engine._stop_event.wait(0.05)
        return True
    require_admission(engine)
    interfaces = engine._cpu_interfaces
    paged = interfaces is not None and engine._cpu_policy.declaration["version"] == 2
    proposal_paged = paged and "proposal_page_size" in engine._cpu_policy.declaration
    evidence_request = getattr(engine, "_cpu_evidence_request", None) if paged else None
    proposal_request = getattr(engine, "_cpu_proposal_request", None) if proposal_paged else None
    continuing = evidence_request is not None or proposal_request is not None
    if not continuing:
        ingest_ideas_source(engine, engine.cfg)
        queue = engine.lake.get_queue(limit=2000 if interfaces is None else 32)
    else:
        # A read-only continuation retains only this bounded private queue.
        # Ingress can write the Lake and must not silently restart a scan.
        queue = copy.deepcopy(engine._cpu_evidence_queue)
    domain_enabled = engine.cfg.get("action_domain") is not None
    for queued in queue:
        row = engine.lake.get(queued["idea_id"])
        if row is None or row["kind"] != "native_cpu_action":
            raise CPUExecutionError("execution: CPU queue contains a non-CPU task")
        try:
            if domain_enabled:
                request = parse_domain_task(row["config"])
                queued["_raw_config"] = row["config"]
                queued["request"] = request
                queued["action"] = {"timeout_seconds": request["timeout_seconds"]}
            else:
                parsed = yaml.safe_load(row["config"])
                if type(parsed) is not dict:
                    raise ValueError("not a mapping")
                if parsed.get("domain_request") is not None:
                    raise ValueError("domain request has no selected domain")
                queued["action"] = validate_action(parsed.get("action"))
        except (ValueError, TypeError, yaml.YAMLError) as exc:
            raise CPUExecutionError("execution: queued CPU action declaration is invalid") from exc
    snapshot = {"queue": queue, "active": bool(engine._cpu_handles), "now": time.time()}
    try:
        if interfaces is not None:
            from orze.engine.cpu_policy_evidence import EvidencePager, recorded_evidence
            from orze.engine.cpu_proposals import ProposalPager, recorded_proposals
            snapshot["queue"] = [{"idea_id": item["idea_id"],
                "action": {"timeout_seconds": item["action"]["timeout_seconds"]},
                "request": item.get("request", item["action"])} for item in queue]
            if paged:
                if not continuing:
                    engine._cpu_evidence_pager = EvidencePager(engine.lake, engine.results_dir,
                        limit=engine._cpu_policy.declaration["evidence_page_size"])
                if proposal_request is not None:
                    # Switching channels must not present cached artifact state
                    # as newly checked evidence. Reselect the exact bounded refs
                    # (including unavailable refs), without consuming its cursor.
                    previous = engine._cpu_evidence_view
                    recorded = previous["recorded_evidence"]
                    refs = [item["ref"] for item in recorded["results"] + recorded["unavailable"]]
                    if refs:
                        evidence_view = engine._cpu_evidence_pager.read(refs=copy.deepcopy(refs))
                    else:
                        engine._cpu_evidence_pager.verify()
                        evidence_view = copy.deepcopy(previous)
                else:
                    evidence_view = engine._cpu_evidence_pager.read(**(evidence_request or {}))
                engine._cpu_evidence_view = copy.deepcopy(evidence_view)
                snapshot.update(evidence_view)
            else:
                snapshot["recorded_evidence"] = recorded_evidence(engine.lake, engine.results_dir)
            if proposal_paged:
                if not continuing:
                    engine._cpu_proposal_pager = ProposalPager(engine.lake, engine.results_dir,
                        limit=engine._cpu_policy.declaration["proposal_page_size"],
                        guard=engine._cpu_evidence_pager)
                if not continuing or proposal_request is not None:
                    engine._cpu_proposal_view = engine._cpu_proposal_pager.read(**(proposal_request or {}))
                else:
                    engine._cpu_proposal_pager.verify()
                snapshot.update(copy.deepcopy(engine._cpu_proposal_view))
            else:
                snapshot["recorded_proposals"] = recorded_proposals(engine.lake, engine.results_dir)
        # This private copy is not passed to a trusted callback. The selected
        # source metadata is still independently verified by normal admission.
        proposal_snapshot = copy.deepcopy(snapshot)
        decision = engine._cpu_policy.decide(snapshot, budget.snapshot(engine.lake, engine._cpu_scope))
        if paged:
            # Even a trusted callback cannot turn a changed read revision into
            # execution, a further page, or a permanent Stop decision.
            engine._cpu_evidence_pager.verify()
            if proposal_paged:
                engine._cpu_proposal_pager.verify()
    except Exception as exc:
        raise CPUExecutionError("execution: research policy decision rejected") from exc
    if decision["kind"] in {"ReadEvidence", "SelectEvidence", "ReadProposals", "SelectProposals"}:
        engine._cpu_evidence_request = ({"cursor": decision["cursor"]}
            if decision["kind"] == "ReadEvidence" else
            {"refs": copy.deepcopy(decision["refs"])} if decision["kind"] == "SelectEvidence" else None)
        engine._cpu_proposal_request = ({"cursor": decision["cursor"]}
            if decision["kind"] == "ReadProposals" else
            {"request_ids": copy.deepcopy(decision["request_ids"])}
            if decision["kind"] == "SelectProposals" else None)
        engine._cpu_evidence_queue = copy.deepcopy(queue)
        # No decision ledger entry, permit, claim, worker, or once latch: these
        # are bounded queries within the same policy decision, not CPU actions.
        return True
    _release_evidence_scan(engine)
    if decision["kind"] == "Propose":
        from orze.core.research_interfaces import proposal_sources
        from orze.engine.cpu_proposals import propose
        try:
            require_admission(engine)
            if not domain_enabled:
                raise CPUExecutionError("execution: proposed task has no selected Domain")
            if check_disk_space(engine.results_dir, engine.cfg.get("min_disk_gb", 5)):
                result = propose(engine.lake, engine.results_dir, engine.cfg, decision,
                    expected_sources=proposal_sources(proposal_snapshot, decision))
                reason = "proposal_" + result["status"]
            else:
                reason = "disk_space"
        except Exception as exc:
            raise CPUExecutionError("execution: policy proposal admission rejected") from exc
        # Normal admission records an outcome, not execution or a free permit.
        # A retry returns the original outcome; every proposal yields the loop.
        decision = {"kind": "Wait", "reason": reason,
                    "wakeup": time.time() + engine._cpu_policy.declaration["wait_seconds"]}
    if decision["kind"] == "Replicate":
        from orze.engine.replication import request_replication
        try:
            require_admission(engine)
            if check_disk_space(engine.results_dir, engine.cfg.get("min_disk_gb", 5)):
                result = request_replication(decision["source_ref"]["task_id"],
                    engine.results_dir, engine.cfg, engine.lake,
                    request_id=decision["request_id"], reason=decision["reason"],
                    expected_source_ref=decision["source_ref"])
                reason = "replication_" + result["status"]
            else:
                reason = "disk_space"
        except Exception as exc:
            raise CPUExecutionError("execution: policy replication request rejected") from exc
        # The request ledger owns the exact key/source/target/rationale. It
        # creates only a queued task, never a worker or a free execution permit.
        # Even an idempotent replay yields before asking the policy again.
        decision = {"kind": "Wait", "reason": reason,
                    "wakeup": time.time() + engine._cpu_policy.declaration["wait_seconds"]}
    if decision["kind"] == "Execute":
        idea_id = decision["task_id"]
        action = next(task["action"] for task in queue if task["idea_id"] == idea_id)
        if not check_disk_space(engine.results_dir, engine.cfg.get("min_disk_gb", 5)):
            decision = {"kind": "Wait", "reason": "disk_space",
                        "wakeup": time.time() + engine._cpu_policy.declaration["wait_seconds"]}
        else:
            domain_run = None
            if domain_enabled:
                from orze.engine.cpu_action_sources import capture_sources
                item = next(task for task in queue if task["idea_id"] == idea_id)
                try:
                    sources = capture_sources(engine.lake, engine.results_dir,
                                              item["request"]["input_artifact_ids"])
                    domain_run = prepare_domain_run(interfaces, item["_raw_config"], sources)
                    action = domain_run.action
                except Exception as exc:
                    raise CPUExecutionError("execution: domain preparation rejected") from exc
            from orze.engine.cpu_replication import authorization
            try:
                authorization(engine.lake, idea_id, engine.results_dir, engine.cfg,
                              action=action, domain_run=domain_run)
            except Exception as exc:
                raise CPUExecutionError("execution: CPU replication authorization rejected") from exc
            # Reject a static lease/action mismatch before consuming a slot or
            # claim. Native launch independently repeats this dynamic check.
            runtime_lease_seconds(engine.cfg, action["timeout_seconds"])
            permit = budget.reserve(engine.lake, engine._cpu_scope, idea_id, action["timeout_seconds"])
            if permit is None:
                decision = {"kind": "Wait", "reason": "cpu_resource_or_budget_unavailable",
                            "wakeup": time.time() + engine._cpu_policy.declaration["wait_seconds"]}
            else:
                require_admission(engine)
                if not claim(idea_id, engine.results_dir, None, lake=engine.lake, resource="cpu"):
                    raise CPUExecutionError("execution: reserved action claim unconfirmed; budget retained")
                try:
                    extension = {} if domain_run is None else {"domain_run": domain_run}
                    handle = executor.launch(idea_id, engine.results_dir, engine.cfg,
                        lake=engine.lake, action=action, permit=permit,
                        admission=lambda: require_admission(engine), **extension)
                except BaseException as exc:
                    handle = getattr(exc, "cpu_action_handle", None)
                    if handle is not None:
                        engine._cpu_handles[permit["reservation_id"]] = (handle, permit)
                    raise
                engine._cpu_handles[permit["reservation_id"]] = (handle, permit)
                engine._cpu_once_dispatched = True
                return True
    budget.record_decision(engine.lake, engine._cpu_scope, decision)
    logger.info("CPU policy %s: %s", decision["kind"], decision["reason"])
    if decision["kind"] in {"Pause", "Stop"} or engine.once:
        return False
    engine._cpu_wait_until = time.monotonic() + max(0, decision["wakeup"] - time.time())
    return True


def _release_evidence_scan(engine):
    engine._cpu_evidence_pager = None
    engine._cpu_evidence_request = None
    engine._cpu_evidence_queue = None
    engine._cpu_evidence_view = None
    engine._cpu_proposal_pager = None
    engine._cpu_proposal_request = None
    engine._cpu_proposal_view = None


def close(engine):
    """Only captured action owners are stopped; no PID discovery or adoption."""
    if engine._cpu_closed:
        return
    engine._cpu_closed = True
    _release_evidence_scan(engine)
    engine.running = False
    engine._stop_event.set()
    failures = []
    from orze.engine import native_cpu_action as executor
    for key, (handle, permit) in list(engine._cpu_handles.items()):
        try:
            executor.stop(handle, engine.results_dir, engine.cfg,
                          lake=engine.lake, permit=permit)
            del engine._cpu_handles[key]
        except BaseException as exc:
            failures.append(type(exc).__name__)
            logger.error("CPU action %s remains HOLD; reservation retained", handle.idea_id)
    try:
        engine.lake.close()
    except BaseException as exc:
        failures.append(type(exc).__name__)
    if failures:
        raise CPUExecutionError("execution: CPU cleanup remains unconfirmed: " + ",".join(failures))
    # The close-attempt latch alone is not proof of cleanup. Only this success
    # path releases invocation roots; unknown native owners keep their captures.
    # Never overwrite a signal handler installed by another caller after ours.
    for sig, (previous, installed) in engine._cpu_signal_handlers.items():
        if signal.getsignal(sig) is installed:
            signal.signal(sig, installed.predecessor(sig))
    atexit.unregister(engine._cpu_exit_callback)
    for _, installed in engine._cpu_signal_handlers.values():
        installed.engine = None
    engine._cpu_exit_callback = None
    engine._cpu_signal_handlers = {}
    engine._cpu_interfaces = None
    engine._cpu_policy = None
