"""Notification delivery to Slack, Discord, Telegram, and generic webhooks.

CALLING SPEC:
    notify(event: str, data: dict, cfg: dict) -> None
        Send notifications for an event to all configured channels. Never
        raises. event is one of: completed, failed, new_best, report,
        started, shutdown, heartbeat, milestone, disk_warning, stall,
        role_summary, upgrading, watchdog_restart, watchdog_failure_loop,
        plateau, needs_intervention.
        data is event-specific (e.g. idea_id, title, metric_value, rank,
        leaderboard). cfg must contain 'notifications' key with 'enabled',
        'on' (event filter list), and 'channels' (list of channel configs
        with type: slack|discord|telegram|webhook).

    startup_canary(cfg: dict) -> dict
        Probe each configured channel with a low-noise canary message and
        return a per-channel delivery report:
            {channel_label: {"delivered": bool, "last_error": str|None,
                             "type": str}}
        Never raises. The orchestrator surfaces this on status.json under
        ``notification_health`` and (when ``notifications.startup_canary``
        is true — default true) exits nonzero if any channel failed so
        systemd / loop-restart picks it up. Closes the meta-audit blind
        spot that delivery was previously trust-based.

    validate_channels(cfg: dict) -> dict
        Cheap, no-network re-validation of channel configs. Returns the
        same shape as ``startup_canary`` but ``delivered`` is True iff
        every URL/token field for the channel is fully resolved (no
        leftover ``${VAR}`` placeholder, no empty/None). Designed to run
        after every config hot-reload so an env-expansion regression
        (the bug a5eb216 fixed, plus its near siblings) surfaces in
        seconds instead of waiting for the next hourly heartbeat to
        404. Doesn't replace ``startup_canary`` — that still owns
        end-to-end delivery proof at boot.
"""
import datetime
import html as html_mod
import json
import logging
import math
import re
import socket
import urllib.request
from typing import Dict, Optional, Tuple

# Same shape as orze.core.config._UNRESOLVED_VAR_RE — a literal ${VAR}
# left in any field means env-expansion didn't run on that load path
# (or the env var was unset when it did). Either way the URL will 404
# at notify() time, silently.
_UNRESOLVED_VAR_RE = re.compile(r"\$\{[A-Z_][A-Z0-9_]*\}")

from orze import __version__
from orze.reporting.leaderboard import _format_report_text

logger = logging.getLogger("orze")


def _safe_watchdog_failure_data(data: dict) -> dict:
    """Return the closed, content-safe payload allowed off-host."""
    host_raw = str(data.get("host", socket.gethostname()))
    host = "".join(
        ch if ch.isalnum() or ch in "._-" else "_" for ch in host_raw
    )[:128] or "unknown"
    code_raw = str(data.get("failure_code", ""))
    code = (
        code_raw if re.fullmatch(r"[a-z0-9_]{1,64}", code_raw)
        else "unclassified_failure"
    )
    count_raw = data.get("consecutive_count")
    count = (
        count_raw
        if isinstance(count_raw, int) and not isinstance(count_raw, bool)
        and 0 <= count_raw <= 2**63 - 1
        else "?"
    )
    fingerprint_raw = str(data.get("fingerprint", ""))
    fingerprint = (
        fingerprint_raw[:12]
        if re.fullmatch(r"[0-9a-f]{12,64}", fingerprint_raw)
        else "unknown"
    )
    result = {
        "host": host,
        "failure_code": code,
        "consecutive_count": count,
        "fingerprint": fingerprint,
    }
    first_seen = data.get("first_seen_epoch")
    if (
        isinstance(first_seen, (int, float))
        and not isinstance(first_seen, bool)
        and math.isfinite(float(first_seen))
        and float(first_seen) >= 0
    ):
        result["first_seen_epoch"] = float(first_seen)
    return result


def _evidence_context(data: dict, escape_fn=str) -> str:
    scope = data.get("evidence_scope")
    if not scope:
        return ""
    mode = data.get("selection_mode")
    value = str(scope) + (f"/{mode}" if mode else "")
    return f" [{escape_fn(value)}]"


# Runtime per-channel delivery state, keyed by channel label (same key
# space as ``startup_canary`` / ``validate_channels`` outputs). Updated
# from inside ``notify()`` after every send so silent post-boot drift —
# e.g. a token rotated or revoked between boot and the first hourly
# heartbeat — surfaces on ``status.json["notification_health"]`` within
# one notification cycle instead of staying frozen at the boot snapshot.
#
# Pre-fix behavior: ``notification_health`` was set once at boot from
# the canary and only refreshed on config hot-reload. A telegram 404 on
# every heartbeat could fire indefinitely while the dashboard kept
# showing ``delivered: true`` from boot. Operators trusting status.json
# would not notice until they manually grep'd orze.log.
_RUNTIME_HEALTH: Dict[str, Dict[str, object]] = {}


def get_runtime_health() -> Dict[str, Dict[str, object]]:
    """Return a snapshot of the latest per-channel delivery state.

    Returns a shallow copy so callers can merge into status.json without
    racing the dispatch path. Each entry has the same shape as
    ``startup_canary``: ``{type, delivered, last_error}``. Empty dict
    when no notify() has fired yet (boot canary still authoritative).
    """
    return {k: dict(v) for k, v in _RUNTIME_HEALTH.items()}


def _record_runtime(label: str, ch_type: str, ok: bool,
                    err: Optional[str]) -> None:
    """Record a delivery outcome for ``label``. Never raises."""
    try:
        _RUNTIME_HEALTH[label] = {
            "type": ch_type,
            "delivered": bool(ok),
            "last_error": err,
        }
    except Exception:
        # State write must never break the dispatch path.
        pass


def _notify_send(url: str, payload: dict,
                 headers: Optional[Dict[str, str]] = None,
                 timeout: int = 10) -> Tuple[bool, Optional[str]]:
    """POST JSON payload to a URL. Never raises.

    Returns (ok, last_error). ok is True iff a 2xx response came back;
    last_error is a human-readable cause on failure (network error,
    timeout, non-2xx status). Callers that don't care about the result
    can ignore the return value — the previous void contract is
    preserved at runtime since this never raises.
    """
    try:
        data = json.dumps(payload).encode("utf-8")
        req_headers = {
            "Content-Type": "application/json",
            "User-Agent": f"orze/{__version__}",
        }
        if headers:
            req_headers.update(headers)
        req = urllib.request.Request(url, data=data, method="POST",
                                     headers=req_headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", 200)
            if 200 <= int(status) < 300:
                return True, None
            return False, f"HTTP {status}"
    except urllib.request.HTTPError as e:
        # urllib treats non-2xx as exceptions; record status + first 200B
        try:
            body = e.read().decode("utf-8", errors="replace")[:200]
        except Exception:
            body = ""
        msg = f"HTTP {e.code} {body}".strip()
        logger.error("Notification delivery failed (%s): %s",
                     url[:60], msg)
        return False, msg
    except Exception as e:
        msg = f"{type(e).__name__}: {e}"
        logger.error("Notification delivery failed (%s): %s",
                     url[:60], msg)
        return False, msg


def _channel_label(ch: dict, idx: int) -> str:
    """Stable label for status.json keys; prefers explicit ``name``, else
    falls back to ``<type>[<idx>]``."""
    if isinstance(ch, dict):
        nm = ch.get("name")
        if nm:
            return str(nm)
        t = ch.get("type", "webhook")
        return f"{t}[{idx}]"
    return f"channel[{idx}]"


def startup_canary(cfg: dict) -> Dict[str, Dict[str, object]]:
    """Probe each configured channel with a canary; return delivery report.

    Never raises. Returns ``{}`` when notifications are disabled or no
    channels are configured. Each entry has ``{type, delivered,
    last_error}``. Format is intentionally minimal — same payload shape
    as the ``started`` event so a passing canary looks like a normal
    boot ping to operators.
    """
    out: Dict[str, Dict[str, object]] = {}
    try:
        ncfg = cfg.get("notifications") or {}
        if not ncfg.get("enabled", False):
            return out
        channels = ncfg.get("channels") or []
        if not channels:
            return out
        data = {
            "host": socket.gethostname(),
            "message": (f"orze v{__version__} startup canary — "
                        "if you see this, delivery works"),
        }
        for idx, ch in enumerate(channels):
            label = _channel_label(ch, idx)
            ch_type = (ch or {}).get("type", "webhook")
            try:
                if ch_type == "slack":
                    ok, err = _notify_send(ch["webhook_url"],
                                           _format_slack("started", data))
                elif ch_type == "discord":
                    ok, err = _notify_send(ch["webhook_url"],
                                           _format_discord("started", data))
                elif ch_type == "telegram":
                    url, payload = _format_telegram("started", data, ch)
                    ok, err = _notify_send(url, payload)
                elif ch_type == "webhook":
                    payload = {"event": "started", "data": data,
                               "host": socket.gethostname(),
                               "timestamp":
                                   datetime.datetime.now().isoformat()}
                    ok, err = _notify_send(ch["url"], payload,
                                           headers=ch.get("headers"))
                else:
                    ok, err = False, f"unknown channel type {ch_type!r}"
            except Exception as e:
                ok, err = False, f"{type(e).__name__}: {e}"
            out[label] = {
                "type": ch_type,
                "delivered": bool(ok),
                "last_error": err,
            }
            if not ok:
                logger.error(
                    "Startup canary FAILED for channel %s (%s): %s",
                    label, ch_type, err)
            else:
                logger.info(
                    "Startup canary delivered to %s (%s)", label, ch_type)
    except Exception as e:
        logger.error("startup_canary dispatch error: %s: %s",
                     type(e).__name__, e)
    return out


# Per-channel-type list of fields that must be fully resolved (non-empty,
# no ${VAR} placeholder) before the channel can deliver. Kept here so
# adding a new channel type only touches one place.
_CHANNEL_REQUIRED_FIELDS = {
    "slack":    ("webhook_url",),
    "discord":  ("webhook_url",),
    "telegram": ("bot_token", "chat_id"),
    "webhook":  ("url",),
}


def _has_unresolved(val: object) -> bool:
    """True iff val is a string with a ${VAR} placeholder still in it."""
    return isinstance(val, str) and bool(_UNRESOLVED_VAR_RE.search(val))


def validate_channels(cfg: dict) -> Dict[str, Dict[str, object]]:
    """Re-validate channel configs without sending a network probe.

    Returns the same shape as :func:`startup_canary`. ``delivered`` is
    True iff every required URL/token field for the channel is present
    and free of ``${VAR}`` placeholders. Logs an ERROR on each failed
    channel so an env-expansion regression (a5eb216 and its near
    siblings) surfaces immediately instead of waiting for the next
    hourly heartbeat to 404 silently.

    Designed to be called after every config hot-reload — cheap, never
    raises, no I/O. Does NOT replace startup_canary; that still owns
    end-to-end delivery proof at boot.
    """
    out: Dict[str, Dict[str, object]] = {}
    try:
        ncfg = cfg.get("notifications") or {}
        if not ncfg.get("enabled", False):
            return out
        channels = ncfg.get("channels") or []
        if not channels:
            return out
        for idx, ch in enumerate(channels):
            label = _channel_label(ch, idx)
            ch = ch or {}
            ch_type = ch.get("type", "webhook")
            required = _CHANNEL_REQUIRED_FIELDS.get(ch_type)
            if required is None:
                out[label] = {
                    "type": ch_type,
                    "delivered": False,
                    "last_error": f"unknown channel type {ch_type!r}",
                }
                continue
            missing = [f for f in required if not ch.get(f)]
            unresolved = [f for f in required if _has_unresolved(ch.get(f))]
            if missing:
                err = f"missing required field(s): {', '.join(missing)}"
                ok = False
            elif unresolved:
                # The exact failure mode of the a5eb216 hot-reload bug:
                # ${TELEGRAM_BOT_TOKEN} survives into the live URL.
                err = (f"unresolved ${{VAR}} in: {', '.join(unresolved)} "
                       "(env var not set, or hot-reload didn't expand)")
                ok = False
            else:
                err = None
                ok = True
            out[label] = {
                "type": ch_type,
                "delivered": bool(ok),
                "last_error": err,
            }
            if not ok:
                logger.error(
                    "Channel validation FAILED for %s (%s): %s",
                    label, ch_type, err)
    except Exception as e:
        logger.error("validate_channels error: %s: %s",
                     type(e).__name__, e)
    return out


def _format_leaderboard(data: dict, bold_fn=str, escape_fn=str) -> str:
    """Format top 10 leaderboard lines from data['leaderboard'].
    escape_fn is applied to all text content (needed for Telegram HTML)."""
    board = data.get("leaderboard", [])
    if not board:
        return ""
    metric = escape_fn(str(data.get("metric_name", "score")))
    lines = [
        f"\nLocal top {len(board)} ({metric})"
        f"{_evidence_context(data, escape_fn)}:"
    ]
    for i, entry in enumerate(board, 1):
        val = entry.get("value")
        if isinstance(val, float):
            val_str = escape_fn(f"{val:.4f}")
        elif isinstance(val, (int,)):
            val_str = escape_fn(str(val))
        elif val is not None:
            val_str = escape_fn(str(val))
        else:
            val_str = "—"
        marker = escape_fn(" <-" if entry["id"] == data.get("idea_id") else "")
        title = escape_fn(str(entry.get("title", ""))[:30])
        line = f"#{i} {escape_fn(str(entry['id']))}: {val_str} {title}{marker}"
        if i == 1:
            line = bold_fn(line)
        lines.append(line)

    # Append view leaderboards (e.g. edge)
    for vname, vdata in (data.get("view_leaderboards") or {}).items():
        vtitle = escape_fn(str(vdata.get("title", vname)))
        entries = vdata.get("entries") or []
        if not entries:
            continue
        lines.append(f"\n{bold_fn(vtitle)} (top {len(entries)}):")
        for i, entry in enumerate(entries, 1):
            val = entry.get("value")
            val_str = escape_fn(f"{val:.4f}" if isinstance(val, float) else str(val))
            marker = escape_fn(" <-" if entry["id"] == data.get("idea_id") else "")
            title = escape_fn(str(entry.get("title", ""))[:30])
            line = f"#{i} {escape_fn(str(entry['id']))}: {val_str} {title}{marker}"
            if i == 1:
                line = bold_fn(line)
            lines.append(line)

    return "\n".join(lines)


def _format_slack(event: str, data: dict) -> dict:
    """Format notification for Slack webhook."""
    if event == "report":
        return {"text": f"```\n{_format_report_text(data)}\n```"}
    if event in ("started", "shutdown"):
        icon = ":arrow_forward:" if event == "started" else ":stop_button:"
        host = data.get("host", socket.gethostname())
        return {"text": f"{icon} *Orze {event}* on `{host}`\n{data.get('message', '')}"}
    if event == "heartbeat":
        host = data.get("host", socket.gethostname())
        completed = data.get("completed", 0)
        failed = data.get("failed", 0)
        queued = data.get("queued", 0)
        running = data.get("running", data.get("training", 0) + data.get("eval", 0))
        total_gpus = data.get("total_gpus", running + data.get("free", 0))
        active_gpus = total_gpus - data.get("free", 0)
        lines = [
            f":bar_chart: *Orze Status* — `{host}`",
            (f":white_check_mark: {completed} completed | :x: {failed} failed | "
             f":hourglass_flowing_sand: {queued} queued | :arrows_counterclockwise: {running} running"),
        ]
        best_val = data.get("best_val")
        if best_val is not None:
            metric = data.get("best_metric", "score")
            best_id = data.get("best_id", "?")
            val_str = f"{best_val:.4f}" if isinstance(best_val, float) else str(best_val)
            lines.append(f":trophy: Best: {val_str} {metric} (`{best_id}`)")
        lines.append(f":computer: GPUs: {active_gpus}/{total_gpus} active | Up {data.get('uptime', '?')}")
        if data.get("rate"):
            lines.append(f":chart_with_upwards_trend: {data['rate']}")
        return {"text": "\n".join(lines)}
    if event == "milestone":
        return {"text": f":dart: *Milestone: {data.get('count', '?')} experiments completed!*"}
    if event == "disk_warning":
        return {"text": f":warning: *Low disk* on `{data.get('host', socket.gethostname())}` — "
                        f"only {data.get('free_gb', '?')}GB free"}
    if event == "stall":
        return {"text": f":rotating_light: *{data.get('reason', 'Stalled')}*: "
                        f"`{data.get('idea_id', '?')}` on GPU {data.get('gpu', '?')}"}
    if event == "role_summary":
        bd = data.get("breakdown") or str(data.get("new_ideas", 0))
        return {"text": f":test_tube: *{data.get('role', '?')}* finished | "
                        f"{bd} new ideas | {data.get('queued', '?')} queued"}
    if event == "upgrading":
        host = data.get("host", socket.gethostname())
        return {"text": f":arrows_counterclockwise: *Orze upgrading* on `{host}`: "
                        f"v{data.get('from_version', '?')} -> v{data.get('to_version', '?')}"}
    if event == "watchdog_restart":
        host = data.get("host", socket.gethostname())
        reason = data.get("reason", "unknown")
        return {"text": f":dog: *Watchdog restarted orze* on `{host}` (reason: {reason})"}
    if event == "watchdog_failure_loop":
        data = _safe_watchdog_failure_data(data)
        host = str(data.get("host", socket.gethostname()))[:128]
        code = str(data.get("failure_code", "unknown"))[:64]
        count = data.get("consecutive_count", "?")
        fingerprint = str(data.get("fingerprint", "unknown"))[:12]
        return {"text": (
            f":rotating_light: *Repeated Orze startup failure* on `{host}`\n"
            f"code=`{code}` consecutive={count} fingerprint=`{fingerprint}`"
        )}
    if event == "plateau":
        return {"text": f":warning: *Plateau detected*: {data.get('message', 'No improvement')}"}
    if event == "needs_intervention":
        role = data.get("role", "?")
        reason = data.get("reason", "unknown")
        evidence = str(data.get("evidence", ""))[:200]
        log_tail = str(data.get("log_tail", ""))[:500]
        host = data.get("host", socket.gethostname())
        pid = data.get("pid", "?")
        return {"text": (f":warning: *{role}* needs human intervention\n"
                         f"*Reason:* {reason}\n"
                         f"*Evidence:* {evidence}\n"
                         f"*Log tail:*\n```\n{log_tail}\n```\n"
                         f"*Host:* `{host}` (pid {pid})")}
    if event == "new_best":
        prev = data.get("prev_best_id", "none")
        text = (f":trophy: *NEW LOCAL BEST*"
                f"{_evidence_context(data)} `{data['idea_id']}`: {data['title']}\n"
                f"{data['metric_name']}: *{data['metric_value']}*"
                f" (was `{prev}`)")
    elif event == "failed":
        err = str(data.get("error") or "unknown")[:200]
        text = (f":x: *FAILED* `{data['idea_id']}`: {data['title']}\n"
                f"Error: {err}")
    else:
        t_str = ""
        try:
            t = data.get("training_time")
            if t is not None:
                t_str = f" in {float(t):.0f}s"
        except (ValueError, TypeError):
            pass
        text = (f":white_check_mark: *Completed* `{data.get('idea_id', '?')}`: "
                f"{data.get('title', '?')}\n"
                f"{data.get('metric_name', '?')}: {data.get('metric_value', '?')}"
                f" (local rank #{data.get('rank', '?')}"
                f"{_evidence_context(data)})"
                f"{t_str}")
    if not data.get("summary_only"):
        text += _format_leaderboard(data, lambda s: f"*{s}*")
    return {"text": text}


def _format_discord(event: str, data: dict) -> dict:
    """Format notification for Discord webhook."""
    if event == "report":
        return {"content": f"```\n{_format_report_text(data)}\n```"}
    if event in ("started", "shutdown"):
        icon = "\u25b6\ufe0f" if event == "started" else "\u23f9\ufe0f"
        host = data.get("host", socket.gethostname())
        return {"content": f"{icon} **Orze {event}** on `{host}`\n{data.get('message', '')}"}
    if event == "heartbeat":
        host = data.get("host", socket.gethostname())
        completed = data.get("completed", 0)
        failed = data.get("failed", 0)
        queued = data.get("queued", 0)
        running = data.get("running", data.get("training", 0) + data.get("eval", 0))
        total_gpus = data.get("total_gpus", running + data.get("free", 0))
        active_gpus = total_gpus - data.get("free", 0)
        lines = [
            f"\U0001f4ca **Orze Status** \u2014 `{host}`",
            (f"\u2705 {completed} completed | \u274c {failed} failed | "
             f"\u23f3 {queued} queued | \U0001f504 {running} running"),
        ]
        best_val = data.get("best_val")
        if best_val is not None:
            metric = data.get("best_metric", "score")
            best_id = data.get("best_id", "?")
            val_str = f"{best_val:.4f}" if isinstance(best_val, float) else str(best_val)
            lines.append(f"\U0001f3c6 Best: {val_str} {metric} (`{best_id}`)")
        lines.append(f"\U0001f4bb GPUs: {active_gpus}/{total_gpus} active | Up {data.get('uptime', '?')}")
        if data.get("rate"):
            lines.append(f"\U0001f4c8 {data['rate']}")
        return {"content": "\n".join(lines)}
    if event == "milestone":
        return {"content": f"\U0001f3af **Milestone: {data.get('count', '?')} experiments completed!**"}
    if event == "disk_warning":
        return {"content": f"\u26a0\ufe0f **Low disk** on `{data.get('host', socket.gethostname())}` — "
                           f"only {data.get('free_gb', '?')}GB free"}
    if event == "stall":
        return {"content": f"\U0001f6a8 **{data.get('reason', 'Stalled')}**: "
                           f"`{data.get('idea_id', '?')}` on GPU {data.get('gpu', '?')}"}
    if event == "role_summary":
        bd = data.get("breakdown") or str(data.get("new_ideas", 0))
        return {"content": f"\U0001f9ea **{data.get('role', '?')}** finished | "
                           f"{bd} new ideas | {data.get('queued', '?')} queued"}
    if event == "upgrading":
        host = data.get("host", socket.gethostname())
        return {"content": f"\U0001f504 **Orze upgrading** on `{host}`: "
                           f"v{data.get('from_version', '?')} -> v{data.get('to_version', '?')}"}
    if event == "watchdog_restart":
        host = data.get("host", socket.gethostname())
        reason = data.get("reason", "unknown")
        return {"content": f"\U0001f415 **Watchdog restarted orze** on `{host}` (reason: {reason})"}
    if event == "watchdog_failure_loop":
        data = _safe_watchdog_failure_data(data)
        host = str(data.get("host", socket.gethostname()))[:128]
        code = str(data.get("failure_code", "unknown"))[:64]
        count = data.get("consecutive_count", "?")
        fingerprint = str(data.get("fingerprint", "unknown"))[:12]
        return {"content": (
            f"\U0001f6a8 **Repeated Orze startup failure** on `{host}`\n"
            f"code=`{code}` consecutive={count} fingerprint=`{fingerprint}`"
        )}
    if event == "plateau":
        return {"content": f"\u26a0\ufe0f **Plateau detected**: {data.get('message', 'No improvement')}"}
    if event == "needs_intervention":
        role = data.get("role", "?")
        reason = data.get("reason", "unknown")
        evidence = str(data.get("evidence", ""))[:200]
        log_tail = str(data.get("log_tail", ""))[:500]
        host = data.get("host", socket.gethostname())
        pid = data.get("pid", "?")
        return {"content": (f"\u26a0\ufe0f **{role}** needs human intervention\n"
                            f"**Reason:** {reason}\n"
                            f"**Evidence:** {evidence}\n"
                            f"**Log tail:**\n```\n{log_tail}\n```\n"
                            f"**Host:** `{host}` (pid {pid})")}
    if event == "new_best":
        prev = data.get("prev_best_id", "none")
        content = (f"**NEW LOCAL BEST**{_evidence_context(data)} "
                   f"`{data['idea_id']}`: {data['title']}\n"
                   f"{data['metric_name']}: **{data['metric_value']}**"
                   f" (was `{prev}`)")
    elif event == "failed":
        err = str(data.get("error") or "unknown")[:200]
        content = (f"**FAILED** `{data['idea_id']}`: {data['title']}\n"
                   f"Error: {err}")
    else:
        t_str = ""
        try:
            t = data.get("training_time")
            if t is not None:
                t_str = f" in {float(t):.0f}s"
        except (ValueError, TypeError):
            pass
        content = (f"**Completed** `{data.get('idea_id', '?')}`: {data.get('title', '?')}\n"
                   f"{data.get('metric_name', '?')}: {data.get('metric_value', '?')}"
                   f" (local rank #{data.get('rank', '?')}"
                   f"{_evidence_context(data)})"
                   f"{t_str}")
    if not data.get("summary_only"):
        content += _format_leaderboard(data, lambda s: f"**{s}**")
    return {"content": content}


def _format_telegram(event: str, data: dict, channel_cfg: dict) -> tuple:
    """Format notification for Telegram Bot API using HTML parse_mode.
    Returns (url, payload). Uses HTML to avoid MarkdownV2 escaping issues."""
    esc = html_mod.escape
    token = channel_cfg["bot_token"]
    chat_id = channel_cfg["chat_id"]
    url = f"https://api.telegram.org/bot{token}/sendMessage"

    if event == "report":
        text = f"<pre>\n{esc(_format_report_text(data))}\n</pre>"
        return url, {"chat_id": chat_id, "text": text,
                     "parse_mode": "HTML"}

    if event in ("started", "shutdown"):
        host = esc(data.get("host", socket.gethostname()))
        msg = esc(str(data.get("message", "")))
        icon = "\u25b6\ufe0f" if event == "started" else "\u23f9\ufe0f"
        text = f"{icon} <b>Orze {event}</b> on <code>{host}</code>\n{msg}"
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "heartbeat":
        host = esc(data.get("host", socket.gethostname()))
        completed = data.get("completed", 0)
        failed = data.get("failed", 0)
        queued = data.get("queued", 0)
        running = data.get("running", data.get("training", 0) + data.get("eval", 0))
        total_gpus = data.get("total_gpus", running + data.get("free", 0))
        uptime = esc(str(data.get("uptime", "?")))
        active_runs = data.get("active_runs") or []

        # Stall detection: 0 completions + experiments running longer than timeout
        # Use configured timeout (default 6h) — stall means oldest experiment
        # exceeded the timeout, not just "hasn't finished yet".
        rate_str = str(data.get("rate", ""))
        rate_num = 0
        try:
            rate_num = int(rate_str.split()[0])
        except (ValueError, IndexError):
            pass
        max_elapsed = max((r.get("elapsed_min", 0) for r in active_runs),
                         default=0)
        stall_threshold = data.get("timeout", 21600) / 60  # seconds -> minutes
        is_stalled = (rate_num == 0 and active_runs
                      and max_elapsed >= stall_threshold)

        # Header with health status
        if is_stalled:
            lines = [
                f"\u26a0\ufe0f <b>Orze</b> \u2014 <code>{host}</code> \u2014 {uptime}"
                f" \u2014 <b>STALLED</b>",
            ]
        else:
            lines = [
                f"\U0001f4ca <b>Orze</b> \u2014 <code>{host}</code> \u2014 {uptime}",
            ]

        # Best result with target comparison
        best_val = data.get("best_val")
        est_label = data.get("estimate_label")
        metric_name = esc(str(data.get("best_metric", "score")))
        lower_is_better = data.get("sort", "descending") == "ascending"
        if best_val is not None:
            best_id = esc(str(data.get("best_id", "?")))
            if isinstance(best_val, float):
                val_str = f"{best_val:.2f}"
            else:
                val_str = str(best_val)
            tag = f" [{esc(est_label)}]" if est_label else ""
            target = data.get("target")
            if target is not None:
                beats_target = (best_val <= target if lower_is_better
                                else best_val >= target)
                if isinstance(best_val, (int, float)) and beats_target:
                    status = "\u2705"
                else:
                    gap = best_val - target if isinstance(best_val, (int, float)) else 0
                    status = f"\u274c {gap:+.2f}"
                lines.append(
                    f"\U0001f3c6 <b>{esc(val_str)}</b>{tag} {metric_name} "
                    f"(<code>{best_id}</code>) "
                    f"| target {target} {status}")
            else:
                lines.append(
                    f"\U0001f3c6 <b>{esc(val_str)}</b>{tag} {metric_name} "
                    f"(<code>{best_id}</code>)")

        # Verified results (full-scale) with per-dataset breakdown
        verified = data.get("verified")
        if verified:
            v_primary = verified.get("primary") or verified.get("avg_wer")
            if v_primary is not None:
                v_label = " [full]" if est_label else ""
                v_target = verified.get("target")
                gap_str = ""
                if v_target and isinstance(v_primary, (int, float)):
                    gap = v_primary - v_target
                    gap_str = f" | gap {gap:+.2f}"
                lines.append(
                    f"\U0001f3af Verified: <b>{v_primary:.2f}</b>"
                    f"{v_label}{gap_str}")
                per_ds = verified.get("per_dataset")
                if per_ds:
                    parts = [f"{esc(k)}={v:.1f}" for k, v
                             in sorted(per_ds.items())]
                    lines.append(f"  {' | '.join(parts)}")

        # Progress line with normalized rate and completion %
        rate = data.get("rate", "")
        hb_interval = data.get("heartbeat_interval", 3600)
        rate_display = esc(str(rate))
        if rate_num > 0 and hb_interval > 0:
            per_hr = rate_num / (hb_interval / 3600)
            rate_display += f" ({per_hr:.1f}/hr)"
        total_work = completed + failed + queued + running
        pct_str = ""
        if total_work > 0:
            pct = completed / total_work * 100
            pct_str = f" | {pct:.0f}% done"
        lines.append(
            f"\U0001f4c8 {completed} done | {failed} fail | "
            f"{queued} queued | {rate_display}{pct_str}")

        # GPU status — labeled clearly
        n_free = data.get("free", 0)
        n_training = data.get("training", 0)
        n_eval = data.get("eval", 0)
        eval_backlog = data.get("eval_backlog", 0)
        n_active = running
        if n_training and n_eval:
            gpu_line = (f"\U0001f5a5 {n_active} active "
                        f"({n_training} train, {n_eval} eval), "
                        f"{n_free} idle / {total_gpus} GPUs")
        elif n_active:
            gpu_line = (f"\U0001f5a5 {n_active} active, "
                        f"{n_free} idle / {total_gpus} GPUs")
        else:
            gpu_line = f"\U0001f5a5 {total_gpus} GPUs, all idle"
        if eval_backlog:
            gpu_line += f" | {eval_backlog} eval pending"
        lines.append(gpu_line)

        # Active experiments — compact (truncated IDs, count if many)
        if active_runs:
            if len(active_runs) > 4:
                oldest = max(r.get("elapsed_min", 0) for r in active_runs)
                newest = min(r.get("elapsed_min", 0) for r in active_runs)
                if oldest >= 60:
                    oldest_str = f"{oldest / 60:.1f}h"
                else:
                    oldest_str = f"{oldest:.0f}m"
                if newest >= 60:
                    newest_str = f"{newest / 60:.1f}h"
                else:
                    newest_str = f"{newest:.0f}m"
                lines.append(
                    f"\u23f3 {len(active_runs)} running "
                    f"({newest_str}\u2013{oldest_str})")
            else:
                run_parts = []
                for r in active_runs:
                    rid = esc(str(r.get("idea_id", "?")))
                    elapsed = r.get("elapsed_min", 0)
                    phase = r.get("phase", "")
                    if elapsed >= 60:
                        t = f"{elapsed / 60:.1f}h"
                    else:
                        t = f"{elapsed:.0f}m"
                    suffix = "/eval" if phase == "eval" else ""
                    run_parts.append(f"{rid}({t}{suffix})")
                lines.append(f"\u23f3 {' '.join(run_parts)}")

        # Stall warning detail
        if is_stalled:
            lines.append(
                f"\u26a0\ufe0f <b>0 completions with "
                f"{len(active_runs)} running ({max_elapsed:.0f}m oldest)</b>")

        # Next up in queue
        next_queue = data.get("next_queue") or []
        if next_queue:
            q_parts = []
            for q in next_queue:
                qid = esc(str(q.get("id", "?")))
                qtitle = esc(str(q.get("title", ""))[:30])
                q_parts.append(f"<code>{qid}</code> {qtitle}")
            lines.append(f"\U0001f4cb Next up:\n  " + "\n  ".join(q_parts))

        return url, {"chat_id": chat_id, "text": "\n".join(lines),
                     "parse_mode": "HTML"}

    if event == "milestone":
        text = (f"\U0001f3af <b>Milestone: {esc(str(data.get('count', '?')))} "
                f"experiments completed!</b>")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "disk_warning":
        text = (f"\u26a0\ufe0f <b>Low disk</b> on <code>"
                f"{esc(data.get('host', socket.gethostname()))}</code>\n"
                f"Only {data.get('free_gb', '?')}GB free")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "stall":
        reason = esc(str(data.get("reason", "stalled")))
        text = (f"\U0001f6a8 <b>{reason}</b>: <code>"
                f"{esc(str(data.get('idea_id', '?')))}</code> on GPU "
                f"{data.get('gpu', '?')}")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "role_summary":
        role = esc(str(data.get("role", "?")))
        bd = esc(str(data.get("breakdown") or data.get("new_ideas", 0)))
        text = (f"\U0001f9ea <b>{role}</b> finished | "
                f"{bd} new ideas | "
                f"{data.get('queued', '?')} queued")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "upgrading":
        host = esc(data.get("host", socket.gethostname()))
        frm = esc(str(data.get("from_version", "?")))
        to = esc(str(data.get("to_version", "?")))
        text = (f"\U0001f504 <b>Orze upgrading</b> on <code>{host}</code>\n"
                f"v{frm} -> v{to}")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "watchdog_restart":
        host = esc(data.get("host", socket.gethostname()))
        reason = esc(str(data.get("reason", "unknown")))
        text = (f"\U0001f415 <b>Watchdog restarted orze</b> on "
                f"<code>{host}</code> (reason: {reason})")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "watchdog_failure_loop":
        data = _safe_watchdog_failure_data(data)
        host = esc(str(data.get("host", socket.gethostname()))[:128])
        code = esc(str(data.get("failure_code", "unknown"))[:64])
        count = esc(str(data.get("consecutive_count", "?"))[:32])
        fingerprint = esc(str(data.get("fingerprint", "unknown"))[:12])
        text = (
            f"\U0001f6a8 <b>Repeated Orze startup failure</b> on "
            f"<code>{host}</code>\ncode=<code>{code}</code> "
            f"consecutive={count} fingerprint=<code>{fingerprint}</code>"
        )
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "plateau":
        msg = esc(str(data.get("message", "No improvement")))
        text = f"\u26a0\ufe0f <b>Plateau detected</b>: {msg}"
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    if event == "needs_intervention":
        role = esc(str(data.get("role", "?")))
        reason = esc(str(data.get("reason", "unknown")))
        evidence = esc(str(data.get("evidence", ""))[:200])
        log_tail = esc(str(data.get("log_tail", ""))[:500])
        host = esc(data.get("host", socket.gethostname()))
        pid = esc(str(data.get("pid", "?")))
        text = (f"\u26a0\ufe0f <b>{role}</b> needs human intervention\n"
                f"<b>Reason:</b> {reason}\n"
                f"<b>Evidence:</b> <code>{evidence}</code>\n"
                f"<b>Log tail:</b>\n<pre>{log_tail}</pre>\n"
                f"<b>Host:</b> <code>{host}</code> (pid {pid})")
        return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}

    idea_id = esc(str(data.get("idea_id", "")))
    title = esc(str(data.get("title", "")))

    if event == "new_best":
        prev_id = esc(str(data.get("prev_best_id", "none")))
        metric = esc(str(data.get("metric_name", "")))
        val = data.get("metric_value", "")
        val_str = esc(str(val))
        # Show improvement delta
        prev_val = data.get("prev_best_val")
        delta_str = ""
        try:
            if prev_val is not None:
                curr_f = float(val)
                prev_f = float(prev_val)
                delta = curr_f - prev_f
                delta_str = f" | \u0394 {delta:+.2f}%"
        except (ValueError, TypeError):
            pass
        text = (f"\U0001f3c6\U0001f3c6\U0001f3c6 <b>NEW LOCAL BEST</b>"
                f"{_evidence_context(data, esc)}\n"
                f"<code>{idea_id}</code>: {title}\n"
                f"{metric}: <b>{val_str}</b>"
                f" (was {esc(str(prev_val or '?'))}% <code>{prev_id}</code>)"
                f"{delta_str}")
    elif event == "failed":
        err = esc(str(data.get("error") or "unknown")[:200])
        text = (f"\u274c <code>{idea_id}</code>: {title}\n"
                f"{err}")
    else:
        t_str = ""
        try:
            t = data.get("training_time")
            if t is not None:
                secs = float(t)
                if secs >= 3600:
                    t_str = f" | {secs / 3600:.1f}h"
                else:
                    t_str = f" | {secs / 60:.0f}m"
        except (ValueError, TypeError):
            pass
        metric = esc(str(data.get("metric_name", "")))
        val = esc(str(data.get("metric_value", "")))
        rank = data.get("rank", "?")
        rank_str = esc(str(rank))
        # Rank emoji
        if isinstance(rank, int) and rank <= 3:
            medal = ["\U0001f947", "\U0001f948", "\U0001f949"][rank - 1]
        else:
            medal = "\u2705"
        text = (f"{medal} <code>{idea_id}</code>: {title}\n"
                f"{metric}: <b>{val}</b> (local #{rank_str}"
                f"{_evidence_context(data, esc)}){t_str}")
    if not data.get("summary_only"):
        text += _format_leaderboard(data, lambda s: f"<b>{s}</b>", escape_fn=esc)

    return url, {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}


def notify(event: str, data: dict, cfg: dict):
    """Send notifications for an event to all configured channels. Never raises."""
    try:
        ncfg = cfg.get("notifications") or {}
        if not ncfg.get("enabled", False):
            return

        if event == "watchdog_failure_loop":
            data = _safe_watchdog_failure_data(data)

        logger.info("Sending notification for event: %s", event)

        # Health alerts always pass through, regardless of any role-summary
        # suppression flag. Post-mortem 2026-04: a coarse
        # suppress_role_summary=true also silenced role_circuit_breaker for
        # 5 days. The two concerns are now strictly separated.
        _ALWAYS_DELIVER = {"role_circuit_breaker", "role_degraded"}

        # Suppress role_summary if configured. The flag was renamed to
        # ``suppress_role_completion_pings`` to clarify intent (it was
        # never about health). Old name accepted for one release with a
        # DeprecationWarning so existing orze.yaml files keep working.
        if event == "role_summary" and event not in _ALWAYS_DELIVER:
            suppress = ncfg.get("suppress_role_completion_pings", None)
            if suppress is None and "suppress_role_summary" in ncfg:
                import warnings as _warnings
                _warnings.warn(
                    "notifications.suppress_role_summary is deprecated; "
                    "rename to notifications.suppress_role_completion_pings "
                    "(same behavior). The old key will be removed in a "
                    "future release.",
                    DeprecationWarning, stacklevel=2,
                )
                suppress = ncfg.get("suppress_role_summary", False)
            if suppress:
                logger.debug(
                    "Suppressing role_summary notification (configured)")
                return

        # Health events (role_circuit_breaker, role_degraded) are in the
        # default subscription set so silent role death surfaces even
        # when an operator hasn't explicitly listed them. See post-mortem
        # 2026-04 (5-day silent steering-stack failure).
        global_on = ncfg.get("on") or [
            "completed", "failed", "new_best",
            "role_circuit_breaker", "role_degraded",
        ]
        # Lifecycle/system events always delivered (not filtered)
        lifecycle = {"started", "shutdown", "heartbeat", "milestone",
                     "disk_warning", "stall", "role_summary", "upgrading",
                     "watchdog_restart", "watchdog_failure_loop"}

        for idx, ch in enumerate(ncfg.get("channels") or []):
            ch_on = ch.get("on") or global_on
            if event not in lifecycle and event not in ch_on:
                continue

            ch_type = ch.get("type", "webhook")
            label = _channel_label(ch, idx)
            # Capture (ok, err) on every send and surface it in
            # ``_RUNTIME_HEALTH`` so status.json["notification_health"]
            # tracks live delivery, not just the boot canary snapshot.
            ok, err = False, "unsent"
            # Short-circuit channels whose required URL/token field still
            # contains an unresolved ${VAR}. Without this gate every
            # event (heartbeat, sealed_file_changed, etc.) blasts an
            # HTTP 404 against api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/...
            # and floods the log with a hard error class — even though
            # validate_channels already flagged the misconfig at boot
            # and on every hot-reload. _CHANNEL_REQUIRED_FIELDS /
            # _has_unresolved are the same predicates validate_channels
            # uses, kept in one place so a new channel type only needs
            # one edit.
            required = _CHANNEL_REQUIRED_FIELDS.get(ch_type)
            if required is not None:
                bad = [f for f in required
                       if not ch.get(f) or _has_unresolved(ch.get(f))]
                if bad:
                    err = (f"channel not deliverable — unresolved/missing "
                           f"field(s): {', '.join(bad)}")
                    logger.debug(
                        "Skipping notify on %s (%s): %s",
                        label, ch_type, err)
                    _record_runtime(label, ch_type, False, err)
                    continue
            if ch_type == "slack":
                ok, err = _notify_send(ch["webhook_url"],
                                       _format_slack(event, data))
            elif ch_type == "discord":
                ok, err = _notify_send(ch["webhook_url"],
                                       _format_discord(event, data))
            elif ch_type == "telegram":
                url, payload = _format_telegram(event, data, ch)
                ok, err = _notify_send(url, payload)
            elif ch_type == "webhook":
                payload = {"event": event, "data": data,
                           "host": socket.gethostname(),
                           "timestamp": datetime.datetime.now().isoformat()}
                ok, err = _notify_send(ch["url"], payload,
                                       headers=ch.get("headers"))
            else:
                logger.warning("Unknown notification channel: %s", ch_type)
                err = f"unknown channel type {ch_type!r}"
            _record_runtime(label, ch_type, ok, err)
    except Exception as e:
        logger.error("Notification dispatch error: %s: %s", type(e).__name__, e)
