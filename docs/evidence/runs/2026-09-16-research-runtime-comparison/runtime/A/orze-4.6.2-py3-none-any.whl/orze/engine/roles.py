"""Role process lifecycle management and ideas.md corruption guard.

CALLING SPEC:
    check_active_roles(active_roles: Dict[str, RoleProcess],
                       ideas_file: str = "ideas.md")
        -> list[tuple[str, Outcome]]
        Poll all running role processes. Kill any that exceed their timeout.
        Returns list of (role_name, outcome) for roles that finished this call.
        Outcome is one of OUTCOME_OK / OUTCOME_TIMEOUT / OUTCOME_ERROR /
        OUTCOME_SOFT_FAILURE (see Outcome enum below).
        Releases filesystem locks and checks ideas.md integrity after each role.

    Outcome (IntEnum)
        OUTCOME_OK             = 0  process exited 0 and produced its output
        OUTCOME_TIMEOUT        = 1  killed after exceeding rp.timeout
        OUTCOME_ERROR          = 2  process exited non-zero for a real reason
                                     (script bug, config error, etc.)
        OUTCOME_SOFT_FAILURE   = 3  exit 0 but writes_ideas_file=True role
                                     did not modify ideas.md
        OUTCOME_RATE_LIMITED   = 4  process exited non-zero because the
                                     backing LLM hit a billing / usage /
                                     rate-limit ceiling (Claude CLI
                                     "out of extra usage", Gemini 429,
                                     Anthropic 529, etc.). Transient —
                                     do NOT count toward circuit-breaker
                                     consecutive_failures; just retry on
                                     the next scheduled cycle.

    is_success(outcome) -> bool
        Back-compat helper: True iff outcome == OUTCOME_OK.
"""
import logging
import re
import shutil
import time
from enum import IntEnum
from pathlib import Path
from typing import Dict

from orze.engine.process import (
    RoleProcess,
    _terminate_and_reap,
    process_tree_cpu_ticks,
    progress_paths_fingerprint,
    refresh_role_process_descendants,
    terminate_role_process,
)
from orze.core.fs import _fs_unlock
from orze.core.ideas import count_idea_headings
from orze.engine.role_delivery import settle_role_delivery
from orze.engine.role_result import native_role_outcome

logger = logging.getLogger("orze")


class Outcome(IntEnum):
    OK = 0
    TIMEOUT = 1
    ERROR = 2
    SOFT_FAILURE = 3
    RATE_LIMITED = 4


OUTCOME_OK = Outcome.OK
OUTCOME_TIMEOUT = Outcome.TIMEOUT
OUTCOME_ERROR = Outcome.ERROR
OUTCOME_SOFT_FAILURE = Outcome.SOFT_FAILURE
OUTCOME_RATE_LIMITED = Outcome.RATE_LIMITED


# Signals in role stdout/stderr that indicate an LLM rate-limit /
# billing cap / quota exhaustion, NOT a script bug. Matched against the
# last ~4 KB of the role log. Patterns are lowercased-case-insensitive.
_RATE_LIMIT_SIGNATURES = (
    "out of extra usage",            # Claude CLI (`claude -p`)
    "rate limit exceeded",           # generic
    "429 too many requests",         # HTTP 429
    "resource_exhausted",            # Google API
    "quota exceeded",                # Google / OpenAI
    "insufficient_quota",            # OpenAI
    "overloaded_error",              # Anthropic API
    "429 resource has been exhausted",
)


def _effective_stall_minutes(rp: "RoleProcess", stall_minutes: int) -> float:
    override = getattr(rp, "stall_minutes_override", None)
    return float(override if override is not None else stall_minutes)


def _ensure_default_progress_paths(rp: "RoleProcess", ideas_file: str) -> None:
    """Monitor the canonical research output without Pro-specific wiring."""
    if not getattr(rp, "writes_ideas_file", True):
        return
    path = Path(ideas_file).resolve(strict=False)
    existing = tuple(getattr(rp, "progress_paths", ()))
    if path in existing:
        return
    rp.progress_paths = (*existing, path)
    # Adding a signal source is configuration, not evidence of progress.
    # Baseline it immediately so only a later metadata change resets the timer.
    rp._last_progress_fingerprint = progress_paths_fingerprint(
        rp.progress_paths)


def _is_role_stalled(rp: "RoleProcess", stall_minutes: int) -> bool:
    """True if no observable progress occurred for ``stall_minutes``.

    Mutates rp's `_last_log_size` and `_stall_since` fields across calls
    so the caller (check_active_roles polling loop) doesn't need to
    manage timer state. Returns False immediately when stall_minutes
    <= 0 (feature disabled).

    Round-2 B2: ``rp.stall_minutes_override`` (when set on the
    RoleProcess) wins over the global ``stall_minutes`` argument.
    Round-2 B3: until ``rp.stall_warmup_seconds`` has elapsed since
    process spawn, the stall timer is suppressed. The warmup ends
    early as soon as the child writes its first stdout byte —
    ``current_size > 0`` is the signal.
    """
    now = time.time()
    rp._last_observed_at = now
    effective = _effective_stall_minutes(rp, stall_minutes)
    if effective <= 0:
        return False
    try:
        current_size = rp.log_path.stat().st_size
    except OSError:
        current_size = rp._last_log_size
    # B3 warmup: skip stall detection during the warmup window unless
    # the child has already produced output (in which case we want the
    # normal stall logic to apply immediately).
    warmup = float(getattr(rp, "stall_warmup_seconds", 0.0) or 0.0)
    if warmup > 0 and current_size == 0:
        if (now - rp.start_time) < warmup:
            return False
    progress_kinds = []
    if current_size != rp._last_log_size:
        progress_kinds.append("log")
    rp._last_log_size = current_size

    pid = getattr(rp.process, "pid", None)
    cpu_ticks = process_tree_cpu_ticks(pid) if type(pid) is int else None
    previous_cpu = getattr(rp, "_last_cpu_ticks", None)
    if cpu_ticks is not None and previous_cpu is not None and cpu_ticks != previous_cpu:
        progress_kinds.append("cpu")
    if cpu_ticks is not None:
        rp._last_cpu_ticks = cpu_ticks

    fingerprint = progress_paths_fingerprint(
        getattr(rp, "progress_paths", ()))
    previous_fingerprint = getattr(rp, "_last_progress_fingerprint", None)
    if (fingerprint is not None and previous_fingerprint is not None
            and fingerprint != previous_fingerprint):
        progress_kinds.append("artifact")
    if fingerprint is not None:
        rp._last_progress_fingerprint = fingerprint

    if progress_kinds:
        rp._last_progress_kinds = tuple(progress_kinds)
        rp._last_progress_at = now
        rp._stall_since = 0.0
        return False
    if rp._stall_since == 0.0:
        rp._stall_since = now
        return False
    return (now - rp._stall_since) > effective * 60


def _is_rate_limit_exit(log_path: "Path") -> bool:
    """Scan the last ~4 KB of a role log for LLM rate-limit signatures.

    Rate-limit hits surface as exit-code-non-zero from the Claude/Gemini
    CLI with the error printed to stdout/stderr. We don't want those
    one-off transient events to advance the consecutive-failure counter
    and trip the circuit-breaker backoff — the role was blocked by the
    provider, not broken.
    """
    try:
        with open(log_path, "rb") as fh:
            try:
                fh.seek(-4096, 2)
            except OSError:
                fh.seek(0)
            tail = fh.read().decode("utf-8", errors="ignore").lower()
    except OSError:
        return False
    return any(sig in tail for sig in _RATE_LIMIT_SIGNATURES)


def is_success(outcome: "Outcome | bool") -> bool:
    """True iff the outcome represents a clean successful cycle."""
    if isinstance(outcome, bool):
        return outcome
    return outcome == OUTCOME_OK


# Track consecutive soft failures per role (exit 0 but no ideas.md modification)
_consecutive_soft_failures: Dict[str, int] = {}
_SOFT_FAILURE_ERROR_THRESHOLD = 5


def _check_owned_role(rp, owner, ideas_file, role_stall_minutes):
    """Return a completion only after tree proof, settlement and owned release."""
    if getattr(rp, "is_pending_role", False):
        return None
    ret = rp.process.poll()
    timed_out = getattr(rp, "_owned_role_timed_out", False) is True
    if ret is None:
        _ensure_default_progress_paths(rp, ideas_file)
        timed_out = (time.time() - rp.start_time > rp.timeout
                     or _is_role_stalled(rp, role_stall_minutes))
        if not timed_out:
            return None
        rp._owned_role_timed_out = True
        closure = owner.abort()
        if closure is None:
            return None
        ret = closure["worker_returncode"]
    closure = owner.require_closed(ret)
    rp.close_log()
    stopped = closure["stop_requested"] or closure["forced_cleanup"]
    forced = "process_timeout" if timed_out else "process_stopped" if stopped else None
    if getattr(rp, "native_result_ref", None) is not None:
        bucket = native_role_outcome(
            rp, ret, cleanup_verified=True, forced_reason=forced,
            rate_limited=(ret != 0 and (ret == 42 or _is_rate_limit_exit(rp.log_path))))
        outcome = {"ok": OUTCOME_OK, "error": OUTCOME_ERROR,
                   "timeout": OUTCOME_TIMEOUT, "soft_failure": OUTCOME_SOFT_FAILURE,
                   "rate_limited": OUTCOME_RATE_LIMITED}[bucket]
    elif timed_out:
        outcome = OUTCOME_TIMEOUT
    elif stopped:
        outcome = OUTCOME_ERROR
    elif ret == 0:
        outcome = (OUTCOME_OK if not getattr(rp, "writes_ideas_file", True)
                   or _ideas_modified_credits(ideas_file, rp)["modified"]
                   else OUTCOME_SOFT_FAILURE)
    else:
        outcome = (OUTCOME_RATE_LIMITED if ret == 42 or _is_rate_limit_exit(rp.log_path)
                   else OUTCOME_ERROR)
    # Do not repair ideas, advance failure counters or report a finished cycle
    # while either settlement or release remains uncertain.
    if not settle_role_delivery(rp, outcome.name.lower(), ret, True):
        return None
    try:
        _check_ideas_integrity(ideas_file, rp)
    except Exception as exc:
        # Closure/settlement/release already committed; a diagnostic failure
        # must not strand the released owner in active_roles.
        logger.error("Role ideas integrity check failed: %s", type(exc).__name__)
    if outcome == OUTCOME_OK:
        _consecutive_soft_failures.pop(rp.role_name, None)
    elif outcome == OUTCOME_SOFT_FAILURE:
        _consecutive_soft_failures[rp.role_name] = (
            _consecutive_soft_failures.get(rp.role_name, 0) + 1)
    logger.info("%s cycle %d tree-closed result: %s", rp.role_name, rp.cycle_num, outcome.name)
    return outcome


def check_active_roles(active_roles: Dict[str, "RoleProcess"],
                       ideas_file: str = "ideas.md",
                       role_stall_minutes: int = 0) -> list:
    """Check running role processes. Returns list of (role_name, Outcome) tuples.

    ``role_stall_minutes`` (default 0 = disabled): kill a running role
    whose log file hasn't grown for this many minutes, even when the
    wall-clock timeout hasn't elapsed. Catches claude-CLI hangs that
    produce a 0-byte log and would otherwise burn the full timeout.
    """
    finished = []
    for role_name in list(active_roles.keys()):
        rp = active_roles[role_name]
        from orze.engine.role_supervision import supervised_role_owner
        try:
            owner = supervised_role_owner(rp)
            if owner is not None:
                outcome = _check_owned_role(rp, owner, ideas_file, role_stall_minutes)
                if outcome is not None and active_roles.get(role_name) is rp:
                    del active_roles[role_name]
                    finished.append((role_name, outcome))
                continue
        except Exception as exc:
            logger.error("Role %s completion HOLD: %s", role_name, type(exc).__name__)
            continue
        # Snapshot descendants before polling the leader. If the role exits
        # after starting a detached child, ancestry disappears as soon as the
        # child is reparented; the stable identity remains safe to reap.
        refresh_role_process_descendants(rp)
        if rp._receipt_error:
            logger.error(
                "%s role identity receipt could not be refreshed; killing",
                role_name)
            reaped = terminate_role_process(
                rp, f"unattested role {role_name}",
                reaper=_terminate_and_reap)
            rp.close_log()
            if getattr(rp, "native_result_ref", None) is not None:
                native_role_outcome(rp, None, cleanup_verified=reaped,
                                    forced_reason="process_identity_unconfirmed")
            if settle_role_delivery(rp, "error", None, reaped):
                _fs_unlock(rp.lock_dir)
            del active_roles[role_name]
            finished.append((role_name, OUTCOME_ERROR))
            continue
        ret = rp.process.poll()
        elapsed = time.time() - rp.start_time

        if ret is None:
            # Still running — check wall-clock timeout first, then stall.
            _ensure_default_progress_paths(rp, ideas_file)
            if elapsed > rp.timeout:
                logger.warning("[ROLE TIMEOUT] %s after %.0fm — killing",
                               role_name, elapsed / 60)
                reaped = terminate_role_process(
                    rp, f"role {role_name}", reaper=_terminate_and_reap)
                rp.close_log()
                if getattr(rp, "native_result_ref", None) is not None:
                    native_role_outcome(rp, None, cleanup_verified=reaped,
                                        forced_reason="process_timeout")
                if settle_role_delivery(rp, "timeout", None, reaped):
                    _fs_unlock(rp.lock_dir)
                del active_roles[role_name]
                finished.append((role_name, OUTCOME_TIMEOUT))
            elif _is_role_stalled(rp, role_stall_minutes):
                effective = _effective_stall_minutes(
                    rp, role_stall_minutes)
                logger.warning(
                    "[ROLE STALL] %s — no log, process-tree CPU, or "
                    "declared-output progress for %g minutes; killing",
                    role_name, effective,
                )
                reaped = terminate_role_process(
                    rp, f"role {role_name}", reaper=_terminate_and_reap)
                rp.close_log()
                if getattr(rp, "native_result_ref", None) is not None:
                    native_role_outcome(rp, None, cleanup_verified=reaped,
                                        forced_reason="process_timeout")
                if settle_role_delivery(rp, "timeout", None, reaped):
                    _fs_unlock(rp.lock_dir)
                del active_roles[role_name]
                finished.append((role_name, OUTCOME_TIMEOUT))
            continue

        # Process exited. Managed roles are not permitted to leave background
        # children behind, even on a zero exit. Reap exact descendants observed
        # during prior polls before accepting the outcome.
        reaped = terminate_role_process(
            rp, f"completed role {role_name}", reaper=_terminate_and_reap)
        rp.close_log()
        outcome: Outcome
        if getattr(rp, "native_result_ref", None) is not None:
            bucket = native_role_outcome(
                rp, ret, cleanup_verified=reaped,
                rate_limited=(ret != 0 and (ret == 42 or _is_rate_limit_exit(rp.log_path))),
            )
            outcome = {
                "ok": OUTCOME_OK, "error": OUTCOME_ERROR,
                "soft_failure": OUTCOME_SOFT_FAILURE,
                "rate_limited": OUTCOME_RATE_LIMITED,
            }[bucket]
            if outcome == OUTCOME_OK:
                _consecutive_soft_failures.pop(role_name, None)
            elif outcome == OUTCOME_SOFT_FAILURE:
                _consecutive_soft_failures[role_name] = _consecutive_soft_failures.get(role_name, 0) + 1
            logger.info("%s cycle %d native result: %s/%s (%s)",
                        role_name, rp.cycle_num, rp.native_result_details["status"],
                        rp.native_result_details["reason"], outcome.name)
        elif not reaped:
            logger.error(
                "%s exited %d but managed descendants could not be proven "
                "stopped", role_name, ret)
            outcome = OUTCOME_ERROR
        elif ret == 0:
            # Only apply the ideas-modified soft-failure check to roles
            # whose job IS to append to ideas.md (research / research_gemini).
            # Strategy roles (professor, data_analyst, engineer, thinker,
            # code_evolution) modify RESEARCH_RULES.md / *.py / _retrospection.txt
            # instead — their launcher sets rp.writes_ideas_file = False.
            if not getattr(rp, "writes_ideas_file", True):
                logger.info("%s cycle %d completed", role_name, rp.cycle_num)
                _consecutive_soft_failures.pop(role_name, None)
                outcome = OUTCOME_OK
            else:
                credits = _ideas_modified_credits(ideas_file, rp)
                if credits["modified"]:
                    logger.info(
                        "%s cycle %d completed [SOFT_FAILURE_CHECK] %s",
                        role_name, rp.cycle_num, _fmt_credits(credits))
                    _consecutive_soft_failures.pop(role_name, None)
                    outcome = OUTCOME_OK
                else:
                    count = _consecutive_soft_failures.get(role_name, 0) + 1
                    _consecutive_soft_failures[role_name] = count
                    logger.warning(
                        "%s cycle %d exited 0 but ideas.md was not modified "
                        "[SOFT_FAILURE_REASON] %s (soft failure %d/%d)",
                        role_name, rp.cycle_num, _fmt_credits(credits),
                        count, _SOFT_FAILURE_ERROR_THRESHOLD)
                    if count >= _SOFT_FAILURE_ERROR_THRESHOLD:
                        logger.error("%s has %d consecutive soft failures "
                                     "(exit 0, no output) — role may be misconfigured",
                                     role_name, count)
                    outcome = OUTCOME_SOFT_FAILURE
        else:
            if ret == 42 or _is_rate_limit_exit(rp.log_path):
                logger.warning("%s cycle %d hit LLM rate-limit (exit %d) "
                               "— transient, not counting toward "
                               "consecutive_failures",
                               role_name, rp.cycle_num, ret)
                outcome = OUTCOME_RATE_LIMITED
            else:
                logger.warning("%s cycle %d failed (exit %d), see %s",
                               role_name, rp.cycle_num, ret, rp.log_path)
                outcome = OUTCOME_ERROR

        # CORRUPTION GUARD: check if ideas.md was truncated by the role
        _check_ideas_integrity(ideas_file, rp)

        if settle_role_delivery(rp, outcome.name.lower(), ret, reaped):
            _fs_unlock(rp.lock_dir)
        elif getattr(rp, "trigger_launch", None) is not None:
            outcome = OUTCOME_ERROR
            if getattr(rp, "native_result_ref", None) is not None:
                from orze.core.research_result import make_result
                rp.native_result_details = make_result("error", "trigger_terminal_unconfirmed")
        del active_roles[role_name]
        finished.append((role_name, outcome))

    return finished


def _ideas_modified_credits(ideas_file: str,
                            rp: "RoleProcess") -> Dict[str, object]:
    """Evaluate all three soft-failure credit signals and return them.

    Returns a dict with keys:
      modified (bool)            — final verdict, True if any credit fired
      credit  (str)              — which credit decided it: "consumed",
                                   "mtime", "size", "count",
                                   "no_pre_snapshot", "none", "missing",
                                   or "stat_error"
      consumed (int)             — ideas_consumed_during_run counter
      mtime_delta (float|None)   — current_mtime - ideas_md_mtime_pre,
                                   or None if pre_mtime unset / stat failed
      size_pre (int)             — ideas_pre_size at role start
      size_post (int|None)       — current size, or None if missing/stat error
      count_pre (int)            — ideas_pre_count at role start
      count_post (int|None)      — current idea count, or None if not read

    Forensics: c1196 (silent-skip family 6) could not be diagnosed because
    only the final bool was visible. Every credit is now logged at the call
    site so cross-cycle analysis can distinguish "consumed by same daemon"
    from "wiped by another daemon" from "actually no output".
    """
    credits: Dict[str, object] = {
        "modified": False,
        "credit": "none",
        "consumed": int(getattr(rp, "ideas_consumed_during_run", 0)),
        "mtime_delta": None,
        "size_pre": int(getattr(rp, "ideas_pre_size", 0)),
        "size_post": None,
        "count_pre": int(getattr(rp, "ideas_pre_count", 0)),
        "count_post": None,
    }

    if credits["consumed"] > 0:
        credits["modified"] = True
        credits["credit"] = "consumed"
        return credits

    ideas_path = Path(ideas_file)
    if not ideas_path.exists():
        credits["credit"] = "missing"
        return credits

    pre_mtime = float(getattr(rp, "ideas_md_mtime_pre", 0.0))
    current_mtime = None
    current_size = None
    try:
        st = ideas_path.stat()
        current_mtime = st.st_mtime
        current_size = st.st_size
        credits["size_post"] = int(current_size)
    except OSError:
        credits["credit"] = "stat_error"
        return credits

    if pre_mtime > 0 and current_mtime is not None:
        credits["mtime_delta"] = current_mtime - pre_mtime
        if current_mtime > pre_mtime:
            credits["modified"] = True
            credits["credit"] = "mtime"
            return credits

    if credits["size_pre"] == 0:
        # No pre-snapshot; can't tell — assume modified to avoid false positives
        credits["modified"] = True
        credits["credit"] = "no_pre_snapshot"
        return credits

    if current_size != credits["size_pre"]:
        credits["modified"] = True
        credits["credit"] = "size"
        return credits

    # Size same — check idea count
    try:
        current_text = ideas_path.read_text(encoding="utf-8")
        current_count = count_idea_headings(current_text)
        credits["count_post"] = int(current_count)
        if current_count != credits["count_pre"]:
            credits["modified"] = True
            credits["credit"] = "count"
    except OSError:
        credits["credit"] = "stat_error"
    return credits


def _fmt_credits(c: Dict[str, object]) -> str:
    """Compact one-line rendering of credit signals for log scraping."""
    md = c.get("mtime_delta")
    md_s = f"{md:+.3f}" if isinstance(md, (int, float)) else "n/a"
    return (
        f"credit={c['credit']} consumed={c['consumed']} "
        f"mtime_delta={md_s} "
        f"size={c['size_pre']}->{c['size_post']} "
        f"count={c['count_pre']}->{c['count_post']}"
    )


def _ideas_were_modified(ideas_file: str, rp: "RoleProcess") -> bool:
    """Back-compat shim: returns just the bool verdict.

    Prefer ``_ideas_modified_credits`` at call sites that want to log the
    individual signals.
    """
    return bool(_ideas_modified_credits(ideas_file, rp)["modified"])


def _prune_corrupt_archive(archive_dir: Path, basename: str,
                           keep: int = 5) -> None:
    """Keep at most ``keep`` most-recent ``<basename>.corrupt.*`` files."""
    try:
        candidates = sorted(archive_dir.glob(f"{basename}.corrupt.*"),
                            key=lambda p: p.stat().st_mtime, reverse=True)
    except OSError:
        return
    for extra in candidates[keep:]:
        try:
            extra.unlink()
        except OSError:
            pass


def cleanup_stale_corrupt_files(ideas_path: Path,
                                cfg: dict = None,
                                archive_dir=None,
                                keep: int = 5) -> int:
    """Move legacy ``ideas.md.corrupt.*`` files into .orze/backups/corrupt/
    and keep only the ``keep`` most-recent. Returns the number moved.
    Idempotent; safe to call on every startup.
    """
    if archive_dir is None and cfg:
        from orze.core.config import orze_path
        archive_dir = orze_path(cfg, "backups") / "corrupt"
    elif archive_dir is None:
        # Fallback for legacy calls without cfg
        archive_dir = ideas_path.parent / "_corrupt_ideas"
    try:
        archive_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return 0
    moved = 0
    pattern = f"{ideas_path.name}.corrupt.*"
    for stray in ideas_path.parent.glob(pattern):
        if stray.parent == archive_dir:
            continue
        try:
            shutil.move(str(stray), str(archive_dir / stray.name))
            moved += 1
        except OSError:
            continue
    _prune_corrupt_archive(archive_dir, ideas_path.name, keep=keep)
    return moved


def _read_ingest_state(ideas_path: Path) -> dict:
    """Read the ingest-state sidecar: {size, mtime, ts}."""
    sidecar = ideas_path.with_suffix(ideas_path.suffix + ".ingest_state.json")
    try:
        import json
        return json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def mark_ingest(ideas_path: Path) -> None:
    """Record a successful legitimate consumption/wipe of ideas.md.

    The shrink-is-corruption detector uses the recorded timestamp to
    distinguish a DESIGNED post-ingest wipe (legitimate) from a rogue
    role truncating the file (real corruption). Callers: the ideas-
    ingester after successfully moving queued ideas into idea_lake.
    """
    import json
    sidecar = ideas_path.with_suffix(ideas_path.suffix + ".ingest_state.json")
    try:
        st = ideas_path.stat()
        sidecar.write_text(
            json.dumps({"size": st.st_size, "mtime": st.st_mtime,
                        "ts": time.time()}),
            encoding="utf-8",
        )
    except OSError as e:
        logger.debug("mark_ingest failed: %s", e)


# Ingest happened within this many seconds → shrink is expected, not corrupt.
_INGEST_GRACE_WINDOW_S = 120.0


def _check_ideas_integrity(ideas_file: str, rp: "RoleProcess"):
    """Detect and auto-restore ideas.md if a role truncated/corrupted it.

    A shrink is only flagged as corruption when NEITHER of the following
    is true:
      (a) a successful ingest was recorded in the sidecar within the
          last ``_INGEST_GRACE_WINDOW_S`` seconds (designed wipe), OR
      (b) the sidecar's recorded size matches (or is larger than) the
          current size (the file already was small before this role).
    """
    ideas_path = Path(ideas_file)
    if not ideas_path.exists() or rp.ideas_pre_size == 0:
        return

    current_size = ideas_path.stat().st_size
    # Quick check: if file grew or stayed same, it's fine
    if current_size >= rp.ideas_pre_size:
        return

    # Shrink — but was this a legitimate post-ingest wipe?
    ingest_state = _read_ingest_state(ideas_path)
    ingest_ts = ingest_state.get("ts", 0.0)
    if ingest_ts and (time.time() - ingest_ts) < _INGEST_GRACE_WINDOW_S:
        logger.debug(
            "ideas.md shrunk after %s cycle %d but ingest recorded "
            "%.0fs ago — treating as designed wipe, not corruption",
            rp.role_name, rp.cycle_num, time.time() - ingest_ts)
        return
    # Also defend against: sidecar recorded the small post-wipe size; the
    # role was invoked with a pre-snapshot taken BEFORE the wipe but only
    # ran AFTER. Compare against recorded post-ingest size, not pre-snapshot.
    recorded_size = ingest_state.get("size")
    if (isinstance(recorded_size, (int, float))
            and current_size >= recorded_size):
        logger.debug(
            "ideas.md size %d >= last-ingest size %d — no corruption",
            current_size, int(recorded_size))
        return

    # File shrunk — check idea count to confirm corruption
    try:
        current_text = ideas_path.read_text(encoding="utf-8")
        current_count = count_idea_headings(current_text)
    except OSError:
        current_count = 0

    if current_count >= rp.ideas_pre_count:
        return  # Count OK despite smaller size (unlikely but possible)

    # CORRUPTION DETECTED
    shrink_pct = (1 - current_size / rp.ideas_pre_size) * 100
    lost_ideas = rp.ideas_pre_count - current_count
    logger.error(
        "IDEAS.MD CORRUPTION DETECTED after %s cycle %d! "
        "File shrunk %.0f%% (%d->%d bytes), lost %d ideas (%d->%d). "
        "Restoring from backup.",
        rp.role_name, rp.cycle_num, shrink_pct,
        rp.ideas_pre_size, current_size,
        lost_ideas, rp.ideas_pre_count, current_count)

    # Restore from .safe backup — validate by idea count, not byte size
    backup_path = ideas_path.with_suffix(".md.safe")
    if backup_path.exists():
        try:
            backup_text = backup_path.read_text(encoding="utf-8")
            backup_count = count_idea_headings(backup_text)
        except OSError:
            backup_count = 0

        if backup_count >= rp.ideas_pre_count:
            # Save the corrupted file for forensics — in a dedicated
            # subdir of the results/ tree, keeping only the last 5.
            corrupt_dir = ideas_path.parent / "_corrupt_ideas"
            try:
                corrupt_dir.mkdir(parents=True, exist_ok=True)
            except OSError:
                corrupt_dir = ideas_path.parent
            corrupt_path = corrupt_dir / f"{ideas_path.name}.corrupt.{int(time.time())}"
            shutil.copy2(str(ideas_path), str(corrupt_path))
            _prune_corrupt_archive(corrupt_dir, ideas_path.name, keep=5)
            # Restore
            shutil.copy2(str(backup_path), str(ideas_path))
            logger.info("Restored ideas.md from backup (%d ideas). "
                        "Corrupted version saved to %s",
                        backup_count, corrupt_path)
        else:
            logger.error("Backup also has fewer ideas (%d vs expected %d). "
                         "NOT restoring.",
                         backup_count, rp.ideas_pre_count)
    else:
        logger.error("No backup found at %s — cannot restore!", backup_path)
