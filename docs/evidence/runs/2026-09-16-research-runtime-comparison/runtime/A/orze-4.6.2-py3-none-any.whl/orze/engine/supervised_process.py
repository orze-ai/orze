"""Two-phase Linux execution handle with an exact whole-tree closure receipt.

prepare_supervised forks a *blocked* worker under a dedicated subreaper.
The caller must durably bind ``binding`` before start(). A worker's integer
exit status is returned only after TREE_CLOSED and normal supervisor exit.
No crash recovery/adoption or hostile same-UID process sandbox is claimed.
"""
from __future__ import annotations

import copy
import ctypes
import hashlib
import json
import os
from pathlib import Path
import secrets
import select
import signal
import socket
import subprocess
import sys
import time

from orze.engine.supervisor_worker import (
    MAX_FRAME, PROTOCOL, canonical, process_identity, send_frame, take_frame,
    MAX_NS, RUNTIME_LEASE_PROTOCOL, RuntimeLeaseExpired,
    validate_runtime_lease, runtime_lease_now, require_runtime_lease,
)


class SupervisionUnavailable(ValueError):
    """Rejected locally, before creating any supervisor or worker."""


class SupervisionUncertain(RuntimeError):
    """No closure authority; the caller must preserve its attempt HOLD."""

    def __init__(self, reason, *, process=None):
        super().__init__(reason)
        self.process = process


class SupervisedProcess:
    """A Popen-like handle whose pid is the actual worker, not the supervisor."""

    def __init__(self, supervisor, channel, identity, nonce, command_sha256, *, runtime_lease=None):
        self._initialize(supervisor, channel, identity, nonce, command_sha256,
                         runtime_lease=runtime_lease)

    def _initialize(self, supervisor, channel, identity, nonce, command_sha256, *, runtime_lease=None):
        self._supervisor = supervisor
        self._channel = channel
        self._identity = json.loads(canonical(identity))
        self._nonce = nonce
        self._command_sha256 = command_sha256
        self._runtime_lease = (None if runtime_lease is None
                               else validate_runtime_lease(runtime_lease))
        self._lease_observed_ns = None
        self._binding = None
        self._closed = None
        self._buffer = bytearray()
        self._started = False
        self._stop_sent = False
        self._uncertainty = None
        self._eof = False
        self._supervisor_pidfd = None
        self.pid = None
        self.returncode = None
        self.args = ["<supervised-worker>"]  # never leak argv in TimeoutExpired

    @property
    def supervisor_pid(self):
        return self._supervisor.pid

    @property
    def supervisor_pidfd(self):
        return self._supervisor_pidfd

    @property
    def binding(self):
        return copy.deepcopy(self._binding)

    def _fail(self, reason):
        self._uncertainty = self._uncertainty or reason
        from orze.engine.controller_members import hold_process
        hold_process(self, "controller_supervision_uncertain")
        raise SupervisionUncertain(self._uncertainty, process=self)

    def _accept(self, message):
        if self._binding is None:
            if set(message) != {"event", "binding"} or message["event"] != "READY":
                self._fail("supervisor_ready_invalid")
            binding = message["binding"]
            keys = {
                    "schema", "protocol", "identity", "nonce_sha256", "command_sha256",
                    "worker", "supervisor"}
            if self._runtime_lease is not None:
                keys.add("runtime_lease")
            if not isinstance(binding, dict) or set(binding) != keys:
                self._fail("supervisor_binding_invalid")
            expected = {"schema": 1, "protocol": PROTOCOL, "identity": self._identity,
                        "nonce_sha256": hashlib.sha256(self._nonce.encode("ascii")).hexdigest(),
                        "command_sha256": self._command_sha256}
            if self._runtime_lease is not None:
                expected.update(schema=2, protocol=RUNTIME_LEASE_PROTOCOL,
                                runtime_lease=self._runtime_lease)
            if canonical({key: binding[key] for key in expected}) != canonical(expected):
                self._fail("supervisor_binding_mismatch")
            for key in ("worker", "supervisor"):
                item = binding[key]
                if (not isinstance(item, dict) or set(item) != {"pid", "start_ticks"}
                        or any(type(item[value]) is not int or item[value] <= 0
                               for value in ("pid", "start_ticks"))):
                    self._fail("supervisor_process_identity_invalid")
            if binding["supervisor"]["pid"] != self.supervisor_pid:
                self._fail("supervisor_process_identity_mismatch")
            observed, _ = process_identity(self.supervisor_pid)
            worker, parent = process_identity(binding["worker"]["pid"])
            if (observed != binding["supervisor"] or worker != binding["worker"]
                    or parent != self.supervisor_pid):
                self._fail("supervisor_process_identity_mismatch")
            self._binding = copy.deepcopy(binding)
            self.pid = worker["pid"]
            return
        expected_keys = {"schema", "event", "binding", "worker_returncode", "stop_requested",
                         "forced_cleanup", "reaped_children", "wait_proof"}
        schema = 1
        if self._runtime_lease is not None:
            schema = 2
            expected_keys.update(("lease_expired", "lease_observed_ns"))
            observed = message.get("lease_observed_ns")
            expired = message.get("lease_expired")
            if (type(observed) is not int
                    or not self._runtime_lease["issued_ns"] <= observed <= MAX_NS
                    or type(expired) is not bool
                    or expired != (observed >= self._runtime_lease["deadline_ns"])
                    or (expired and message.get("stop_requested") is not True)):
                self._fail("supervisor_lease_closure_invalid")
        if (self._closed is not None or set(message) != expected_keys
                or type(message["schema"]) is not int or message["schema"] != schema
                or message["event"] != "TREE_CLOSED"
                or canonical(message["binding"]) != canonical(self._binding)
                or type(message["worker_returncode"]) is not int
                or not -64 <= message["worker_returncode"] <= 255
                or type(message["stop_requested"]) is not bool
                or type(message["forced_cleanup"]) is not bool
                or (message["forced_cleanup"] and not message["stop_requested"])
                or type(message["reaped_children"]) is not int
                or message["reaped_children"] < 1
                or message["wait_proof"] != "ECHILD_WALL"
                or (not self._started and not message["stop_requested"])):
            self._fail("supervisor_closure_invalid")
        self._closed = copy.deepcopy(message)

    def _receive(self):
        if self._uncertainty is not None:
            self._fail(self._uncertainty)
        try:
            while not self._eof:
                try:
                    chunk = self._channel.recv(65536)
                except BlockingIOError:
                    break
                if not chunk:
                    self._eof = True
                    break
                self._buffer.extend(chunk)
                if len(self._buffer) > MAX_FRAME + 4:
                    self._fail("supervisor_frame_limit")
                while True:
                    message = take_frame(self._buffer)
                    if message is None:
                        break
                    self._accept(message)
            if self._eof and (self._buffer or self._closed is None):
                self._fail("supervisor_channel_lost")
        except SupervisionUncertain:
            raise
        except Exception:
            self._fail("supervisor_protocol_uncertain")

    def start(self):
        if self._uncertainty or self._binding is None or self._started or self._stop_sent:
            self._fail("supervisor_start_not_authorized")
        if self._runtime_lease is not None:
            try:
                observed = runtime_lease_now(self._runtime_lease)
                if self._lease_observed_ns is not None and observed < self._lease_observed_ns:
                    raise ValueError("runtime_lease_clock_reversed")
                self._lease_observed_ns = observed
            except Exception:
                self._fail("supervisor_lease_clock_uncertain")
            if observed >= self._runtime_lease["deadline_ns"]:
                raise RuntimeLeaseExpired(observed)
        from orze.engine.controller_members import start_guard
        with start_guard(self) as admitted:
            if not admitted:
                return False
            self._send("GO")
            self._started = True

    def _send(self, command):
        try:
            self._channel.settimeout(1)
            send_frame(self._channel, {"command": command, "nonce": self._nonce})
            self._channel.setblocking(False)
        except Exception:
            self._fail("supervisor_control_uncertain")

    def poll(self):
        from orze.engine.controller_members import poll_process, record_closed
        # Consume any already-issued closure before a late quiesce asks this
        # same (single-reader) owner to send STOP to a finished supervisor.
        self._receive()
        poll_process(self)
        self._receive()
        supervisor_code = self._supervisor.poll()
        if supervisor_code is not None:
            # Drain any final message already written before waitpid observed exit.
            self._receive()
            if supervisor_code != 0 or self._closed is None:
                self._fail("supervisor_exit_unconfirmed")
            self.returncode = self._closed["worker_returncode"]
            self._close_descriptors()
            record_closed(self)
        return self.returncode

    def wait(self, timeout=None):
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            result = self.poll()
            if result is not None:
                return result
            if deadline is not None and time.monotonic() >= deadline:
                raise subprocess.TimeoutExpired(self.args, timeout)
            time.sleep(0.01)

    def closure_receipt(self):
        return copy.deepcopy(self._closed) if self.poll() is not None else None

    def stop(self, timeout=10):
        if self.poll() is not None:
            return True
        # A v2 autonomous expiry may deliver CLOSED before waitpid observes
        # supervisor exit. Do not send STOP back into an already closed peer.
        if not self._stop_sent and (self._runtime_lease is None or self._closed is None):
            self._send("STOP")
            self._stop_sent = True
        try:
            self.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self._fail("supervisor_stop_unconfirmed")
        return True

    def _close_descriptors(self):
        self._channel.close()
        if self._supervisor_pidfd is not None:
            os.close(self._supervisor_pidfd)
            self._supervisor_pidfd = None


def prepare_supervised(cmd, *, identity, env=None, cwd=None, stdout=None,
                       stderr=None, pass_fds=(), worker_only_fds=(), ready_timeout=10,
                       runtime_lease=None):
    """Create a blocked worker; post-Popen failures carry a HOLD handle.

    ``pass_fds`` are retained by both supervisor and worker until their own
    close/exit (for example a shared lease). ``worker_only_fds`` are handed to
    the blocked worker and closed by the supervisor before READY. Both groups
    together accept at most 64 distinct, valid descriptors >= 3. The caller
    still owns its original descriptors; no local inheritable flags change.
    """
    try:
        if (sys.platform != "linux" or not hasattr(os, "pidfd_open")
                or not hasattr(signal, "pidfd_send_signal")
                or not hasattr(ctypes.CDLL(None), "prctl")):
            raise ValueError("supervisor_linux_support_required")
        if (not isinstance(cmd, (list, tuple)) or not cmd
                or any(not isinstance(arg, str) or "\0" in arg for arg in cmd)
                or not isinstance(identity, dict)):
            raise ValueError("supervisor_setup_invalid")
        identity = json.loads(canonical(identity))
        lease = None if runtime_lease is None else validate_runtime_lease(runtime_lease)
        if lease is not None:
            if (type(identity.get("attempt_ref")) is not dict
                    or identity["attempt_ref"].get("phase") != "action"):
                raise ValueError("supervisor_lease_phase_invalid")
            require_runtime_lease(lease)
        if len(canonical(identity)) > 16384:
            raise ValueError("supervisor_identity_limit")
        if type(ready_timeout) not in (int, float) or not 0 < ready_timeout <= 60:
            raise ValueError("supervisor_ready_timeout_invalid")
        environment = dict(os.environ if env is None else env)
        if any(not isinstance(key, str) or not isinstance(value, str)
               or "\0" in key + value or "=" in key for key, value in environment.items()):
            raise ValueError("supervisor_environment_invalid")
        if (not isinstance(pass_fds, (list, tuple))
                or not isinstance(worker_only_fds, (list, tuple))):
            raise ValueError("supervisor_pass_fds_invalid")
        worker_fds = tuple(worker_only_fds)
        fds = (*pass_fds, *worker_fds)
        if (len(fds) > 64 or any(type(fd) is not int or fd < 3 for fd in fds)
                or len(set(fds)) != len(fds)):
            raise ValueError("supervisor_pass_fds_invalid")
        for fd in fds:
            os.fstat(fd)
        nonce = secrets.token_hex(32)
        config = {"cmd": list(cmd), "identity": identity, "env": environment, "nonce": nonce,
                  "worker_only_fds": list(worker_fds)}
        if lease is not None:
            config["runtime_lease"] = lease
        if len(canonical(config)) > MAX_FRAME:
            raise ValueError("supervisor_setup_limit")
        # Probe only ourselves, without installing a process-wide subreaper.
        probe = os.pidfd_open(os.getpid(), 0)
        try:
            signal.pidfd_send_signal(probe, 0)
        finally:
            os.close(probe)
    except Exception as exc:
        raise SupervisionUnavailable("supervisor_setup_unavailable") from exc
    from orze.engine.controller_members import before_prepare, bind_prepared, prepare_failed
    command_hash = hashlib.sha256(canonical(list(cmd))).hexdigest()
    member = before_prepare(identity, command_hash)
    try:
        parent, child = socket.socketpair()
    except BaseException:
        prepare_failed(member, no_execution=True)
        raise
    # Prepare a reliable failure owner before any process is created. Normal
    # handle construction is still inside the post-spawn uncertainty boundary.
    try:
        fallback = object.__new__(SupervisedProcess)
        options = {} if lease is None else {"runtime_lease": lease}
        SupervisedProcess._initialize(fallback, None, parent, identity, nonce, command_hash, **options)
        bind_prepared(member, fallback)
    except BaseException:
        parent.close()
        child.close()
        prepare_failed(member, no_execution=True)
        raise
    try:
        supervisor = subprocess.Popen(
            [sys.executable, "-I", str(Path(__file__).with_name("supervisor_worker.py")),
             str(child.fileno())], cwd=cwd, stdin=subprocess.DEVNULL,
            stdout=stdout, stderr=stderr, pass_fds=(*fds, child.fileno()),
            start_new_session=True,
        )
    except BaseException:
        parent.close()
        child.close()
        # Popen may have created an OS process before a constructor/response
        # failure. Only the earlier, pre-Popen setup can prove no execution.
        prepare_failed(member)
        if member is not None:
            raise SupervisionUncertain("supervisor_popen_uncertain", process=fallback) from None
        raise
    handle = fallback
    fallback._supervisor = supervisor
    try:
        child.close()
        handle = SupervisedProcess(supervisor, parent, identity, nonce, command_hash, **options)
        bind_prepared(member, handle)
        handle._supervisor_pidfd = os.pidfd_open(supervisor.pid, 0)
        parent.settimeout(ready_timeout)
        send_frame(parent, config)
        parent.setblocking(False)
        deadline = time.monotonic() + ready_timeout
        while handle._binding is None:
            handle._receive()
            if supervisor.poll() is not None:
                handle._fail("supervisor_ready_unconfirmed")
            if time.monotonic() >= deadline:
                handle._fail("supervisor_ready_timeout")
            select.select([parent], [], [], 0.01)
        bind_prepared(member, handle, ready=True)
        return handle
    except BaseException as exc:
        # Closing the channel asks the supervisor to drain; it is NOT proof of
        # completion, nor authority to turn a committed intent into NOT_STARTED.
        # Local descriptor cleanup must not replace the uncertainty signal.
        for channel in (parent, child):
            try:
                channel.close()
            except BaseException:
                pass
        prepare_failed(member)
        if isinstance(exc, SupervisionUncertain):
            raise
        raise SupervisionUncertain("supervisor_prepare_uncertain", process=handle) from None
