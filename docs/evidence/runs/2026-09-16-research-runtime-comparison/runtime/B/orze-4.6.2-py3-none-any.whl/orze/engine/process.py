"""Process dataclasses and low-level process management utilities.

CALLING SPEC:
    TrainingProcess (dataclass)
        Fields: idea_id (str), gpu (int), process (Popen), start_time (float),
                log_path (Path), timeout (float)
        Private: _log_fh, _last_log_size, _last_log_check, _stall_since
        Methods: close_log() — closes the log file handle if open

    EvalProcess (dataclass)
        Fields: idea_id (str), gpu (int), process (Popen), start_time (float),
                log_path (Path), timeout (float)
        Private: _log_fh
        Methods: close_log() — closes the log file handle if open

    RoleProcess (dataclass)
        Fields: role_name (str), process (Popen), start_time (float),
                log_path (Path), timeout (float), lock_dir (Path), cycle_num (int),
                ideas_pre_size (int), ideas_pre_count (int)
        Private: _log_fh
        Methods: close_log() — closes the log file handle if open

    _kill_pg(proc, sig=SIGTERM) -> None
        proc: subprocess.Popen
        sig: signal number (default SIGTERM)
        side effects: sends signal to the entire process group; falls back to proc.send_signal

    _terminate_and_reap(proc, label="", timeout=10) -> bool
        proc: subprocess.Popen
        label: str — for log messages
        timeout: float — seconds to wait after SIGTERM before SIGKILL
        side effects: SIGTERM -> wait -> SIGKILL surviving process-group
                      descendants; logs warnings on force kill
        returns: True only if the group, tracked escaped descendants, and
                 leader are stopped; callers must not ignore False

    _new_process_group() -> None
        preexec_fn for subprocess.Popen; calls os.setpgrp() to create a new process group

    run_pre_script(idea_id, gpu, cfg, results_dir=None, *, lake=None)
        idea_id: str
        gpu: int — accepted for API compatibility; never exposed to child
        cfg: dict — uses 'pre_script', 'pre_args', 'pre_timeout', 'python', 'train_extra_env'
        results_dir: task scope; native execution requires the claim's Lake
        returns: legacy bool or native PreScriptResult carrying its exact ref
        side effects: CPU-only; native continuation requires owned tree closure

    run_artifact_preflight(idea_id, results_dir, cfg) -> bool
        returns: True if disabled or resolver exited 0, False otherwise
        side effects: runs a zero-GPU resolver and writes a hash-only receipt
"""
import datetime
import hashlib
import json
import os
import signal
import secrets
import shutil
import socket
import stat
import subprocess
import logging
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Optional
from pathlib import Path

from orze.engine.supervised_process import prepare_supervised

logger = logging.getLogger("orze")

_ROLE_PROCESS_RECEIPT = "role-process.json"
_ROLE_RECEIPT_VERSION = 1
_MAX_ROLE_RECEIPTS = 1024
_MAX_ROLE_DESCENDANTS = 4096
_MAX_ROLE_RECEIPT_BYTES = 1024 * 1024


def capture_process_identity(pid: int) -> dict:
    """Capture stable Linux process identity fields for crash recovery."""
    stat_text = Path(f"/proc/{int(pid)}/stat").read_text(encoding="utf-8")
    # The comm field is parenthesized and may contain spaces. Fields after
    # the final ')' start at process-state (field 3); starttime is field 22.
    rest = stat_text.rsplit(")", 1)[1].strip().split()
    return {
        "pid": int(pid),
        "pgid": os.getpgid(int(pid)),
        "start_ticks": int(rest[19]),
    }


def process_is_running(pid: int, start_ticks: Optional[int] = None) -> bool:
    """True only for the same, non-zombie process recorded at launch."""
    try:
        identity = capture_process_identity(int(pid))
        stat_text = Path(f"/proc/{int(pid)}/stat").read_text(encoding="utf-8")
        state = stat_text.rsplit(")", 1)[1].strip().split()[0]
    except (OSError, ValueError, ProcessLookupError):
        return False
    if start_ticks is not None and identity["start_ticks"] != int(start_ticks):
        return False
    return state != "Z"


def process_group_members(pgid: int) -> list:
    """Return non-zombie PIDs currently belonging to a Linux process group."""
    members = []
    try:
        proc_entries = Path("/proc").iterdir()
    except OSError:
        return members
    for entry in proc_entries:
        if not entry.name.isdigit():
            continue
        try:
            stat_text = (entry / "stat").read_text(encoding="utf-8")
            rest = stat_text.rsplit(")", 1)[1].strip().split()
            state = rest[0]
            member_pgid = int(rest[2])
        except (OSError, ValueError, IndexError):
            continue
        if member_pgid == int(pgid) and state != "Z":
            members.append(int(entry.name))
    return sorted(members)


def process_descendant_identities(root_pid: int) -> list[dict]:
    """Snapshot every non-zombie descendant, including escaped groups.

    Process groups are not an ancestry boundary: a shell can call ``setsid``
    and survive a later ``killpg`` of its role parent. Capturing stable
    ``(pid, start_ticks)`` identities before termination lets the reaper kill
    those already-existing escapees without risking a reused PID.
    """
    rows: dict[int, dict] = {}
    try:
        entries = Path("/proc").iterdir()
    except OSError:
        return []
    for entry in entries:
        if not entry.name.isdigit():
            continue
        try:
            stat_text = (entry / "stat").read_text(encoding="utf-8")
            rest = stat_text.rsplit(")", 1)[1].strip().split()
            state = rest[0]
            pid = int(entry.name)
            rows[pid] = {
                "pid": pid,
                "ppid": int(rest[1]),
                "pgid": int(rest[2]),
                "start_ticks": int(rest[19]),
                "state": state,
            }
        except (OSError, ValueError, IndexError):
            continue

    descendants = []
    frontier = {int(root_pid)}
    while frontier:
        children = [row for row in rows.values()
                    if row["ppid"] in frontier and row["state"] != "Z"]
        if not children:
            break
        descendants.extend(children)
        frontier = {row["pid"] for row in children}
    return sorted(descendants, key=lambda row: row["pid"])


def process_tree_cpu_ticks(root_pid: int) -> Optional[int]:
    """Return cumulative live-tree CPU ticks, or ``None`` if unavailable.

    Linux ``/proc`` utime/stime plus waited-child cutime/cstime provide a
    content-free activity signal. Including the root and every current
    descendant catches useful silent computation without reading commands,
    prompts, output, or environment values.
    """
    if (isinstance(root_pid, bool)
            or not isinstance(root_pid, int) or root_pid < 1):
        return None
    rows: dict[int, dict] = {}
    try:
        entries = Path("/proc").iterdir()
    except OSError:
        return None
    for entry in entries:
        if not entry.name.isdigit():
            continue
        try:
            stat_text = (entry / "stat").read_text(encoding="utf-8")
            rest = stat_text.rsplit(")", 1)[1].strip().split()
            pid = int(entry.name)
            rows[pid] = {
                "ppid": int(rest[1]),
                "ticks": sum(int(rest[index]) for index in range(11, 15)),
            }
        except (OSError, ValueError, IndexError):
            continue
    if root_pid not in rows:
        return None
    members = {root_pid}
    frontier = {root_pid}
    while frontier:
        children = {
            pid for pid, row in rows.items()
            if row["ppid"] in frontier and pid not in members
        }
        members.update(children)
        frontier = children
    return sum(rows[pid]["ticks"] for pid in members)


def progress_paths_fingerprint(paths) -> Optional[str]:
    """Hash only lstat metadata for declared role outputs.

    No file contents are read or persisted. A path creation, replacement,
    size change, or mtime change is enough to count as artifact progress.
    """
    normalized = sorted({str(Path(path)) for path in (paths or ())})
    if not normalized:
        return None
    digest = hashlib.sha256()
    for value in normalized:
        digest.update(value.encode("utf-8", errors="surrogateescape"))
        digest.update(b"\0")
        try:
            stat = Path(value).lstat()
        except OSError:
            digest.update(b"missing\0")
            continue
        digest.update(
            f"{stat.st_mode}:{stat.st_size}:{stat.st_mtime_ns}".encode("ascii")
        )
        digest.update(b"\0")
    return digest.hexdigest()


def _signal_tracked_processes(identities: list[dict], sig: int) -> None:
    """Signal exact process identities, refusing PID-reuse collisions."""
    for identity in reversed(identities):
        pid = int(identity["pid"])
        if not process_is_running(pid, identity.get("start_ticks")):
            continue
        try:
            os.kill(pid, sig)
        except (ProcessLookupError, PermissionError, OSError):
            pass


def terminate_recorded_process_group(pid: int, pgid: int, start_ticks: int,
                                     idea_id: str, timeout: float = 3.0) -> bool:
    """Terminate a durably identified orphan process group.

    Refuses to signal on PID reuse, command mismatch, PGID mismatch, or if the
    recorded group is this orchestrator's group. Returns only after the
    recorded process is absent or a zombie (therefore no longer executing).
    """
    pid = int(pid)
    pgid = int(pgid)
    members = process_group_members(pgid)
    if not members:
        return True
    try:
        current = capture_process_identity(pid)
        cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ")
    except (OSError, ValueError, ProcessLookupError):
        return not process_group_members(pgid)
    expected = idea_id.encode("utf-8")
    if (current["start_ticks"] != int(start_ticks)
            or current["pgid"] != pgid or pgid == os.getpgrp()
            or expected not in cmdline or b"--idea-id" not in cmdline):
        logger.error(
            "Refusing orphan termination for %s: recorded pid/pgid identity no longer matches",
            idea_id,
        )
        return False

    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        return True
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not process_group_members(pgid):
            return True
        time.sleep(0.05)
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        return True
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not process_group_members(pgid):
            return True
        time.sleep(0.05)
    remaining = process_group_members(pgid)
    if remaining:
        logger.error(
            "Orphan process group %d for %s still has live members after SIGKILL: %s",
            pgid, idea_id, remaining,
        )
    return not remaining


def _kill_pg(proc: subprocess.Popen, sig=signal.SIGTERM):
    """Send a signal to the entire process group of *proc*.
    lookup fails (e.g. process already dead).
    """
    try:
        pgid = os.getpgid(proc.pid)
        os.killpg(pgid, sig)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.send_signal(sig)
        except (ProcessLookupError, OSError):
            pass


def _terminate_and_reap(proc: subprocess.Popen, label: str = "",
                        timeout: float = 10, pgid: Optional[int] = None,
                        tracked_identities: Optional[list[dict]] = None,
                        discover_pgid: bool = True):
    """Terminate a process and every descendant in its dedicated group."""
    from orze.engine.supervised_process import SupervisedProcess
    if isinstance(proc, SupervisedProcess):
        # Never discover a now-dead worker's PGID or fall back to raw PID
        # signals. Only its prelaunch supervisor owns the full descendant set.
        return proc.stop(timeout=timeout)
    escaped_descendants = list(tracked_identities or [])
    proc_pid = getattr(proc, "pid", None)
    if type(proc_pid) is int and discover_pgid:
        escaped_descendants.extend(process_descendant_identities(proc_pid))
    # Retain only one record per stable process identity. A role may have
    # observed the same child over many watchdog polls.
    escaped_descendants = list({
        (int(identity["pid"]), int(identity["start_ticks"])): identity
        for identity in escaped_descendants
        if isinstance(identity, dict)
        and type(identity.get("pid")) is int
        and type(identity.get("start_ticks")) is int
    }.values())
    if pgid is None and discover_pgid and type(proc_pid) is int:
        try:
            pgid = os.getpgid(proc_pid)
        except (ProcessLookupError, PermissionError, OSError):
            pgid = None
    if pgid == os.getpgrp():
        logger.error("Refusing to terminate our own process group for %s",
                     label or "process")
        pgid = None

    # Signal captured descendants first. A child that created a separate
    # process group/session is not reached by killpg(pgid); the exact identity
    # check prevents signaling a different process after PID reuse.
    _signal_tracked_processes(escaped_descendants, signal.SIGTERM)
    if pgid is not None:
        try:
            os.killpg(pgid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            pass
    else:
        try:
            proc.terminate()
        except (ProcessLookupError, OSError):
            pass
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        logger.warning("Force killing %s (PID %d)", label or "process", proc.pid)
        if pgid is not None:
            try:
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass
        else:
            try:
                proc.kill()
            except (ProcessLookupError, OSError):
                pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.error("Failed to reap %s (PID %d) after SIGKILL",
                         label or "process", proc.pid)

    # The group leader can exit on SIGTERM while a descendant ignores it.
    # Waiting only for ``proc`` then leaks that descendant indefinitely.
    group_remaining = process_group_members(pgid) if pgid is not None else []
    if pgid is not None:
        if group_remaining:
            logger.warning("Force killing %d surviving descendant(s) of %s: %s",
                           len(group_remaining), label or "process",
                           group_remaining)
            try:
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                pass
            deadline = time.time() + 5
            while time.time() < deadline and process_group_members(pgid):
                time.sleep(0.05)
            group_remaining = process_group_members(pgid)
            if group_remaining:
                logger.error("Failed to reap process group %d for %s: %s",
                             pgid, label or "process", group_remaining)

    escaped_remaining = [
        identity for identity in escaped_descendants
        if process_is_running(identity["pid"], identity.get("start_ticks"))
    ]
    if escaped_remaining:
        logger.warning(
            "Force killing %d escaped descendant(s) of %s: %s",
            len(escaped_remaining), label or "process",
            [identity["pid"] for identity in escaped_remaining],
        )
        _signal_tracked_processes(escaped_remaining, signal.SIGKILL)
        deadline = time.time() + 5
        while time.time() < deadline:
            escaped_remaining = [
                identity for identity in escaped_remaining
                if process_is_running(
                    identity["pid"], identity.get("start_ticks"))
            ]
            if not escaped_remaining:
                break
            time.sleep(0.05)
        if escaped_remaining:
            logger.error(
                "Failed to reap escaped descendant(s) of %s: %s",
                label or "process",
                [identity["pid"] for identity in escaped_remaining],
            )
    return not group_remaining and not escaped_remaining and proc.poll() is not None


_OFFLINE_ENV_KEYS = (
    "HF_HUB_OFFLINE", "HF_DATASETS_OFFLINE", "TRANSFORMERS_OFFLINE",
)


def _truthy_env(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _sha256_file(path: Path) -> Optional[str]:
    try:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError:
        return None


def _drain_and_hash(stream, digest) -> None:
    """Drain a subprocess pipe at constant memory while hashing its bytes."""
    try:
        for block in iter(lambda: stream.read(64 * 1024), b""):
            digest.update(block)
    finally:
        stream.close()


def _artifact_preflight_identity(idea_id: str, results_dir: Path,
                                 cfg: dict) -> dict:
    """Return current hash-only identity for an enabled resolver contract."""
    spec = cfg.get("artifact_preflight") or {}
    results_dir = Path(results_dir)
    idea_dir = results_dir / idea_id
    policy = str(spec.get("network", "inherit")).strip().lower()
    script_text = str(spec.get("script") or "")
    project_root = Path(cfg.get("_project_root", "."))
    script_path = Path(script_text)
    if not script_path.is_absolute():
        script_path = project_root / script_path
    config_path = idea_dir / "idea_config.yaml"
    if not config_path.exists():
        config_path = Path(cfg.get("base_config", "configs/base.yaml"))
        if not config_path.is_absolute():
            config_path = project_root / config_path
    extra_env_raw = cfg.get("train_extra_env") or {}
    extra_env = extra_env_raw if isinstance(extra_env_raw, dict) else {}
    contract = {
        "script": script_text,
        "args": [str(value) for value in (spec.get("args") or [])],
        "interpreter": str(spec.get(
            "interpreter", cfg.get("python", sys.executable)) or ""),
        "network": policy,
        # Bind environment shape and the artifact network switches without
        # hashing arbitrary secret values into a durable offline oracle.
        "train_extra_env_keys": sorted(
            str(key) for key in extra_env),
        "train_extra_env_type": type(extra_env_raw).__name__,
        "offline_flags": {
            key: _truthy_env(str(extra_env.get(
                key, os.environ.get(key, ""))))
            for key in _OFFLINE_ENV_KEYS
        },
    }
    return {
        "network_policy": policy,
        "script_sha256": _sha256_file(script_path),
        "config_sha256": _sha256_file(config_path),
        "contract_sha256": hashlib.sha256(json.dumps(
            contract, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")).hexdigest(),
    }


def verify_artifact_preflight_receipt(idea_id: str, results_dir: Path,
                                      cfg: dict, *, lake=None) -> bool:
    """True only when a passed receipt matches the current launch contract."""
    from orze.engine.artifact_preflight_receipts import (
        capture_preflight_source, require_preflight_history_closed,
    )
    if lake is not None:
        capture_preflight_source(lake, Path(results_dir) / idea_id, cfg)
        return True
    require_preflight_history_closed(lake, Path(results_dir) / idea_id, cfg)
    spec = cfg.get("artifact_preflight") or {}
    if not isinstance(spec, dict) or not spec.get("enabled", False):
        return True
    try:
        receipt = json.loads((
            Path(results_dir) / idea_id / "artifact_preflight.json"
        ).read_text(encoding="utf-8"))
        expected = _artifact_preflight_identity(idea_id, results_dir, cfg)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError,
            ValueError):
        return False
    return (
        isinstance(receipt, dict)
        and receipt.get("schema_version") == 1
        and receipt.get("idea_id") == idea_id
        and receipt.get("status") == "passed"
        and receipt.get("gpu_visibility") == "hidden"
        and all(expected.get(key) is not None
                and receipt.get(key) == expected.get(key)
                for key in (
                    "network_policy", "script_sha256", "config_sha256",
                    "contract_sha256",
                ))
    )


def run_artifact_preflight(idea_id: str, results_dir: Path, cfg: dict, *, lake=None):
    """Run a bounded dataset/model resolver with accelerators hidden.

    The configured script owns domain-specific resolution. Orze enforces the
    execution contract: no visible accelerator, explicit metadata-network
    policy and a non-secret audit receipt. Native calls carry an independent
    occurrence reference and require owned tree closure; legacy calls retain
    their bool API and explicitly limited process-group compatibility path.
    """
    spec = cfg.get("artifact_preflight") or {}
    from orze.engine.artifact_preflight_receipts import require_preflight_history_closed
    enabled = isinstance(spec, dict) and bool(spec.get("enabled", False))
    if lake is None or not enabled:
        require_preflight_history_closed(lake, Path(results_dir) / idea_id, cfg)
    if lake is not None and enabled:
        from orze.engine.native_artifact_preflight import run_native_artifact_preflight
        return run_native_artifact_preflight(idea_id, results_dir, cfg, lake)
    if not isinstance(spec, dict) or not spec.get("enabled", False):
        return True

    started = time.time()
    results_dir = Path(results_dir)
    idea_dir = results_dir / idea_id
    idea_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = idea_dir / "artifact_preflight.json"
    policy = str(spec.get("network", "inherit")).strip().lower()
    script_text = str(spec.get("script") or "")
    project_root = Path(cfg.get("_project_root", "."))
    script_path = Path(script_text)
    if not script_path.is_absolute():
        script_path = project_root / script_path
    config_path = idea_dir / "idea_config.yaml"
    if not config_path.exists():
        config_path = Path(cfg.get("base_config", "configs/base.yaml"))
        if not config_path.is_absolute():
            config_path = project_root / config_path

    identity = _artifact_preflight_identity(idea_id, results_dir, cfg)
    receipt = {
        "schema_version": 1,
        "idea_id": idea_id,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "gpu_visibility": "hidden",
        **identity,
    }

    def finish(status: str, **fields) -> bool:
        receipt.update(fields)
        receipt["status"] = status
        receipt["finished_at"] = datetime.datetime.now(
            datetime.timezone.utc).isoformat()
        receipt["duration_seconds"] = round(time.time() - started, 3)
        from orze.core.fs import atomic_write
        atomic_write(receipt_path, json.dumps(receipt, indent=2) + "\n")
        return status == "passed"

    if policy not in {"inherit", "required", "offline"}:
        return finish("configuration_error", reason="invalid_network_policy")
    if not script_text or not script_path.is_file():
        return finish("configuration_error", reason="script_missing")

    extra_env = cfg.get("train_extra_env") or {}
    if not isinstance(extra_env, dict):
        return finish("configuration_error", reason="train_extra_env_not_mapping")
    env = os.environ.copy()
    for key, value in extra_env.items():
        env[key] = str(value)
    offline_conflicts = [key for key in _OFFLINE_ENV_KEYS
                         if _truthy_env(env.get(key, ""))]
    if policy == "required" and offline_conflicts:
        return finish(
            "configuration_error",
            reason="network_required_but_offline_flags_set",
            conflicting_env_keys=offline_conflicts,
        )
    if policy == "offline":
        for key in _OFFLINE_ENV_KEYS:
            env[key] = "1"

    env.update({
        "CUDA_VISIBLE_DEVICES": "",
        "NVIDIA_VISIBLE_DEVICES": "none",
        "HIP_VISIBLE_DEVICES": "",
        "ROCR_VISIBLE_DEVICES": "",
        "ORZE_ARTIFACT_PREFLIGHT": "1",
        "ORZE_ARTIFACT_NETWORK_POLICY": policy,
        "ORZE_IDEA_ID": idea_id,
        "ORZE_RESULTS_DIR": str(results_dir),
        "ORZE_IDEA_CONFIG": str(config_path),
    })

    from orze.engine.launcher import _format_args
    values = {
        "idea_id": idea_id,
        "results_dir": str(results_dir),
        "config": str(config_path),
        "project_root": str(project_root),
    }
    interpreter = spec.get("interpreter", cfg.get("python", sys.executable))
    cmd = ([str(interpreter)] if interpreter else []) + [str(script_path)]
    cmd.extend(_format_args(spec.get("args") or [], values))
    timeout = float(spec.get("timeout", 300))

    logger.info("Running zero-GPU artifact preflight for %s (%s network)",
                idea_id, policy)
    proc = None
    stdout_digest = hashlib.sha256()
    stderr_digest = hashlib.sha256()
    drain_threads = []
    try:
        proc = subprocess.Popen(
            cmd, env=env, cwd=str(project_root),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            start_new_session=True,
        )
        for stream, digest in (
                (proc.stdout, stdout_digest),
                (proc.stderr, stderr_digest)):
            thread = threading.Thread(
                target=_drain_and_hash, args=(stream, digest), daemon=True)
            thread.start()
            drain_threads.append(thread)
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        assert proc is not None
        _terminate_and_reap(proc, f"artifact preflight {idea_id}",
                            timeout=1, pgid=proc.pid)
        for thread in drain_threads:
            thread.join()
        return finish(
            "timed_out", timeout_seconds=timeout,
            stdout_sha256=stdout_digest.hexdigest(),
            stderr_sha256=stderr_digest.hexdigest(),
        )
    except Exception as exc:
        if proc is not None:
            _terminate_and_reap(proc, f"artifact preflight {idea_id}",
                                timeout=1, pgid=proc.pid)
        for thread in drain_threads:
            thread.join()
        return finish("execution_error", reason=type(exc).__name__)

    for thread in drain_threads:
        thread.join()

    fields = {
        "exit_code": proc.returncode,
        "stdout_sha256": stdout_digest.hexdigest(),
        "stderr_sha256": stderr_digest.hexdigest(),
    }
    if proc.returncode != 0:
        logger.warning("Artifact preflight failed for %s (exit %d)",
                       idea_id, proc.returncode)
        return finish("failed", **fields)
    logger.info("Artifact preflight passed for %s", idea_id)
    return finish("passed", **fields)


# ---------------------------------------------------------------------------
# Utilities

@dataclass
class TrainingProcess:
    """Tracks a non-blocking training subprocess."""
    idea_id: str
    gpu: int
    process: subprocess.Popen
    start_time: float
    log_path: Path
    timeout: float
    train_script: Optional[str] = None
    config_path: Optional[str] = None
    attempt_id: Optional[str] = None
    execution_identity: Optional[str] = None
    attempt_ref: Any = field(default=None, repr=False)
    _termination_unconfirmed: bool = field(default=False, repr=False)
    _log_fh: Any = field(default=None, repr=False)
    _last_log_size: int = field(default=0, repr=False)
    _last_log_check: float = field(default=0.0, repr=False)
    _stall_since: float = field(default=0.0, repr=False)

    def close_log(self):
        """Close the log file handle if open."""
        if self._log_fh and not self._log_fh.closed:
            try:
                self._log_fh.close()
            except Exception:
                pass


@dataclass
class EvalProcess:
    """Tracks a non-blocking eval subprocess."""
    idea_id: str
    gpu: int
    process: subprocess.Popen
    start_time: float
    log_path: Path
    timeout: float
    attempt_id: Optional[str] = None
    attempt_ref: Any = field(default=None, repr=False)
    _termination_unconfirmed: bool = field(default=False, repr=False)
    _log_fh: Any = field(default=None, repr=False)

    def close_log(self):
        if self._log_fh and not self._log_fh.closed:
            try:
                self._log_fh.close()
            except Exception:
                pass


@dataclass
class RoleProcess:
    """Tracks a non-blocking agent role subprocess."""
    role_name: str
    process: subprocess.Popen
    start_time: float
    log_path: Path
    timeout: float
    lock_dir: Path
    cycle_num: int
    _log_fh: Any = field(default=None, repr=False)
    ideas_pre_size: int = 0  # ideas.md size before role started
    ideas_pre_count: int = 0  # idea count before role started
    # Running tally of ideas consumed from ideas.md while this role was
    # still active. Incremented by the consumption phase whenever it
    # ingests ideas and a research-writer role is running. Used to avoid
    # the _ideas_were_modified false-negative where a role appends ideas
    # that get consumed (ideas.md wiped) before the role exits — without
    # this counter, the post-exit size/count check cannot distinguish
    # "appended then consumed" from "never appended".
    ideas_consumed_during_run: int = 0
    # ideas.md mtime snapshot taken at role launch. Used as a cross-daemon
    # fallback signal: in multi-daemon deployments (shared ideas.md,
    # separate active_roles dicts) the ideas_consumed_during_run counter
    # is only incremented by the daemon whose active_roles contains this
    # RoleProcess. If a DIFFERENT daemon performs the consumption (wipes
    # ideas.md), this daemon's counter stays 0 and the size/count check
    # also returns False (ideas_pre_size matches the post-wipe size by
    # coincidence). mtime changes on any write to the shared file, so
    # current_mtime > ideas_md_mtime_pre means ideas.md was touched
    # during the role's lifetime — enough to credit the role.
    ideas_md_mtime_pre: float = 0.0
    # Stall-detection state. Mirrors TrainingProcess: `_last_log_size`
    # tracks the last observed log bytes and `_stall_since` is the
    # epoch-time the log last stopped growing. Used by
    # check_active_roles to kill roles whose stdout has been silent for
    # longer than `role_stall_minutes` — catches claude-CLI hangs that
    # produce a 0-byte log and would otherwise burn the full wall-clock
    # timeout.
    _last_log_size: int = field(default=0, repr=False)
    _stall_since: float = field(default=0.0, repr=False)
    # Round-2 B2: optional per-role override of role_stall_minutes.
    # When None, the global ``role_stall_minutes`` (from orze.yaml) is
    # used. Roles with `<role>.stall_minutes:` set this at launch so
    # check_active_roles can enforce a per-role timer instead of the
    # global one.
    stall_minutes_override: Optional[float] = None
    # Round-2 B3: warmup tolerance — the stall timer doesn't begin
    # counting until either (a) the first stdout byte is observed, or
    # (b) ``stall_warmup_seconds`` has elapsed since process spawn,
    # whichever is sooner. This protects LLM-mode roles whose first
    # 30-90s is model init / skill composition with no stdout yet.
    stall_warmup_seconds: float = 60.0
    # Declared output paths are monitored by metadata only. Together with
    # process-tree CPU ticks and log growth, this makes the no-progress
    # watchdog distinguish a genuine stall from silent useful work.
    progress_paths: tuple[Path, ...] = field(default_factory=tuple)
    _last_cpu_ticks: Optional[int] = field(default=None, repr=False)
    _last_progress_fingerprint: Optional[str] = field(default=None, repr=False)
    _last_progress_kinds: tuple[str, ...] = field(
        default_factory=tuple, repr=False)
    # Operator-visible progress timing. These are metadata-only epochs updated
    # by the watchdog; no prompt, log, command, or artifact content is retained.
    _last_progress_at: float = field(default=0.0, repr=False)
    _last_observed_at: float = field(default=0.0, repr=False)
    # True for research-type roles whose job is to append to ideas.md.
    # False for strategy roles (professor, data_analyst, thinker,
    # engineer, code_evolution) that modify other files — skipping the
    # ideas-modified soft-failure check for those avoids spurious
    # "completed successfully but ideas file was not modified" warnings.
    writes_ideas_file: bool = True
    # Stable process identities observed while the role is alive. Keeping
    # live descendants across polls lets normal-exit and graceful-shutdown
    # paths reap children that reparented themselves with setsid().
    _root_start_ticks: Optional[int] = field(default=None, repr=False)
    _pgid: Optional[int] = field(default=None, repr=False)
    _tracked_descendants: list[dict] = field(default_factory=list, repr=False)
    # Per-launch capability injected into the role environment. Only its hash
    # is persisted; startup rechecks the live process environment before any
    # crash-recovery signal is authorized.
    process_nonce: Optional[str] = field(default=None, repr=False)
    _receipt_error: bool = field(default=False, repr=False)
    # Captured delivery identity, independent of mutable role_state. These
    # fields confer no process-signalling authority; nonce identities still do.
    trigger_delivery_db: Optional[str] = field(default=None, repr=False)
    trigger_launch: Optional[dict] = field(default=None, repr=False)
    # Native proposal-result identity is captured at dispatch, never recovered
    # from mutable role_state or shared ideas.md after the child exits.
    native_result_ref: Optional[dict] = field(default=None, repr=False)
    native_result_details: Optional[dict] = field(default=None, repr=False)
    supervision_owner: Any = field(default=None, repr=False)

    def __post_init__(self):
        if self.trigger_launch is not None:
            from copy import deepcopy
            self.trigger_launch = deepcopy(self.trigger_launch)
        if self.native_result_ref is not None:
            from orze.core.research_result import (
                NativeResultError, validate_native_result_ref,
            )
            self.native_result_ref = validate_native_result_ref(
                self.native_result_ref, process_nonce=self.process_nonce)
            if (self.native_result_ref["role_name"] != self.role_name
                    or (self.trigger_launch is not None
                        and self.native_result_ref["attempt_id"]
                        != self.trigger_launch.get("attempt_id"))):
                raise NativeResultError("native_result_process_binding_invalid")
        if self._last_progress_at <= 0:
            self._last_progress_at = float(self.start_time)
        if self._last_observed_at <= 0:
            self._last_observed_at = float(self.start_time)
        from orze.engine.role_supervision import supervised_role_owner
        owner = supervised_role_owner(self)
        if owner is not None:
            # The READY worker has not exec'd its user environment yet. Its
            # exact protocol binding, not a pre-GO /proc nonce scan, is proof.
            owner.bind_role(self)
            return
        pid = getattr(self.process, "pid", None)
        if type(pid) is not int:
            return
        try:
            identity = capture_process_identity(pid)
        except (OSError, ValueError, ProcessLookupError):
            nonce_hash = _role_nonce_sha256(self.process_nonce)
            if self.process_nonce is not None:
                matches = (_process_identities_with_nonce_hash(nonce_hash)
                           if nonce_hash is not None else None)
                if matches is not None:
                    _reap_exact_identities(matches, timeout=3)
                raise RuntimeError("role_process_identity_capture_failed")
            return
        self._root_start_ticks = identity["start_ticks"]
        self._pgid = identity["pgid"]
        if self.process_nonce is not None:
            if (not isinstance(self.process_nonce, str)
                    or len(self.process_nonce) != 64
                    or any(char not in "0123456789abcdef"
                           for char in self.process_nonce)
                    or not _process_has_nonce_hash(
                        pid, hashlib.sha256(
                            self.process_nonce.encode("ascii")).hexdigest())):
                _terminate_and_reap(
                    self.process, f"unattested role {self.role_name}",
                    timeout=3, pgid=self._pgid)
                raise RuntimeError("role_process_receipt_initialization_failed")
        refresh_role_process_descendants(self)
        if self._receipt_error:
            _terminate_and_reap(
                self.process, f"unattested role {self.role_name}",
                timeout=3, pgid=self._pgid)
            raise RuntimeError("role_process_receipt_initialization_failed")

    def close_log(self):
        if self._log_fh and not self._log_fh.closed:
            try:
                self._log_fh.close()
            except Exception:
                pass


def refresh_role_process_descendants(rp: RoleProcess) -> int:
    """Refresh the live stable-identity set for a managed role.

    Dead identities are pruned, so process churn cannot grow this state
    indefinitely. The return value is the current number of retained live
    descendants.
    """
    from orze.engine.role_supervision import supervised_role_owner
    if supervised_role_owner(rp) is not None:
        # Complete descendant ownership belongs to the prelaunch subreaper.
        # Legacy ancestry/nonce snapshots must not replace that authority.
        return 0
    pid = getattr(rp.process, "pid", None)
    if type(pid) is not int:
        return 0
    retained = {
        (int(identity["pid"]), int(identity["start_ticks"])): identity
        for identity in getattr(rp, "_tracked_descendants", [])
        if isinstance(identity, dict)
        and type(identity.get("pid")) is int
        and type(identity.get("start_ticks")) is int
        and process_is_running(identity["pid"], identity["start_ticks"])
    }
    root_start_ticks = getattr(rp, "_root_start_ticks", None)
    if (root_start_ticks is not None
            and process_is_running(pid, root_start_ticks)):
        for identity in process_descendant_identities(pid):
            retained[(identity["pid"], identity["start_ticks"])] = identity
    rp._tracked_descendants = sorted(
        retained.values(), key=lambda identity: identity["pid"])
    if rp.process_nonce is not None and not persist_role_process_receipt(rp):
        rp._receipt_error = True
    return len(rp._tracked_descendants)


def _process_has_nonce_hash(pid: int, expected_sha256: str) -> bool:
    """Verify the role nonce without returning or logging environment data."""
    try:
        payload = Path(f"/proc/{int(pid)}/environ").read_bytes()
    except (OSError, ValueError):
        return False
    prefix = b"ORZE_ROLE_PROCESS_NONCE="
    values = [item[len(prefix):] for item in payload.split(b"\0")
              if item.startswith(prefix)]
    return (len(values) == 1
            and hashlib.sha256(values[0]).hexdigest() == expected_sha256)


def _role_nonce_sha256(nonce: object) -> Optional[str]:
    if (not isinstance(nonce, str) or len(nonce) != 64
            or any(char not in "0123456789abcdef" for char in nonce)):
        return None
    return hashlib.sha256(nonce.encode("ascii")).hexdigest()


def _process_identities_with_nonce_hash(
        nonce_sha256: Optional[str]) -> Optional[list[dict]]:
    """Return a bounded identity set matching one role capability hash."""
    if nonce_sha256 is None:
        return None
    try:
        entries = Path("/proc").iterdir()
    except OSError:
        return None
    matches = []
    for entry in entries:
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        if not _process_has_nonce_hash(pid, nonce_sha256):
            continue
        try:
            matches.append(capture_process_identity(pid))
        except (OSError, ValueError, ProcessLookupError):
            continue
        if len(matches) > _MAX_ROLE_DESCENDANTS:
            return None
    return matches


def _reap_exact_identities(identities: list[dict], timeout: float) -> bool:
    """Terminate only stable identities already authorized by a role nonce."""
    identities = list({
        (item["pid"], item["start_ticks"]): item for item in identities
    }.values())
    _signal_tracked_processes(identities, signal.SIGTERM)
    deadline = time.time() + timeout
    while time.time() < deadline and any(
            process_is_running(item["pid"], item["start_ticks"])
            for item in identities):
        time.sleep(0.05)
    remaining = [
        item for item in identities
        if process_is_running(item["pid"], item["start_ticks"])
    ]
    if remaining:
        _signal_tracked_processes(remaining, signal.SIGKILL)
        deadline = time.time() + timeout
        while time.time() < deadline and any(
                process_is_running(item["pid"], item["start_ticks"])
                for item in remaining):
            time.sleep(0.05)
        remaining = [
            item for item in remaining
            if process_is_running(item["pid"], item["start_ticks"])
        ]
    return not remaining


def _legacy_role_receipt_file_identity(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _legacy_role_receipt_identity(path: Path) -> tuple:
    """Capture the named legacy receipt and its unredirected parent chain.

    This is a read/recheck witness, not permission to reap a process or an
    atomic-unlink primitive. Directory timestamps are deliberately excluded.
    """
    path = Path(path).absolute()
    if ".." in path.parts:
        raise OSError("role_receipt_path_invalid")
    identities = []
    for parent in reversed(path.parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode):
            raise OSError("role_receipt_parent_redirected")
        identities.append((str(parent), True,
                           (info.st_dev, info.st_ino, info.st_mode)))
    info = path.lstat()
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
            or not 0 <= info.st_size <= _MAX_ROLE_RECEIPT_BYTES):
        raise OSError("role_receipt_file_invalid")
    identities.append((str(path), False, _legacy_role_receipt_file_identity(info)))
    return tuple(identities)


def _read_legacy_role_receipt(path: Path) -> tuple[bytes, tuple]:
    """Read a complete, stable legacy role receipt within its own 1 MiB cap.

    Initial absence keeps the existing FileNotFoundError contract. A file
    disappearing after capture is uncertainty, not a clean missing receipt.
    The generic effect reader and owned-v2 receipt limits are unchanged.
    """
    path = Path(path).absolute()
    captured = _legacy_role_receipt_identity(path)
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        before = os.fstat(fd)
        if _legacy_role_receipt_file_identity(before) != captured[-1][2]:
            raise OSError("role_receipt_changed")
        chunks, total = [], 0
        while total <= before.st_size:
            chunk = os.read(fd, min(65536, before.st_size + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
        if (total != before.st_size
                or _legacy_role_receipt_file_identity(os.fstat(fd)) != captured[-1][2]
                or _legacy_role_receipt_identity(path) != captured):
            raise OSError("role_receipt_changed")
        return b"".join(chunks), captured
    except OSError as exc:
        raise OSError("role_receipt_read_unconfirmed") from exc
    finally:
        if fd is not None:
            os.close(fd)


def _atomic_private_json(path: Path, payload: dict) -> None:
    """Atomically persist a private controller receipt with fsync."""
    encoded = (json.dumps(payload, sort_keys=True, separators=(",", ":"))
               + "\n").encode("utf-8")
    if len(encoded) > _MAX_ROLE_RECEIPT_BYTES:
        raise OSError("role_receipt_size_limit")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.is_symlink() or not path.parent.is_dir():
        raise OSError("role receipt parent is not a real directory")
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{secrets.token_hex(6)}")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        remaining = memoryview(encoded)
        while remaining:
            written = os.write(fd, remaining)
            if written <= 0:
                raise OSError("short role receipt write")
            remaining = remaining[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)
    dir_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def persist_role_process_receipt(rp: RoleProcess) -> bool:
    """Persist hash-only crash-recovery authority for one managed role."""
    from orze.engine.role_supervision import supervised_role_owner
    if supervised_role_owner(rp) is not None:
        # The v2 owner already persists each exact protocol transition.
        return True
    if rp.process_nonce is None or rp._root_start_ticks is None or rp._pgid is None:
        return False
    try:
        controller = capture_process_identity(os.getpid())
        descendants = [
            {
                "pid": identity["pid"],
                "pgid": identity["pgid"],
                "start_ticks": identity["start_ticks"],
            }
            for identity in rp._tracked_descendants[:_MAX_ROLE_DESCENDANTS]
        ]
        if len(rp._tracked_descendants) > _MAX_ROLE_DESCENDANTS:
            return False
        payload = {
            "schema_version": _ROLE_RECEIPT_VERSION,
            "role_name": rp.role_name,
            "host": socket.gethostname(),
            "controller": controller,
            "root": {
                "pid": int(rp.process.pid),
                "pgid": int(rp._pgid),
                "start_ticks": int(rp._root_start_ticks),
            },
            "nonce_sha256": hashlib.sha256(
                rp.process_nonce.encode("ascii")).hexdigest(),
            "descendants": descendants,
            "updated_ns": time.time_ns(),
        }
        if rp.trigger_launch is not None:
            from orze.engine.role_delivery import delivery_reference
            payload["trigger_delivery"] = delivery_reference(rp)
        _atomic_private_json(rp.lock_dir / _ROLE_PROCESS_RECEIPT, payload)
        return True
    except (OSError, TypeError, ValueError, KeyError):
        return False


def _valid_identity(value: object) -> bool:
    return (isinstance(value, dict)
            and type(value.get("pid")) is int and value["pid"] > 0
            and type(value.get("pgid")) is int and value["pgid"] > 0
            and type(value.get("start_ticks")) is int
            and value["start_ticks"] > 0)


def reconcile_orphaned_role_receipts(
    orze_dir: Path,
    hostname: Optional[str] = None,
    timeout: float = 3,
) -> dict:
    """Reap locally orphaned roles from bounded, nonce-bound receipts.

    Receipts from another host are left untouched. Invalid or unverifiable
    local receipts fail closed and authorize no signals.
    """
    hostname = hostname or socket.gethostname()
    lock_root = Path(orze_dir) / "locks"
    report = {"recovered": [], "remote": [], "errors": []}
    if not lock_root.exists():
        return report
    try:
        entries = sorted(lock_root.iterdir(), key=lambda path: path.name)
    except OSError:
        report["errors"].append("role_receipt_lock_root_unreadable")
        return report
    for entry in entries:
        if entry.name.startswith('.') and entry.name.endswith('.role-transition'):
            role = entry.name[1:-len('.role-transition')]
            report["errors"].append(f"role_storage_transition_unconfirmed:{role}")
    receipt_entries = [
        entry for entry in entries
        if entry.is_dir() and (
            (entry / _ROLE_PROCESS_RECEIPT).exists()
            or (entry / _ROLE_PROCESS_RECEIPT).is_symlink()
        )
    ]
    if len(receipt_entries) > _MAX_ROLE_RECEIPTS:
        report["errors"].append("role_receipt_count_exceeded")
        return report

    for lock_dir in receipt_entries:
        role = lock_dir.name
        receipt_path = lock_dir / _ROLE_PROCESS_RECEIPT
        try:
            if lock_dir.is_symlink() or receipt_path.is_symlink():
                raise ValueError("redirected")
            if receipt_path.stat().st_size > _MAX_ROLE_RECEIPT_BYTES:
                raise ValueError("oversized")
            receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
            report["errors"].append(f"role_receipt_invalid:{role}")
            continue
        if not isinstance(receipt, dict):
            report["errors"].append(f"role_receipt_invalid:{role}")
            continue
        if receipt.get("schema_version") == 2:
            # A previous controller's v2 intent is never authority for the
            # legacy nonce scanner, even if its recorded PID has disappeared.
            report["errors"].append(f"role_supervision_recovery_required:{role}")
            continue
        receipt_role = receipt.get("role_name")
        nonce_sha256 = receipt.get("nonce_sha256")
        descendants = receipt.get("descendants")
        if (receipt.get("schema_version") != _ROLE_RECEIPT_VERSION
                or receipt_role != role
                or not isinstance(receipt.get("host"), str)
                or not _valid_identity(receipt.get("controller"))
                or not _valid_identity(receipt.get("root"))
                or not isinstance(nonce_sha256, str)
                or len(nonce_sha256) != 64
                or any(char not in "0123456789abcdef"
                       for char in nonce_sha256)
                or not isinstance(descendants, list)
                or len(descendants) > _MAX_ROLE_DESCENDANTS
                or any(not _valid_identity(item) for item in descendants)):
            report["errors"].append(f"role_receipt_invalid:{role}")
            continue
        if receipt["host"] != hostname:
            report["remote"].append(role)
            continue

        controller = receipt["controller"]
        if process_is_running(controller["pid"], controller["start_ticks"]):
            report["errors"].append(f"role_controller_still_live:{role}")
            continue

        nonce_matches = _process_identities_with_nonce_hash(nonce_sha256)
        if nonce_matches is None:
            report["errors"].append(f"role_receipt_nonce_scan_failed:{role}")
            continue
        records = [receipt["root"], *descendants, *nonce_matches]
        root = receipt["root"]
        if process_is_running(root["pid"], root["start_ticks"]):
            records.extend(process_descendant_identities(root["pid"]))
        live = {
            (record["pid"], record["start_ticks"]): record
            for record in records
            if process_is_running(record["pid"], record["start_ticks"])
        }
        if any(not _process_has_nonce_hash(record["pid"], nonce_sha256)
               for record in live.values()):
            report["errors"].append(f"role_receipt_nonce_mismatch:{role}")
            continue

        identities = sorted(live.values(), key=lambda item: item["pid"])
        if not _reap_exact_identities(identities, timeout):
            report["errors"].append(f"role_receipt_reap_failed:{role}")
            continue
        try:
            shutil.rmtree(lock_dir)
        except OSError:
            report["errors"].append(f"role_receipt_cleanup_failed:{role}")
            continue
        report["recovered"].append(role)
    return report


def terminate_role_process(
    rp: RoleProcess,
    label: str,
    timeout: float = 10,
    *,
    reaper=None,
) -> bool:
    """Terminate a role using its stable root and descendant identities."""
    from orze.engine.role_supervision import supervised_role_owner
    owner = supervised_role_owner(rp)
    if owner is not None:
        owner.abort(timeout=timeout)
        owner.require_closed()
        # Receipt and lock release belong to exact delivery settlement, not
        # this process stop. No None/truthy legacy reaper grants v2 closure.
        return True
    refresh_role_process_descendants(rp)
    pid = getattr(rp.process, "pid", None)
    root_live = (
        type(pid) is int
        and rp._root_start_ticks is not None
        and process_is_running(pid, rp._root_start_ticks)
    )
    # Never signal a numeric process group after its recorded leader has
    # exited: Linux may already have reused that ID. Exact retained descendant
    # identities remain safe to signal after reparenting.
    pgid = rp._pgid if root_live else None
    tracked = list(rp._tracked_descendants)
    nonce_scan_ok = True
    if rp.process_nonce is not None:
        matches = _process_identities_with_nonce_hash(
            _role_nonce_sha256(rp.process_nonce))
        if matches is None:
            nonce_scan_ok = False
        else:
            tracked.extend(matches)
    result = (reaper or _terminate_and_reap)(
        rp.process,
        label,
        timeout=timeout,
        pgid=pgid,
        tracked_identities=tracked,
        discover_pgid=root_live,
    )
    clean = result is not False and nonce_scan_ok
    if clean and getattr(rp, "trigger_launch", None) is None:
        try:
            (rp.lock_dir / _ROLE_PROCESS_RECEIPT).unlink(missing_ok=True)
        except OSError:
            clean = False
    rp._tracked_descendants.clear()
    # Legacy/mocked reapers returned None; only an explicit False means the
    # termination proof failed.
    return clean


def run_pre_script(idea_id: str, gpu: int, cfg: dict,
                   results_dir: Optional[Path] = None, *, lake=None):
    """Run project setup without granting it an accelerator.

    Admission continues after this hook, so allocating a GPU here would let a
    subsequently rejected idea consume compute while its claim is recorded as
    zero-GPU.  Keep the historical ``gpu`` and ``results_dir`` parameters for
    callers, but do not expose the selected physical GPU, acquire its lease, or
    create a GPU compute attempt. Native calls return a truth-valued result
    with a captured pre-script reference, independent of the training claim.
    Unknown execution raises HOLD; only confirmed failure may be reported as
    a zero-GPU admission outcome. The no-Lake compatibility path remains bool.
    """
    import sys
    pre_script = cfg.get("pre_script")
    from orze.engine.native_pre_script import (
        PreScriptHOLD, require_launch_ready, run_native_pre_script,
    )
    if results_dir is None and cfg.get("results_dir") is not None:
        results_dir = Path(cfg["results_dir"])
    if results_dir is None and lake is not None:
        raise PreScriptHOLD("pre_script_scope_required")
    if results_dir is not None:
        from orze.engine.artifact_preflight_receipts import require_preflight_history_closed
        require_preflight_history_closed(lake, Path(results_dir) / idea_id, cfg)
    if results_dir is not None and (not pre_script or lake is None):
        # Removing configuration or in-memory wiring cannot erase an existing
        # unresolved native action. This precedes even the no-script return.
        require_launch_ready(lake, Path(results_dir) / idea_id, cfg)
    if not pre_script:
        return True

    python = cfg.get("python", sys.executable)
    pre_args = cfg.get("pre_args") or []
    pre_timeout = cfg.get("pre_timeout", 3600)

    from orze.engine.launcher import _format_args
    cmd = [python, pre_script]
    cmd.extend(_format_args(pre_args, {"idea_id": idea_id, "gpu": -1}))

    env = os.environ.copy()
    for k, v in (cfg.get("train_extra_env") or {}).items():
        env[k] = str(v)
    # Apply these last so train_extra_env cannot accidentally restore a GPU
    # mapping.  This is a cooperative CPU-only boundary; arbitrary setup code
    # is not treated as trusted accelerator work by the harness.
    env["CUDA_VISIBLE_DEVICES"] = ""
    env["NVIDIA_VISIBLE_DEVICES"] = ""
    env["HIP_VISIBLE_DEVICES"] = ""
    env["ROCR_VISIBLE_DEVICES"] = ""

    logger.info("Running CPU-only pre-script for %s", idea_id)
    if lake is not None:
        return run_native_pre_script(
            idea_id, gpu, results_dir, cfg, lake, cmd, pre_timeout, env)
    proc = None
    try:
        proc = subprocess.Popen(
            cmd, env=env, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True,
            preexec_fn=_new_process_group,
        )
        _, stderr = proc.communicate(timeout=pre_timeout)
        if proc.returncode == 0:
            logger.info("Pre-script OK for %s", idea_id)
            return True
        logger.warning("Pre-script failed for %s (exit %d): %s",
                       idea_id, proc.returncode,
                       stderr[-200:] if stderr else "")
        return False
    except subprocess.TimeoutExpired:
        logger.warning("Pre-script timed out for %s after %ds",
                       idea_id, pre_timeout)
        _terminate_and_reap(proc, f"pre-script {idea_id}")
        return False
    except Exception as e:
        if proc is not None and proc.poll() is None:
            _terminate_and_reap(proc, f"pre-script {idea_id}", timeout=3)
        logger.warning("Pre-script error for %s: %s", idea_id, e)
        return False


def _new_process_group():
    """preexec_fn for subprocess.Popen to create a new process group."""
    os.setpgrp()
