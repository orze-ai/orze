"""Strict opt-in boundaries for local controller stop and one-shot handoff.

This module is metadata-only: it does not register a controller, open a
database, discover GPUs, stop processes, clear markers or authorize restart.
Disabled legacy configurations are not revalidated against this profile.
Fingerprints bind parsed public JSON plus resolved launch/control paths and
the exact physical GPU set; private runtime additions are excluded. A caller
must recompute against its own captured fingerprint, not trust a public stamp.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path

from orze.core.role_presets import configured_role_presets


class ControllerProfileError(ValueError):
    """Stable, content-free refusal before unsupported profile side effects."""


def _reject(reason):
    raise ControllerProfileError("controller_profile_" + reason)


def _mapping(cfg, name):
    value = cfg.get(name)
    if value is None:
        return {}
    if type(value) is not dict:
        _reject(name + "_invalid")
    return value


def _gpus(value):
    if (type(value) is not list or not value
            or any(type(item) is not int or item < 0 for item in value)
            or len(value) != len(set(value))):
        _reject("explicit_gpus_required")
    return sorted(value)


def controller_profile(cfg):
    """Return a detached exact declaration, or None for the disabled profile."""
    if cfg is None:
        return None
    if type(cfg) is not dict:
        _reject("config_invalid")
    declaration = cfg.get("controller_control")
    if declaration is None:
        return None
    if (type(declaration) is not dict or set(declaration) != {"version", "profile"}
            or type(declaration["version"]) is not int
            or type(declaration["profile"]) is not str
            or (declaration["version"], declaration["profile"]) not in (
                (1, "local_stop_v1"), (2, "local_handoff_v1"),
                (1, "local_cpu_stop_v1"), (2, "local_cpu_handoff_v1"))):
        _reject("declaration_invalid")
    if any(name in cfg for name in ("_managed_idea_id", "_managed_idea_gpu")):
        _reject("managed_mode_unsupported")
    if "strategy_team" in configured_role_presets(cfg):
        _reject("dynamic_roles_unsupported")
    _physical_gpus(cfg)
    if cfg.get("telemetry", True) is not False:
        _reject("telemetry_unsupported")
    if cfg.get("auto_upgrade", True) is not False:
        _reject("auto_upgrade_unsupported")
    for name in ("bot", "telegram_bot"):
        if cfg.get(name) is not None:
            _reject(name + "_unsupported")
    for name in ("notifications", "retrospection"):
        if _mapping(cfg, name).get("enabled", False) is not False:
            _reject(name + "_unsupported")
    cleanup = _mapping(cfg, "cleanup")
    if cleanup.get("script") not in (None, ""):
        _reject("cleanup_script_unsupported")
    harvest = _mapping(cfg, "metric_harvest")
    if (harvest.get("enabled", True) is not False
            and harvest.get("llm_fallback", True) is not False):
        _reject("metric_llm_unsupported")
    if type(cfg.get("max_fix_attempts", 0)) is not int or cfg.get("max_fix_attempts", 0) != 0:
        _reject("implicit_repair_unsupported")
    for name in ("containers", "remote", "fleet"):
        if cfg.get(name) not in (None, {}, []):
            _reject(name + "_unsupported")
    if _mapping(cfg, "substrate").get("elo_ranking_enabled", False) is not False:
        _reject("elo_ranking_unsupported")
    if any(type(key) is not str for key in cfg):
        _reject("json_invalid")
    _json_value({key: value for key, value in cfg.items() if not key.startswith("_")})
    return {"version": declaration["version"], "profile": declaration["profile"]}


def _physical_gpus(cfg):
    from orze.core.cpu_execution import cpu_execution, cpu_controller_profile
    value = _mapping(cfg, "gpu_scheduling").get("allowed_gpus")
    if cpu_controller_profile(cfg):
        if cpu_execution(cfg) is None:
            _reject("cpu_execution_required")
        if value is not None and (type(value) is not list or value):
            _reject("cpu_gpu_scope_unsupported")
        return []
    return _gpus(value)


def handoff_profile(cfg):
    """Whether the exact validated profile supports the one-successor protocol."""
    value = controller_profile(cfg)
    return value is not None and value["version"] == 2


def _json_value(value, depth=0):
    if depth > 32:
        _reject("json_invalid")
    if value is None or type(value) in (bool, int, str):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for item in value:
            _json_value(item, depth + 1)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _json_value(item, depth + 1)
        return
    _reject("json_invalid")


def profile_fingerprint(cfg, gpu_ids=None):
    """Hash the complete supported parsed configuration without publishing it."""
    if controller_profile(cfg) is None:
        return None
    allowed = _physical_gpus(cfg)
    if gpu_ids is not None and (type(gpu_ids) is not list or
            (gpu_ids != [] if not allowed else _gpus(gpu_ids) != allowed)):
        _reject("gpu_scope_changed")
    public = {key: value for key, value in cfg.items()
              if type(key) is str and not key.startswith("_")}
    if any(type(key) is not str for key in cfg):
        _reject("json_invalid")
    _json_value(public)
    workdir = cfg.get("_controller_workdir", str(Path.cwd()))
    if type(workdir) is not str or not workdir:
        _reject("workdir_invalid")
    workdir = Path(workdir).absolute()
    def absolute(value):
        if type(value) is not str or not value or "\0" in value:
            _reject("path_invalid")
        path = Path(value)
        return str((path if path.is_absolute() else workdir / path).absolute())
    paths = {name: absolute(cfg.get(name, default)) for name, default in (
        ("_config_path", "orze.yaml"), ("results_dir", "orze_results"),
        ("idea_lake_db", ".orze/idea_lake.db"), ("_orze_dir", ".orze"),
        ("_project_root", str(workdir)))}
    # These loader-derived paths feed orze_path and the worker environment.
    # Their private prefix does not make them transient runtime metadata.
    for name in ("_env_ORZE_DIR", "_env_ORZE_RESULTS_DIR", "_env_ORZE_IDEAS_FILE",
                 "_env_ORZE_RULES_DIR", "_env_ORZE_METHODS_DIR",
                 "_env_ORZE_KNOWLEDGE_DIR", "_env_ORZE_FEEDBACK_DIR"):
        paths[name] = absolute(cfg[name]) if name in cfg else None
    payload = {"schema": 1, "public_config": public, "paths": paths,
               "workdir": str(workdir), "physical_gpus": allowed}
    try:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, UnicodeError, RecursionError):
        _reject("json_invalid")
    return hashlib.sha256(raw).hexdigest()


def validate_profile_cli(cfg, args):
    """Validate controller-mode CLI overrides before GPU/admin/launch effects."""
    profile = controller_profile(cfg)
    if profile is None:
        return None
    command = getattr(args, "command", None)
    if (command == "run-idea" or getattr(args, "role_only", None)
            or getattr(args, "research_only", False) or getattr(args, "admin", False)
            or command == "start"):
        _reject("cli_mode_unsupported")
    if profile["version"] == 2 and (
            command == "resume" or getattr(args, "enable", False)
            or (command == "restart" and getattr(args, "foreground", False))):
        _reject("cli_mode_unsupported")
    raw = getattr(args, "gpus", None)
    if raw is not None:
        if (type(raw) is not str or not raw or any(not part.strip().isascii()
                or not part.strip().isdigit() for part in raw.split(","))):
            _reject("explicit_gpus_required")
        if _gpus([int(part.strip()) for part in raw.split(",")]) != _gpus(cfg["gpu_scheduling"]["allowed_gpus"]):
            _reject("gpu_scope_changed")
    stopping = command in {"stop", "restart"} or getattr(args, "stop", False) or getattr(args, "restart", False)
    for arg, key in (("timeout", "timeout"), ("poll", "poll"), ("results_dir", "results_dir"),
                     ("train_script", "train_script"), ("ideas_md", "ideas_file"), ("base_config", "base_config")):
        value = getattr(args, arg, None)
        if value is not None and not (arg == "timeout" and stopping) and value != cfg.get(key):
            _reject("cli_override_unsupported")
    return profile


def validate_successor_cli(args):
    """Reject a claimed private entry on non-foreground CLI paths, without IO.

    The environment key is only a claim. This check grants no registration or
    launch authority; the actual inherited channel must be checked separately
    after loading the complete configuration and before launch-side effects.
    """
    name = "ORZE_CONTROLLER_HANDOFF_FD"
    if name not in os.environ:
        return
    raw = os.environ[name]
    if (not raw or len(raw) > 7 or not raw.isascii() or not raw.isdecimal()
            or not 3 <= int(raw) <= 2 ** 20):
        _reject("handoff_fd_invalid")
    if (getattr(args, "command", None) is not None
            or getattr(args, "init", None) is not None
            or getattr(args, "controller_request_id", None) is not None
            or any(getattr(args, key, False) for key in (
                "stop", "restart", "disable", "enable", "report_only", "role_only",
                "research_only", "admin", "upgrade", "reinstall", "check",
                "launch_status", "uninstall"))):
        _reject("handoff_cli_mode_unsupported")
