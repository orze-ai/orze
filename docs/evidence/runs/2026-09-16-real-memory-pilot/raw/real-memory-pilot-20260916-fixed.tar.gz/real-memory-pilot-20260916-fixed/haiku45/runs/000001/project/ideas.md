# Ideas






## idea-b8574d: Aggressive long job at start of window with mandatory finish
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-357a60
- **Research Cycle**: 4
- **Hypothesis**: Previous attempts either sacrificed long (value 11) entirely or placed it too late to meet deadline of 9. Starting long at tick 3 (release) and finishing by tick 8 leaves room for mandatory finish at tick 9. This avoids the deadline violation seen in idea-357a60 while capturing long's high value.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


