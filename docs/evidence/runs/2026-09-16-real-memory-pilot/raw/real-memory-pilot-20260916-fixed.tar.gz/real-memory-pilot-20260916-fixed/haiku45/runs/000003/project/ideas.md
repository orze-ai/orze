# Ideas




## idea-b5718b: All four jobs with optimal packing: start, one, two, three
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: The instance has capacity 1 and horizon 4. Job 'start' (duration 1, value 1, mandatory) must occupy tick 0. Job 'one' (duration 1, release 1, deadline 2, value 2) can occupy tick 1. Job 'two' (duration 1, release 2, deadline 3, value 3) can occupy tick 2. Job 'three' (duration 1, release 3, deadline 4, value 4) can occupy tick 3. All precedence constraints (one, two, three depend on start) are satisfied. This schedule achieves the theoretical maximum total value (1+2+3+4=10) by fitting all jobs within their windows. idea-442c94 attempted this exact order but may have had an encoding issue; this proposal explicitly verifies the schedule through evaluation.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

