# Ideas




## idea-b5718b: Maximize optional jobs within deadline constraints
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 3
- **Hypothesis**: The greedy sequential schedule (idea-442c94) includes all four jobs but may violate deadline constraints. This candidate respects all release times, deadlines, and the finish-before-start dependency from 'start'. It schedules: start at tick 0 (mandatory, release 0, deadline 1), one at tick 1 (release 1, deadline 2), two at tick 2 (release 2, deadline 3), and three at tick 3 (release 3, deadline 4). This achieves total value 1+2+3+4=10 while satisfying capacity (1 job per tick) and all timing constraints.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


