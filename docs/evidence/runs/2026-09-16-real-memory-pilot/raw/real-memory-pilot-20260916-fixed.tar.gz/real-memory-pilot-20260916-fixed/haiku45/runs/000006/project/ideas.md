# Ideas




## idea-b5718b: Parallel optional jobs: start 'one' at tick 1, then 'two' and 'three' greedily
- **Priority**: high
- **Category**: scheduling_exploration
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: Previous greedy approach scheduled sequentially (one→two→three at ticks 1,2,3). Since capacity=1 and all optional jobs have duration=1 with disjoint deadlines (2,3,4), we can still only fit one per tick. However, the mandatory 'start' job finishes at tick 1, leaving ticks 1–3 available. Scheduling 'one' at tick 1 (release 1, deadline 2) is valid. Then 'two' at tick 2 (release 2, deadline 3) and 'three' at tick 3 (release 3, deadline 4). This captures all four jobs for total value 1+2+3+4=10, same as idea-442c94 if feasible, but serves as an independent confirmation of the greedy order.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


