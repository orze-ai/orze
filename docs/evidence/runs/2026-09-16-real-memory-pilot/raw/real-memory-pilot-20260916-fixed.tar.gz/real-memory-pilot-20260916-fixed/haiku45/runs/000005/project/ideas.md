# Ideas




## idea-ee11c9: Compact early + middle + late schedule avoiding long deadline conflict
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-28bed3
- **Research Cycle**: 2
- **Hypothesis**: The previous idea-28bed3 attempted early + middle + late but did not achieve full coverage. Reconsidering: early (value 7, duration 2, release 3, deadline 6), middle (value 8, duration 2, release 5, deadline 9), late (value 9, duration 2, release 7, deadline 11). Mandatory: prepare (0-2), gate (2-3), finish (9-10). Available windows: ticks 3-9 and 10-12. Schedule: prepare (0-2), gate (2-3), early (3-5), middle (5-7), late (7-9), finish (9-10). All jobs fit within capacity and deadlines. Total optional value: 7+8+9=24, which exceeds the long-only path (11). This tests whether tight packing of three medium-value jobs outperforms one high-value job.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

