# Ideas




## idea-b5718b: Schedule all jobs in deadline order: start, one, two, three
- **Priority**: high
- **Category**: scheduling_order
- **Approach Family**: optimization
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: The previous baseline (idea-442c94) scheduled jobs at their release times in sequence. A deadline-driven ordering may better utilize the capacity window. Since all jobs have duration 1, capacity 1, and release/deadline constraints, scheduling start→one→two→three respects all dependencies (each job after start) and deadlines (1,2,3,4), yielding maximum total value of 10.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


