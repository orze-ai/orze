# Ideas




## idea-b5718b: Optimized schedule: start, one, two, three in sequence
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: optimization
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: Previous greedy approach scheduled all four jobs sequentially (start→one→two→three at times 0,1,2,3). This candidate respects all prerequisites (one, two, three all require 'start' to complete first), meets all release windows (one releases at 1, two at 2, three at 3), and fits within the capacity-1 horizon-4 constraint. With values 1+2+3+4=10, this should achieve maximal feasible value if all deadlines are met: start by tick 1, one by tick 2, two by tick 3, three by tick 4.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




## idea-713603: Minimal-plus schedule: start and highest-value optional job two
- **Priority**: high
- **Category**: scheduling_greedy
- **Approach Family**: other
- **Parent**: idea-30483f
- **Research Cycle**: 4
- **Hypothesis**: Conservative schedules (idea-3bcd7d with only 'start', idea-30483f with 'start' and 'two') provide a baseline. Since job 'two' has value 3, release time 2, deadline 3, and fits in the horizon after 'start' (which runs t=0), including it yields value 1+3=4. This avoids scheduling lower-value job 'one' (value 2) and focuses on the single highest-value optional job to test whether value concentration outperforms broader inclusion.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "two", "start": 2}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

