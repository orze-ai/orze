# Ideas




## idea-ee11c9: Exclude long job and maximize all four optional jobs with tighter packing
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: optimization
- **Parent**: idea-28bed3
- **Research Cycle**: 4
- **Hypothesis**: Prior schedules attempted to include long (value 11, duration 5), which creates scheduling pressure. Excluding long entirely and fitting early, middle, and late (total value 7+8+9=24) may yield higher total value than long alone. This tests the hypothesis that four shorter jobs (total duration 5) are worth more collectively than one long job despite both fitting the same time window.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

