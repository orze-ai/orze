# Ideas




## idea-b5718b: Greedy value-maximizing schedule with mandatory start
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: Previous attempts used earliest-deadline or selective inclusion heuristics. Since capacity is 1 and all optional jobs have disjoint release windows (one at tick 1, two at tick 2, three at tick 3), scheduling all jobs in descending value order after satisfying the mandatory 'start' job should capture maximum value within the horizon and deadline constraints. Job 'three' (value 4, release 3, deadline 4) can fit at tick 3; job 'two' (value 3, release 2, deadline 3) can fit at tick 2; job 'one' (value 2, release 1, deadline 2) can fit at tick 1.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




## idea-655a1f: Greedy value-first schedule skipping low-value optional job
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-eedcc5
- **Research Cycle**: 3
- **Hypothesis**: If scheduling all jobs is infeasible due to an overlooked constraint, prioritize high-value jobs. Schedule 'start' at tick 0, skip 'one' (value=2, lowest among optionals), include 'two' at tick 2 (value=3, deadline=3), and 'three' at tick 3 (value=4, deadline=4). This yields value 1+3+4=8. This tests whether the previous 'skip two' candidate (idea-eedcc5) was suboptimal compared to skipping 'one' instead.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "two", "start": 2}, {"job_id":
        "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```



