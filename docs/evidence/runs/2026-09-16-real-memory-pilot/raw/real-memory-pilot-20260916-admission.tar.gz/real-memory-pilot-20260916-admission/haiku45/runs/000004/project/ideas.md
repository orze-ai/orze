# Ideas








## idea-6b9c92: Maximize optional job value by scheduling early and middle back-to-back, defer long to late window
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: optimization
- **Parent**: idea-28645a
- **Research Cycle**: 4
- **Hypothesis**: Previous attempts have traded off between long (value 11, duration 5) and early+middle (combined value 15, duration 4). Scheduling early at release 3 and middle at release 5 consecutively (starts 3 and 5) leaves the long job to fit only in the tight 8-9 window, which fails. Instead, pack early+middle tightly before gate completes (starts 3-4, finishes by 5), then attempt long in the 8-9 window or skip it entirely. The mandatory jobs (prepare 0-2, gate 2-3, finish 9-11) leave windows 3-7 and 8-9 for optionals. Early (3-5) + middle (5-7) = value 15 achieves higher total than long alone (value 11) if both fit.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        8}, {"job_id": "finish", "start": 10}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


