# Ideas




## idea-b5718b: Schedule all optional jobs in dependency order within windows
- **Priority**: high
- **Category**: candidate_enumeration
- **Approach Family**: other
- **Parent**: none
- **Research Cycle**: 2
- **Hypothesis**: Previous candidates were either greedy (all four jobs) or selective (three jobs). The instance allows capacity 1 and horizon 4. Job 'start' (required, duration 1, deadline 1) must run at tick 0. Jobs 'one', 'two', 'three' have release times 1, 2, 3 and deadlines 2, 3, 4 respectively, each with duration 1 and value 2, 3, 4. A schedule that includes all optional jobs in strict dependency order—start at 0, one at 1, two at 2, three at 3—respects all windows and maximizes total value (1+2+3+4=10). This differs from previous attempts by confirming whether the evaluator accepts this theoretically feasible packing.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-655a1f: Exclude lowest-value optional job (one) to test value vs. feasibility trade-off
- **Priority**: high
- **Category**: candidate_enumeration
- **Approach Family**: other
- **Parent**: idea-eedcc5
- **Research Cycle**: 2
- **Hypothesis**: If the all-jobs schedule fails evaluation, the bottleneck may be strict timing or a hidden constraint. Removing the lowest-value optional job ('one', value 2) and scheduling start→two→three preserves higher value (1+3+4=8) while reducing pressure on the capacity window. Start runs at 0, two at 2 (respecting release 2, deadline 3), three at 3 (respecting release 3, deadline 4). This tests whether feasibility improves when optional jobs are selectively omitted.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "two", "start": 2}, {"job_id":
        "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```



