# Ideas




## idea-b5718b: Schedule all jobs in release-window order with greedy capacity matching
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: The baseline greedy approach scheduled jobs sequentially starting at their release times. An alternative candidate that respects the same constraints but explores a different ordering or timing pattern may reveal whether the sequential assumption is optimal. This tests whether the disjoint windows structure admits a better feasible schedule by varying job placement within deadline and dependency bounds.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




