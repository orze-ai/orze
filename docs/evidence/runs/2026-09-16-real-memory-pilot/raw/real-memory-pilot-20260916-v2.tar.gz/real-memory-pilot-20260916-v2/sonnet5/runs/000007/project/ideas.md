# Ideas






## idea-b5718b: Independent re-submission of full-inclusion schedule to resolve missing-metrics gap
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 3
- **Hypothesis**: All 8 prior report records, including idea-442c94's full-inclusion candidate (start@0, one@1, two@2, three@3), show 'local_metrics_missing' rather than a scored outcome. Since start/one/two/three occupy disjoint integer ticks (0,1,2,3) under capacity=1, and each job's release/deadline window is satisfied with the finish-before-start dependency on 'start' respected, this schedule should be structurally feasible and would maximize sum-of-values (1+2+3+4=10) if evaluated. Re-submitting it as an independent attempt tests whether the missing-metrics condition is a persistent system/reporting issue or was specific to that earlier attempt, without assuming the original result was a tie or failure.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


