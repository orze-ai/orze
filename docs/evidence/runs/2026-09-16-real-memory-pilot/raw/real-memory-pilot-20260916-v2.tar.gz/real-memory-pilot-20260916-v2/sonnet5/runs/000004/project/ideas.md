# Ideas




## idea-ee11c9: Confirm full-window packing score (independent re-run)
- **Priority**: high
- **Category**: confirmation
- **Approach Family**: other
- **Parent**: idea-28bed3
- **Research Cycle**: 2
- **Hypothesis**: idea-28bed3 proposed the full-window packing schedule (prepare, gate, early, middle, late, finish) but its evaluation record shows availability=unavailable/local_metrics_missing rather than a computed score. This is an unknown measurement, not a negative result. Re-submitting the identical candidate lets us obtain an actual feasibility/value determination from the evaluator to decide whether this packing (analytically summing to value 27: 1+1+1+7+8+9) is confirmed feasible before exploring further variants.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


