# Ideas




## idea-b5718b: Schedule all jobs in release order with deadline feasibility
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: The baseline scheduled jobs greedily by earliest deadline after the mandatory 'start' job. An alternative approach is to schedule jobs strictly in their release order (start→one→two→three) while respecting deadlines. Since capacity=1 and horizon=4, this should fit all jobs: start at 0 (deadline 1), one at 1 (deadline 2), two at 2 (deadline 3), three at 3 (deadline 4). This yields value 1+2+3+4=10 if feasible, matching the baseline but testing whether order independence holds.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

