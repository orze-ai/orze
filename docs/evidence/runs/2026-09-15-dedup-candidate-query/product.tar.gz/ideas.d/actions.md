## idea-first: Sidecar CPU first
```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - import json; from pathlib import Path; Path('answer.json').write_text(json.dumps(sorted([5,1,3])))
  inputs: {}
  outputs:
    answer:
      max_bytes: 128
      path: answer.json
  purpose: verify sidecar ingress CPU execution
  timeout_seconds: 4
  version: 1
kind: native_cpu_action
```
## idea-duplicate: Sidecar CPU duplicate
```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - import json; from pathlib import Path; Path('answer.json').write_text(json.dumps(sorted([5,1,3])))
  inputs: {}
  outputs:
    answer:
      max_bytes: 128
      path: answer.json
  purpose: verify sidecar ingress CPU execution
  timeout_seconds: 4
  version: 1
kind: native_cpu_action
```
