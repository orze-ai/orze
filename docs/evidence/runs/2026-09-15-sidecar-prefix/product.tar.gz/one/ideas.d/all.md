## idea-history-0000: Conflicting authored title
```yaml
seed: 0
```

## idea-history-0001: Conflicting authored title
```yaml
seed: 1
```

## idea-history-0002: Conflicting authored title
```yaml
seed: 2
```

## idea-history-0003: Conflicting authored title
```yaml
seed: 3
```

## idea-history-0004: Conflicting authored title
```yaml
seed: 4
```

## idea-history-0005: Conflicting authored title
```yaml
seed: 5
```

## idea-history-0006: Conflicting authored title
```yaml
seed: 6
```

## idea-history-0007: Conflicting authored title
```yaml
seed: 7
```

## idea-history-0008: Conflicting authored title
```yaml
seed: 8
```

## idea-history-0009: Conflicting authored title
```yaml
seed: 9
```

## idea-history-0010: Conflicting authored title
```yaml
seed: 10
```

## idea-history-0011: Conflicting authored title
```yaml
seed: 11
```

## idea-history-0012: Conflicting authored title
```yaml
seed: 12
```

## idea-history-0013: Conflicting authored title
```yaml
seed: 13
```

## idea-history-0014: Conflicting authored title
```yaml
seed: 14
```

## idea-history-0015: Conflicting authored title
```yaml
seed: 15
```

## idea-history-0016: Conflicting authored title
```yaml
seed: 16
```

## idea-history-0017: Conflicting authored title
```yaml
seed: 17
```

## idea-history-0018: Conflicting authored title
```yaml
seed: 18
```

## idea-history-0019: Conflicting authored title
```yaml
seed: 19
```

## idea-history-0020: Conflicting authored title
```yaml
seed: 20
```

## idea-history-0021: Conflicting authored title
```yaml
seed: 21
```

## idea-history-0022: Conflicting authored title
```yaml
seed: 22
```

## idea-history-0023: Conflicting authored title
```yaml
seed: 23
```

## idea-history-0024: Conflicting authored title
```yaml
seed: 24
```

## idea-history-0025: Conflicting authored title
```yaml
seed: 25
```

## idea-history-0026: Conflicting authored title
```yaml
seed: 26
```

## idea-history-0027: Conflicting authored title
```yaml
seed: 27
```

## idea-history-0028: Conflicting authored title
```yaml
seed: 28
```

## idea-history-0029: Conflicting authored title
```yaml
seed: 29
```

## idea-history-0030: Conflicting authored title
```yaml
seed: 30
```

## idea-history-0031: Conflicting authored title
```yaml
seed: 31
```

## idea-history-0032: Conflicting authored title
```yaml
seed: 32
```

## idea-history-0033: Conflicting authored title
```yaml
seed: 33
```

## idea-history-0034: Conflicting authored title
```yaml
seed: 34
```

## idea-history-0035: Conflicting authored title
```yaml
seed: 35
```

## idea-history-0036: Conflicting authored title
```yaml
seed: 36
```

## idea-history-0037: Conflicting authored title
```yaml
seed: 37
```

## idea-history-0038: Conflicting authored title
```yaml
seed: 38
```

## idea-history-0039: Conflicting authored title
```yaml
seed: 39
```

## idea-history-0040: Conflicting authored title
```yaml
seed: 40
```

## idea-history-0041: Conflicting authored title
```yaml
seed: 41
```

## idea-history-0042: Conflicting authored title
```yaml
seed: 42
```

## idea-history-0043: Conflicting authored title
```yaml
seed: 43
```

## idea-history-0044: Conflicting authored title
```yaml
seed: 44
```

## idea-history-0045: Conflicting authored title
```yaml
seed: 45
```

## idea-history-0046: Conflicting authored title
```yaml
seed: 46
```

## idea-history-0047: Conflicting authored title
```yaml
seed: 47
```

## idea-history-0048: Conflicting authored title
```yaml
seed: 48
```

## idea-history-0049: Conflicting authored title
```yaml
seed: 49
```

## idea-history-0050: Conflicting authored title
```yaml
seed: 50
```

## idea-history-0051: Conflicting authored title
```yaml
seed: 51
```

## idea-history-0052: Conflicting authored title
```yaml
seed: 52
```

## idea-history-0053: Conflicting authored title
```yaml
seed: 53
```

## idea-history-0054: Conflicting authored title
```yaml
seed: 54
```

## idea-history-0055: Conflicting authored title
```yaml
seed: 55
```

## idea-history-0056: Conflicting authored title
```yaml
seed: 56
```

## idea-history-0057: Conflicting authored title
```yaml
seed: 57
```

## idea-history-0058: Conflicting authored title
```yaml
seed: 58
```

## idea-history-0059: Conflicting authored title
```yaml
seed: 59
```

## idea-history-0060: Conflicting authored title
```yaml
seed: 60
```

## idea-history-0061: Conflicting authored title
```yaml
seed: 61
```

## idea-history-0062: Conflicting authored title
```yaml
seed: 62
```

## idea-history-0063: Conflicting authored title
```yaml
seed: 63
```

## idea-history-0064: Conflicting authored title
```yaml
seed: 64
```

## idea-history-0065: Conflicting authored title
```yaml
seed: 65
```

## idea-history-0066: Conflicting authored title
```yaml
seed: 66
```

## idea-history-0067: Conflicting authored title
```yaml
seed: 67
```

## idea-history-0068: Conflicting authored title
```yaml
seed: 68
```

## idea-history-0069: Conflicting authored title
```yaml
seed: 69
```

## idea-history-0070: Conflicting authored title
```yaml
seed: 70
```

## idea-history-0071: Conflicting authored title
```yaml
seed: 71
```

## idea-history-0072: Conflicting authored title
```yaml
seed: 72
```

## idea-history-0073: Conflicting authored title
```yaml
seed: 73
```

## idea-history-0074: Conflicting authored title
```yaml
seed: 74
```

## idea-history-0075: Conflicting authored title
```yaml
seed: 75
```

## idea-history-0076: Conflicting authored title
```yaml
seed: 76
```

## idea-history-0077: Conflicting authored title
```yaml
seed: 77
```

## idea-history-0078: Conflicting authored title
```yaml
seed: 78
```

## idea-history-0079: Conflicting authored title
```yaml
seed: 79
```

## idea-history-0080: Conflicting authored title
```yaml
seed: 80
```

## idea-history-0081: Conflicting authored title
```yaml
seed: 81
```

## idea-history-0082: Conflicting authored title
```yaml
seed: 82
```

## idea-history-0083: Conflicting authored title
```yaml
seed: 83
```

## idea-history-0084: Conflicting authored title
```yaml
seed: 84
```

## idea-history-0085: Conflicting authored title
```yaml
seed: 85
```

## idea-history-0086: Conflicting authored title
```yaml
seed: 86
```

## idea-history-0087: Conflicting authored title
```yaml
seed: 87
```

## idea-history-0088: Conflicting authored title
```yaml
seed: 88
```

## idea-history-0089: Conflicting authored title
```yaml
seed: 89
```

## idea-history-0090: Conflicting authored title
```yaml
seed: 90
```

## idea-history-0091: Conflicting authored title
```yaml
seed: 91
```

## idea-history-0092: Conflicting authored title
```yaml
seed: 92
```

## idea-history-0093: Conflicting authored title
```yaml
seed: 93
```

## idea-history-0094: Conflicting authored title
```yaml
seed: 94
```

## idea-history-0095: Conflicting authored title
```yaml
seed: 95
```

## idea-history-0096: Conflicting authored title
```yaml
seed: 96
```

## idea-history-0097: Conflicting authored title
```yaml
seed: 97
```

## idea-history-0098: Conflicting authored title
```yaml
seed: 98
```

## idea-history-0099: Conflicting authored title
```yaml
seed: 99
```

## idea-history-0100: Conflicting authored title
```yaml
seed: 100
```

## idea-history-0101: Conflicting authored title
```yaml
seed: 101
```

## idea-history-0102: Conflicting authored title
```yaml
seed: 102
```

## idea-history-0103: Conflicting authored title
```yaml
seed: 103
```

## idea-history-0104: Conflicting authored title
```yaml
seed: 104
```

## idea-history-0105: Conflicting authored title
```yaml
seed: 105
```

## idea-history-0106: Conflicting authored title
```yaml
seed: 106
```

## idea-history-0107: Conflicting authored title
```yaml
seed: 107
```

## idea-history-0108: Conflicting authored title
```yaml
seed: 108
```

## idea-history-0109: Conflicting authored title
```yaml
seed: 109
```

## idea-history-0110: Conflicting authored title
```yaml
seed: 110
```

## idea-history-0111: Conflicting authored title
```yaml
seed: 111
```

## idea-history-0112: Conflicting authored title
```yaml
seed: 112
```

## idea-history-0113: Conflicting authored title
```yaml
seed: 113
```

## idea-history-0114: Conflicting authored title
```yaml
seed: 114
```

## idea-history-0115: Conflicting authored title
```yaml
seed: 115
```

## idea-history-0116: Conflicting authored title
```yaml
seed: 116
```

## idea-history-0117: Conflicting authored title
```yaml
seed: 117
```

## idea-history-0118: Conflicting authored title
```yaml
seed: 118
```

## idea-history-0119: Conflicting authored title
```yaml
seed: 119
```

## idea-history-0120: Conflicting authored title
```yaml
seed: 120
```

## idea-history-0121: Conflicting authored title
```yaml
seed: 121
```

## idea-history-0122: Conflicting authored title
```yaml
seed: 122
```

## idea-history-0123: Conflicting authored title
```yaml
seed: 123
```

## idea-history-0124: Conflicting authored title
```yaml
seed: 124
```

## idea-history-0125: Conflicting authored title
```yaml
seed: 125
```

## idea-history-0126: Conflicting authored title
```yaml
seed: 126
```

## idea-history-0127: Conflicting authored title
```yaml
seed: 127
```

## idea-history-0128: Conflicting authored title
```yaml
seed: 128
```

## idea-history-0129: Conflicting authored title
```yaml
seed: 129
```

## idea-history-0130: Conflicting authored title
```yaml
seed: 130
```

## idea-history-0131: Conflicting authored title
```yaml
seed: 131
```

## idea-history-0132: Conflicting authored title
```yaml
seed: 132
```

## idea-history-0133: Conflicting authored title
```yaml
seed: 133
```

## idea-history-0134: Conflicting authored title
```yaml
seed: 134
```

## idea-history-0135: Conflicting authored title
```yaml
seed: 135
```

## idea-history-0136: Conflicting authored title
```yaml
seed: 136
```

## idea-history-0137: Conflicting authored title
```yaml
seed: 137
```

## idea-history-0138: Conflicting authored title
```yaml
seed: 138
```

## idea-history-0139: Conflicting authored title
```yaml
seed: 139
```

## idea-history-0140: Conflicting authored title
```yaml
seed: 140
```

## idea-history-0141: Conflicting authored title
```yaml
seed: 141
```

## idea-history-0142: Conflicting authored title
```yaml
seed: 142
```

## idea-history-0143: Conflicting authored title
```yaml
seed: 143
```

## idea-history-0144: Conflicting authored title
```yaml
seed: 144
```

## idea-history-0145: Conflicting authored title
```yaml
seed: 145
```

## idea-history-0146: Conflicting authored title
```yaml
seed: 146
```

## idea-history-0147: Conflicting authored title
```yaml
seed: 147
```

## idea-history-0148: Conflicting authored title
```yaml
seed: 148
```

## idea-history-0149: Conflicting authored title
```yaml
seed: 149
```

## idea-history-0150: Conflicting authored title
```yaml
seed: 150
```

## idea-history-0151: Conflicting authored title
```yaml
seed: 151
```

## idea-history-0152: Conflicting authored title
```yaml
seed: 152
```

## idea-history-0153: Conflicting authored title
```yaml
seed: 153
```

## idea-history-0154: Conflicting authored title
```yaml
seed: 154
```

## idea-history-0155: Conflicting authored title
```yaml
seed: 155
```

## idea-history-0156: Conflicting authored title
```yaml
seed: 156
```

## idea-history-0157: Conflicting authored title
```yaml
seed: 157
```

## idea-history-0158: Conflicting authored title
```yaml
seed: 158
```

## idea-history-0159: Conflicting authored title
```yaml
seed: 159
```

## idea-history-0160: Conflicting authored title
```yaml
seed: 160
```

## idea-history-0161: Conflicting authored title
```yaml
seed: 161
```

## idea-history-0162: Conflicting authored title
```yaml
seed: 162
```

## idea-history-0163: Conflicting authored title
```yaml
seed: 163
```

## idea-history-0164: Conflicting authored title
```yaml
seed: 164
```

## idea-history-0165: Conflicting authored title
```yaml
seed: 165
```

## idea-history-0166: Conflicting authored title
```yaml
seed: 166
```

## idea-history-0167: Conflicting authored title
```yaml
seed: 167
```

## idea-history-0168: Conflicting authored title
```yaml
seed: 168
```

## idea-history-0169: Conflicting authored title
```yaml
seed: 169
```

## idea-history-0170: Conflicting authored title
```yaml
seed: 170
```

## idea-history-0171: Conflicting authored title
```yaml
seed: 171
```

## idea-history-0172: Conflicting authored title
```yaml
seed: 172
```

## idea-history-0173: Conflicting authored title
```yaml
seed: 173
```

## idea-history-0174: Conflicting authored title
```yaml
seed: 174
```

## idea-history-0175: Conflicting authored title
```yaml
seed: 175
```

## idea-history-0176: Conflicting authored title
```yaml
seed: 176
```

## idea-history-0177: Conflicting authored title
```yaml
seed: 177
```

## idea-history-0178: Conflicting authored title
```yaml
seed: 178
```

## idea-history-0179: Conflicting authored title
```yaml
seed: 179
```

## idea-history-0180: Conflicting authored title
```yaml
seed: 180
```

## idea-history-0181: Conflicting authored title
```yaml
seed: 181
```

## idea-history-0182: Conflicting authored title
```yaml
seed: 182
```

## idea-history-0183: Conflicting authored title
```yaml
seed: 183
```

## idea-history-0184: Conflicting authored title
```yaml
seed: 184
```

## idea-history-0185: Conflicting authored title
```yaml
seed: 185
```

## idea-history-0186: Conflicting authored title
```yaml
seed: 186
```

## idea-history-0187: Conflicting authored title
```yaml
seed: 187
```

## idea-history-0188: Conflicting authored title
```yaml
seed: 188
```

## idea-history-0189: Conflicting authored title
```yaml
seed: 189
```

## idea-history-0190: Conflicting authored title
```yaml
seed: 190
```

## idea-history-0191: Conflicting authored title
```yaml
seed: 191
```

## idea-history-0192: Conflicting authored title
```yaml
seed: 192
```

## idea-history-0193: Conflicting authored title
```yaml
seed: 193
```

## idea-history-0194: Conflicting authored title
```yaml
seed: 194
```

## idea-history-0195: Conflicting authored title
```yaml
seed: 195
```

## idea-history-0196: Conflicting authored title
```yaml
seed: 196
```

## idea-history-0197: Conflicting authored title
```yaml
seed: 197
```

## idea-history-0198: Conflicting authored title
```yaml
seed: 198
```

## idea-history-0199: Conflicting authored title
```yaml
seed: 199
```

## idea-history-0200: Conflicting authored title
```yaml
seed: 200
```

## idea-history-0201: Conflicting authored title
```yaml
seed: 201
```

## idea-history-0202: Conflicting authored title
```yaml
seed: 202
```

## idea-history-0203: Conflicting authored title
```yaml
seed: 203
```

## idea-history-0204: Conflicting authored title
```yaml
seed: 204
```

## idea-history-0205: Conflicting authored title
```yaml
seed: 205
```

## idea-history-0206: Conflicting authored title
```yaml
seed: 206
```

## idea-history-0207: Conflicting authored title
```yaml
seed: 207
```

## idea-history-0208: Conflicting authored title
```yaml
seed: 208
```

## idea-history-0209: Conflicting authored title
```yaml
seed: 209
```

## idea-history-0210: Conflicting authored title
```yaml
seed: 210
```

## idea-history-0211: Conflicting authored title
```yaml
seed: 211
```

## idea-history-0212: Conflicting authored title
```yaml
seed: 212
```

## idea-history-0213: Conflicting authored title
```yaml
seed: 213
```

## idea-history-0214: Conflicting authored title
```yaml
seed: 214
```

## idea-history-0215: Conflicting authored title
```yaml
seed: 215
```

## idea-history-0216: Conflicting authored title
```yaml
seed: 216
```

## idea-history-0217: Conflicting authored title
```yaml
seed: 217
```

## idea-history-0218: Conflicting authored title
```yaml
seed: 218
```

## idea-history-0219: Conflicting authored title
```yaml
seed: 219
```

## idea-history-0220: Conflicting authored title
```yaml
seed: 220
```

## idea-history-0221: Conflicting authored title
```yaml
seed: 221
```

## idea-history-0222: Conflicting authored title
```yaml
seed: 222
```

## idea-history-0223: Conflicting authored title
```yaml
seed: 223
```

## idea-history-0224: Conflicting authored title
```yaml
seed: 224
```

## idea-history-0225: Conflicting authored title
```yaml
seed: 225
```

## idea-history-0226: Conflicting authored title
```yaml
seed: 226
```

## idea-history-0227: Conflicting authored title
```yaml
seed: 227
```

## idea-history-0228: Conflicting authored title
```yaml
seed: 228
```

## idea-history-0229: Conflicting authored title
```yaml
seed: 229
```

## idea-history-0230: Conflicting authored title
```yaml
seed: 230
```

## idea-history-0231: Conflicting authored title
```yaml
seed: 231
```

## idea-history-0232: Conflicting authored title
```yaml
seed: 232
```

## idea-history-0233: Conflicting authored title
```yaml
seed: 233
```

## idea-history-0234: Conflicting authored title
```yaml
seed: 234
```

## idea-history-0235: Conflicting authored title
```yaml
seed: 235
```

## idea-history-0236: Conflicting authored title
```yaml
seed: 236
```

## idea-history-0237: Conflicting authored title
```yaml
seed: 237
```

## idea-history-0238: Conflicting authored title
```yaml
seed: 238
```

## idea-history-0239: Conflicting authored title
```yaml
seed: 239
```

## idea-history-0240: Conflicting authored title
```yaml
seed: 240
```

## idea-history-0241: Conflicting authored title
```yaml
seed: 241
```

## idea-history-0242: Conflicting authored title
```yaml
seed: 242
```

## idea-history-0243: Conflicting authored title
```yaml
seed: 243
```

## idea-history-0244: Conflicting authored title
```yaml
seed: 244
```

## idea-history-0245: Conflicting authored title
```yaml
seed: 245
```

## idea-history-0246: Conflicting authored title
```yaml
seed: 246
```

## idea-history-0247: Conflicting authored title
```yaml
seed: 247
```

## idea-history-0248: Conflicting authored title
```yaml
seed: 248
```

## idea-history-0249: Conflicting authored title
```yaml
seed: 249
```

## idea-history-0250: Conflicting authored title
```yaml
seed: 250
```

## idea-history-0251: Conflicting authored title
```yaml
seed: 251
```

## idea-history-0252: Conflicting authored title
```yaml
seed: 252
```

## idea-history-0253: Conflicting authored title
```yaml
seed: 253
```

## idea-history-0254: Conflicting authored title
```yaml
seed: 254
```

## idea-history-0255: Conflicting authored title
```yaml
seed: 255
```

## idea-history-0256: Conflicting authored title
```yaml
seed: 256
```

## idea-history-0257: Conflicting authored title
```yaml
seed: 257
```

## idea-history-0258: Conflicting authored title
```yaml
seed: 258
```

## idea-history-0259: Conflicting authored title
```yaml
seed: 259
```

## idea-history-0260: Conflicting authored title
```yaml
seed: 260
```

## idea-history-0261: Conflicting authored title
```yaml
seed: 261
```

## idea-history-0262: Conflicting authored title
```yaml
seed: 262
```

## idea-history-0263: Conflicting authored title
```yaml
seed: 263
```

## idea-history-0264: Conflicting authored title
```yaml
seed: 264
```

## idea-history-0265: Conflicting authored title
```yaml
seed: 265
```

## idea-history-0266: Conflicting authored title
```yaml
seed: 266
```

## idea-history-0267: Conflicting authored title
```yaml
seed: 267
```

## idea-history-0268: Conflicting authored title
```yaml
seed: 268
```

## idea-history-0269: Conflicting authored title
```yaml
seed: 269
```

## idea-history-0270: Conflicting authored title
```yaml
seed: 270
```

## idea-history-0271: Conflicting authored title
```yaml
seed: 271
```

## idea-history-0272: Conflicting authored title
```yaml
seed: 272
```

## idea-history-0273: Conflicting authored title
```yaml
seed: 273
```

## idea-history-0274: Conflicting authored title
```yaml
seed: 274
```

## idea-history-0275: Conflicting authored title
```yaml
seed: 275
```

## idea-history-0276: Conflicting authored title
```yaml
seed: 276
```

## idea-history-0277: Conflicting authored title
```yaml
seed: 277
```

## idea-history-0278: Conflicting authored title
```yaml
seed: 278
```

## idea-history-0279: Conflicting authored title
```yaml
seed: 279
```

## idea-history-0280: Conflicting authored title
```yaml
seed: 280
```

## idea-history-0281: Conflicting authored title
```yaml
seed: 281
```

## idea-history-0282: Conflicting authored title
```yaml
seed: 282
```

## idea-history-0283: Conflicting authored title
```yaml
seed: 283
```

## idea-history-0284: Conflicting authored title
```yaml
seed: 284
```

## idea-history-0285: Conflicting authored title
```yaml
seed: 285
```

## idea-history-0286: Conflicting authored title
```yaml
seed: 286
```

## idea-history-0287: Conflicting authored title
```yaml
seed: 287
```

## idea-history-0288: Conflicting authored title
```yaml
seed: 288
```

## idea-history-0289: Conflicting authored title
```yaml
seed: 289
```

## idea-history-0290: Conflicting authored title
```yaml
seed: 290
```

## idea-history-0291: Conflicting authored title
```yaml
seed: 291
```

## idea-history-0292: Conflicting authored title
```yaml
seed: 292
```

## idea-history-0293: Conflicting authored title
```yaml
seed: 293
```

## idea-history-0294: Conflicting authored title
```yaml
seed: 294
```

## idea-history-0295: Conflicting authored title
```yaml
seed: 295
```

## idea-history-0296: Conflicting authored title
```yaml
seed: 296
```

## idea-history-0297: Conflicting authored title
```yaml
seed: 297
```

## idea-history-0298: Conflicting authored title
```yaml
seed: 298
```

## idea-tail: Authored CPU action
```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - import json; from pathlib import Path; Path('answer.json').write_text(json.dumps(sorted([5,1,3])))
  inputs: {}
  outputs:
    answer:
      max_bytes: 128
      path: answer.json
  purpose: verify a sidecar action beyond two inspection pages
  timeout_seconds: 4
  version: 1
kind: native_cpu_action
```

## idea-tail-duplicate: Authored CPU action
```yaml
action:
  adapter: command
  command:
  - /usr/bin/python3
  - -c
  - import json; from pathlib import Path; Path('answer.json').write_text(json.dumps(sorted([5,1,3])))
  inputs: {}
  outputs:
    answer:
      max_bytes: 128
      path: answer.json
  purpose: verify a sidecar action beyond two inspection pages
  timeout_seconds: 4
  version: 1
kind: native_cpu_action
```
