---
name: anomaly_hypotheses
id: sop-001
role: data_analyst
order: 20
produces: [results/_failure_hypotheses.md]
consumed_by: [research, thinker]
requires: []
trigger: periodic_research_cycles(5)
---

## Job: Failure-Driven Hypotheses
Body here.
