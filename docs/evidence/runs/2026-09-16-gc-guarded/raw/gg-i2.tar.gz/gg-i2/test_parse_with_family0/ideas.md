## idea-aaa111: Test Idea
- **Priority**: high
- **Approach Family**: training_config
- **Config overrides**:
  ```yaml
  lr: 0.001
  ```
