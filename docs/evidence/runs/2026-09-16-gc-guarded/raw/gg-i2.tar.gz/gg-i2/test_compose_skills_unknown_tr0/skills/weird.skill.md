---
id: weird
trigger: bogus_expression(99)
---
WEIRD_BODY
