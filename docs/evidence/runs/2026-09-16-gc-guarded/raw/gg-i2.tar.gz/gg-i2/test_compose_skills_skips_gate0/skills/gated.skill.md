---
id: gated
trigger: periodic_research_cycles(10)
---
GATED_BODY
