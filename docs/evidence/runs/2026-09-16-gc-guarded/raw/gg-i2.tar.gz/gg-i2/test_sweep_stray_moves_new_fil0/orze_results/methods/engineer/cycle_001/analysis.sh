#!/bin/bash
echo analysis