## idea-bbb222: No Family
- **Priority**: medium
- **Config overrides**:
  ```yaml
  x: 1
  ```
