# Ideas


## idea-28bed3: Stagger optional jobs to fit capacity constraint without idle time
- **Priority**: high
- **Category**: scheduling_greedy
- **Approach Family**: other
- **Parent**: idea-seed-overload
- **Research Cycle**: 1
- **Hypothesis**: Capacity is 1 throughout the horizon. The previous seed schedules may have created infeasible overlaps or left gaps. By carefully sequencing: prepare (0-2), gate (2-3), early (3-5), middle (5-7), late (7-9), finish (9-10), we pack high-value jobs (early=7, middle=8, late=9) sequentially without exceeding capacity, omitting 'long' if it forces conflicts, and complete all mandatory jobs by their deadlines.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

