# Ideas




## idea-28bed3: Maximize high-value job placement: early then middle then late
- **Priority**: high
- **Category**: scheduling_optimization
- **Approach Family**: other
- **Parent**: idea-evaluate-seed-valid
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-seed-valid (score 27) succeeded with jobs [prepare, gate, early, middle, late, finish] by fitting all high-value optional jobs before finish. idea-evaluate-diagnostic-1-0 (score 14) succeeded with only [prepare, gate, long, finish], trading value for simplicity. This candidate tests whether we can beat 27 by swapping long (value 11, duration 5) for the three medium-value jobs (early 7 + middle 8 + late 9 = 24 value, 6 total duration). Early (deadline 6) and middle (deadline 9) both fit before late (deadline 11), and all complete before finish (release 9). Ordering early→middle→late respects value density and deadline ordering.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-b8574d: Test long job alone against confirmed multi-job baseline
- **Priority**: medium
- **Category**: scheduling_optimization
- **Approach Family**: other
- **Parent**: idea-evaluate-diagnostic-1-0
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-seed-valid achieved 27 with early+middle+late (7+8+9 value, 6 ticks total). idea-evaluate-diagnostic-1-0 achieved 14 with long (11 value, 5 ticks). Both are feasible but represent different strategy families. To isolate whether the evaluator's capacity and deadline constraints favor the multi-job greedy approach or a single high-value job, this proposal schedules only long with mandatory jobs. If score < 27, greedy multi-job placement is preferred; if score ≥ 14, confirms long is independently viable. This distinguishes capacity competition from deadline pressure.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

