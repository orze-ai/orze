# Ideas








## idea-501379: Scheduled jobs one and three (skip two)
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0003-0000
- **Research Cycle**: 4
- **Hypothesis**: Previous experiments show job_two (value=3, deadline=3) and job_three (value=4, deadline=4) compete for the slot at time 3. Job_three has higher value and later deadline. Scheduling one (value=2, deadline=2 at time 1) and three (value=4, deadline=4 at time 3) yields total value 7, matching the current best. This tests whether skipping the middle-value job two in favor of the highest-value job three is optimal.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-713603: Only mandatory job with job two (skip one and three)
- **Priority**: medium
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0002-0000
- **Research Cycle**: 4
- **Hypothesis**: Current best (value 10) schedules all four jobs. Intermediate candidates show job_two alone yields value 6, while jobs one+two yield value 6. Job_two (value=3, deadline=3, release=2) can fit at time 2. This explores whether a simpler schedule without the highest-value job_three (which requires time 3 and has tight release window at 3) might be feasible under different constraints or reveal a pattern in the value-deadline trade-off.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "two", "start": 2}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

