# Ideas




## idea-b5718b: Greedy sequential with job three included
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: The greedy schedule (idea-442c94) achieved value 10 by scheduling start→one→two→three. This baseline shows the sequential approach is feasible. Testing the identical greedy order again as an independent verification confirms reproducibility and establishes whether the evaluation is deterministic.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```






## idea-f3f672: Selective two-job: start→three (skip one and two)
- **Priority**: high
- **Category**: schedule_optimization
- **Approach Family**: optimization
- **Parent**: idea-evaluate-0003-0001
- **Research Cycle**: 4
- **Hypothesis**: Current best single optional (idea-evaluate-0003-0001) is start→two with value 4. Job three has the highest individual value (4) and latest release (3) and deadline (4). Testing start→three skips the earlier optional jobs entirely. This explores whether the highest-value job at the constraint boundary outperforms intermediate selections, achieving value 5 while respecting the single-capacity constraint and disjoint window timing.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

