# Ideas






## idea-655a1f: Maximize window-respecting job selection: start, two, three
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-eedcc5
- **Research Cycle**: 3
- **Hypothesis**: The subset strategy (idea-c9d259, value=7) selected start, one, three; the lookahead variant (idea-eedcc5, value=8) selected start, two, three. Both skip job 'one'. Re-testing the start, two, three combination at its optimal schedule—job 'two' at time 2 (respecting release 2 and deadline 3) and job 'three' at time 3 (respecting release 3 and deadline 4)—may confirm whether this achieves the observed value of 8 or reveal a different ordering.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "two", "start": 2}, {"job_id":
        "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```



## idea-b5718b: Aggressive value-maximizing greedy: start, three, two, one
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: optimization
- **Parent**: idea-evaluate-0001-0000
- **Research Cycle**: 4
- **Hypothesis**: Current best schedules (idea-evaluate-0001-0000 with value 10, idea-evaluate-0002-0000 with value 8) follow sequential or partial orderings. A greedy approach prioritizing jobs by value-to-duration ratio while respecting release times and deadlines may exceed the current best. Job three (value=4, release=3, deadline=4) and two (value=3, release=2, deadline=3) have higher value than one (value=2, release=1, deadline=2). Scheduling start at 0, then attempting three at 3, two at 2, one at 1 respects all deadlines and prerequisites.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

