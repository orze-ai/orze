# Ideas






## idea-ea6e97: Combine early (value 7) and middle (value 8) for 15 total, excluding long
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0002-0001
- **Research Cycle**: 3
- **Hypothesis**: Current best (idea-evaluate-0002-0001) achieves value 19 with early + late + long. Testing whether early + middle can fit within mandatory deadlines and yield a competitive alternative. Early finishes by tick 6, middle by tick 7, leaving room for finish at tick 9. This tests if the 5-unit long job is necessary or if two shorter optionals yield comparable value.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "finish",
        "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-2c8166: Test early + late without long for value 16, maximizing window flexibility
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0002-0001
- **Research Cycle**: 3
- **Hypothesis**: Current best achieves 19 with early + late + long (early 3–4, late 7–8, long 3–7). Removing long frees capacity tick 3–7. Early+late yields 16, leaving ticks 5–6 open. This tests whether the mandatory finish constraint (release 9, duration 1) forces the schedule into a specific pattern or if removing long creates infeasibility despite lower total value.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "late", "start": 7}, {"job_id": "finish", "start":
        9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

