# Ideas




## idea-b5718b: Alternative job ordering: one, two, three after start
- **Priority**: medium
- **Category**: candidate_exploration
- **Approach Family**: other
- **Parent**: idea-442c94
- **Research Cycle**: 2
- **Hypothesis**: Both completed schedules (idea-442c94 and idea-a59517) achieved a score of 10, suggesting they may have found a local optimum or that the greedy orderings tested are equivalent. Testing an alternative permutation of optional jobs (one, two, three in that order) explores whether the evaluation metric or constraint satisfaction is sensitive to scheduling order. This candidate respects all mandatory (start at 0) and prerequisite dependencies while attempting a different greedy sequence.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "one", "start": 1}, {"job_id":
        "two", "start": 2}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```




## idea-519055: Greedy reverse-deadline scheduling with mandatory-first anchor
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: optimization
- **Parent**: idea-442c94
- **Research Cycle**: 3
- **Hypothesis**: Current best (idea-evaluate-0002-0001) scores 5 by scheduling only start + one optional job. Idea-evaluate-0001-0000 and idea-evaluate-0001-0001 both achieve score 10 by including all four jobs in feasible order. The greedy forward approach (idea-442c94) respects all constraints and achieves maximum value. This candidate reverses the optional job selection order to test if backward deadline prioritization combined with mandatory-first placement can maintain feasibility while exploring alternative orderings.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "three", "start": 3}, {"job_id":
        "two", "start": 2}, {"job_id": "one", "start": 1}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


## idea-f3f672: Minimal feasible subset: start plus highest-value optional job
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: optimization
- **Parent**: idea-evaluate-0002-0001
- **Research Cycle**: 3
- **Hypothesis**: Idea-evaluate-0002-0001 scores 5 by including only start and one. The observed score 10 cases (idea-evaluate-0001-0000 and idea-evaluate-0001-0001) include all jobs. This explores whether scheduling only the mandatory job 'start' at t=0 and the single highest-value optional job 'three' at its earliest feasible slot (t=3, respecting release window and start prerequisite) can be a valid alternative to multi-job schedules, testing robustness of minimal completions.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-disjoint-windows-v1", "schedule":
        [{"job_id": "start", "start": 0}, {"job_id": "three", "start": 3}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

