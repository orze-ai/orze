# Ideas




## idea-b8574d: Maximize long job (value=11) with tight scheduling
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0001-0001
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-0001-0001 achieved score=18 by including early(7) + middle(8) + finish(1). However, long(11) has higher unit value. Testing whether long can fit within deadline=9 if we start it immediately after gate at t=3, running until t=8, then finish at t=9. This trades the dual optional jobs for a single high-value job.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```






