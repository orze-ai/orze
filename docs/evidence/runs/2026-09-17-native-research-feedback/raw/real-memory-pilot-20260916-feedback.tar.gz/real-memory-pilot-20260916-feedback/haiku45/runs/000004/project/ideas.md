# Ideas




## idea-ee11c9: Prioritize early and middle jobs with compressed long job window
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: other
- **Parent**: idea-evaluate-0001-0000
- **Research Cycle**: 2
- **Hypothesis**: idea-evaluate-0001-0000 achieved score 27 with critical path (prepare → gate → early → middle → late → finish). idea-evaluate-0001-0001 failed with capacity overload when attempting long (5-duration job). This candidate schedules early (start 3, duration 2, value 7) and middle (start 5, duration 2, value 8) within their deadline windows, then late (start 7, value 9) before finish, avoiding the long job entirely. This prioritizes high-value short jobs over the risky 5-duration long job.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "middle", "start": 5}, {"job_id": "late", "start":
        7}, {"job_id": "finish", "start": 9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```






## idea-58c9de: Schedule long job without any optional jobs except finish
- **Priority**: high
- **Category**: scheduling_strategy
- **Approach Family**: other
- **Parent**: idea-evaluate-0002-0001
- **Research Cycle**: 4
- **Hypothesis**: idea-evaluate-0002-0001 (long only, no middle/early/late) scored 14 but is feasible. The greedy strategy of maximizing long (value=11) alone may be suboptimal. However, the tight deadline windows and single capacity severely limit parallelism. Attempt a middle-ground: include long and one high-value optional (middle, value=8) that fits cleanly after long without violating windows: prepare (0-2), gate (2-3), long (3-8), middle (8-10), finish (10-11). This respects all deadlines and prerequisites while testing if long + one optional beats long alone.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "long", "start": 3}, {"job_id": "middle", "start": 8}, {"job_id": "finish",
        "start": 10}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```

