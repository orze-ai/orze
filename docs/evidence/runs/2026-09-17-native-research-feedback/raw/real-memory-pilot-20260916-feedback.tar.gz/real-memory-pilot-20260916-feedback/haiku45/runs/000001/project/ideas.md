# Ideas








## idea-1ffa62: Scheduled long (11) + early (7) for total 18, placed early in window
- **Priority**: high
- **Category**: scheduling
- **Approach Family**: optimization
- **Parent**: idea-evaluate-0001-0001
- **Research Cycle**: 4
- **Hypothesis**: idea-evaluate-0001-0001 achieved value 27 by stacking early and long jobs back-to-back after gate. Attempt to replicate that high value by scheduling early (release 3, deadline 6, duration 2) immediately after gate completion at tick 3, then long (release 3, deadline 9, duration 5) from tick 5 to tick 9. This respects all mandatory job ordering and capacity constraints while capturing both optional high-value jobs before their deadlines.
- **Config overrides**:
  ```yaml
  kind: native_cpu_action
  domain_request:
    input_artifact_ids: []
    inputs: {}
    outputs:
      candidate:
        max_bytes: 16384
        path: candidate.json
    payload:
      artifact_utf8: '{"instance_id": "memory-pilot-window-tradeoff-v1", "schedule":
        [{"job_id": "prepare", "start": 0}, {"job_id": "gate", "start": 2}, {"job_id":
        "early", "start": 3}, {"job_id": "long", "start": 5}, {"job_id": "finish", "start":
        9}]}'
      candidate: baseline
      operation: produce
    purpose: produce scheduling candidate
    timeout_seconds: 2
    version: 1
  ```


