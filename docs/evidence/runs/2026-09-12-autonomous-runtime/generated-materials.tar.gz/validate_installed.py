"""Real installed Core CLI validation: uncapped accounting, finite application Stop, resumable Pause.
No pytest, mocks, Pro, providers, GPUs, or scientific speed comparison.
"""
from collections import Counter
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import runpy
import sqlite3
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
sys.path.insert(0, str(SOURCE))  # Application-only source tree: Core is under src/, not on sys.path.
import yaml
import orze
from orze.idea_lake import IdeaLake
from orze.engine.supervised_process import prepare_supervised, SupervisionUncertain
from orze.core import cpu_action_budget
from examples.acceptance import sorting, compression
from examples.acceptance.policy import CommonPolicy

TABLES = ("ideas", "idea_state", "idea_transitions", "execution_attempts", "research_artifacts",
          "research_observations", "cpu_action_reservations", "cpu_action_decisions",
          "cpu_action_scopes", "cpu_action_recovery", "cpu_proposal_requests", "replication_requests")
REF_FIELDS = ("task_id", "phase", "attempt_id", "generation")
INDEPENDENT = runpy.run_path(str(SOURCE / "docs/evidence/checks/v1-07a-runs-check.py"))
WORKER = """import json,os
from pathlib import Path
inputs=json.loads(os.pread(int(os.environ['ORZE_ACTION_INPUT_FD']),65536,0))
Path('answer.json').write_text(json.dumps({'ordinal':inputs['ordinal'],'sum':sum(range(11))}),encoding='utf-8')
"""

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def digest(value):
    return sha(canonical(value))

def save(path, value):
    with path.open("xb") as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2, allow_nan=False).encode() + b"\n")
        stream.flush()
        os.fsync(stream.fileno())
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}

def db_snapshot(project):
    conn = sqlite3.connect((project / "lake.db").as_uri() + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        names = {r[0] for r in conn.execute("SELECT name FROM main.sqlite_master WHERE type='table'")}
        return {name: [dict(r) for r in conn.execute("SELECT * FROM main." + name + " ORDER BY rowid")]
                if name in names else [] for name in TABLES}
    finally:
        conn.close()

def project(name, *, capped=False, domain=None, variant=None, pause=False):
    path = ROOT / "projects" / name
    path.mkdir()
    cfg = {"execution": {"version": 1 if capped else 2, "resource": "cpu", "slots": 1,
                         "wall_budget_seconds": 4 if capped else None},
           "results_dir": str(path / "results"), "idea_lake_db": str(path / "lake.db"),
           "ideas_file": str(path / "ideas.md"), "min_disk_gb": 0,
           "action_policy": {"version": 1, "kind": "queue", "idle": "stop", "wait_seconds": .05}}
    if domain:
        module = {"sorting": sorting, "compression": compression}[domain]
        dataset = getattr(module, "DEFAULT_DATASET" if variant == "default" else "COUNTERFACTUAL_DATASET")
        cfg["action_domain"] = {"version": 1, "kind": "acceptance_" + domain,
                                "config": {"dataset": copy.deepcopy(dataset)}}
        cfg["action_policy"].update(kind="acceptance", config={})
    if pause:
        cfg["action_policy"].update(kind="quiescent_queue_validation", idle="wait", config={})
    (path / "orze.yaml").write_text(yaml.safe_dump(cfg, sort_keys=True))
    return path, cfg

def enqueue(path, ordinal):
    task = "idea-queue-" + str(ordinal).zfill(3)
    action = {"version": 1, "adapter": "command", "purpose": "installed CPU queue validation",
              "inputs": {"ordinal": ordinal}, "command": [sys.executable, "-I", "-B", "-c", WORKER],
              "timeout_seconds": 2, "outputs": {"answer": {"path": "answer.json", "max_bytes": 128}}}
    lake = IdeaLake(path / "lake.db")
    try:
        result = lake.insert(task, "private CPU action " + str(ordinal),
            canonical({"kind": "native_cpu_action", "action": action}).decode(), "",
            status="queued", kind="native_cpu_action", if_absent=True)
        assert result["status"] == "inserted", result
    finally:
        lake.close()
    return result

def verify_raw(record, count, reason, *, pause=False):
    assert record["error"] is None and record["exit_code"] == 0
    tree = record["controller_closure"]
    assert tree["event"] == "TREE_CLOSED" and tree["wait_proof"] == "ECHILD_WALL"
    assert tree["binding"] == record["controller_binding"] and tree["worker_returncode"] == 0
    assert tree["forced_cleanup"] is False and tree["stop_requested"] is False
    db = record["database"]
    assert len(db["execution_attempts"]) == len(db["cpu_action_reservations"]) == count
    assert len(db["cpu_action_scopes"]) == 1
    scope = db["cpu_action_scopes"][0]
    decisions = [json.loads(row["record_json"]) for row in db["cpu_action_decisions"]]
    assert decisions[-1]["reason"] == reason
    if pause:
        assert scope["stop_json"] is None
        assert all(d["kind"] != "Stop" for d in decisions)
        assert decisions[-1]["kind"] == "Pause"
    else:
        stop = json.loads(scope["stop_json"])
        assert stop == {"kind": "Stop", "reason": reason, "wakeup": None}
        assert decisions[-1]["kind"] == "Stop"
    attempts = {row["task_id"]: row for row in db["execution_attempts"]}
    reservations = {row["task_id"]: row for row in db["cpu_action_reservations"]}
    ideas = {row["idea_id"]: row for row in db["ideas"]}
    assert len(attempts) == len(reservations) == count
    artifacts = {r["artifact_id"]: json.loads(r["record_json"]) for r in db["research_artifacts"]}
    observations = {r["observation_id"]: json.loads(r["record_json"]) for r in db["research_observations"]}
    for task, attempt in attempts.items():
        ref = {key: attempt[key] for key in REF_FIELDS}
        assert attempt["state"] == "TERMINAL" and attempt["hold_reason"] is None
        assert ideas[task]["status"] == "completed"
        binding = json.loads(attempt["binding_json"])
        terminal = json.loads(attempt["terminal_json"])
        assert binding["attempt_ref"] == ref
        assert terminal["outcome"] == "completed" and terminal["return_code"] == 0
        assert terminal["runtime_lease"]["status"] == "authorized"
        native = terminal["process_tree"]
        assert native["event"] == "TREE_CLOSED" and native["wait_proof"] == "ECHILD_WALL"
        assert native["schema"] == 2 and native["worker_returncode"] == 0
        assert native["lease_expired"] is False
        assert native["forced_cleanup"] is False and native["stop_requested"] is False
        assert native["binding"] == binding["supervision"]
        assert native["binding"]["identity"]["attempt_ref"] == ref
        r = reservations[task]
        permit = json.loads(r["permit_json"])
        assert r["state"] == "SETTLED" and json.loads(r["ref_json"]) == ref
        assert r["terminal_sha256"] == digest(terminal)
        assert r["reservation_id"] == binding["reservation_id"] == permit["reservation_id"]
        assert permit["task_id"] == task and permit["reserved_nanoseconds"] == "2000000000"
        assert permit["budget_scope"]["declaration"] == record["cfg"]["execution"]
        effect = record["effects"][task]
        prepared_raw = effect["prepared"].encode()
        committed = json.loads(effect["committed"])
        assert sha(prepared_raw) == terminal["effect_receipt_sha256"] == committed["prepared_sha256"]
        assert committed["event"] == "effect_committed"
        assert all(committed[key] == ref[key] for key in REF_FIELDS)
        assert effect["guard_absent"] is True
        actual_artifacts = {key for key, a in artifacts.items() if a["producer"] == ref}
        actual_observations = {key for key, o in observations.items() if o["evaluator"] == ref}
        assert set(terminal["artifact_ids"]) == actual_artifacts
        assert set(terminal["observation_ids"]) == actual_observations
        for identity in actual_artifacts:
            artifact = artifacts[identity]
            raw = record["artifact_bytes"][identity].encode()
            assert sha(raw) == artifact["content_sha256"] and len(raw) == artifact["size_bytes"]
            assert artifact["scope"] == record["cfg"]["results_dir"]
        for identity in actual_observations:
            obs = observations[identity]
            assert set(obs["result_artifact_ids"]) == actual_artifacts
    budget = record["budget_after"]
    assert budget["reserved_wall_seconds"] == 2 * count
    assert budget["active_reservations"] == 0 and budget["free_slots"] == 1
    assert budget["stopped"] is (not pause)
    if record["cfg"]["execution"]["version"] == 2:
        assert budget["remaining_wall_seconds"] is None
    else:
        assert budget["remaining_wall_seconds"] == 4 - 2 * count
    return {"native_actions_in_database": count, "cumulative_reserved_seconds": 2 * count,
            "remaining_wall_seconds": budget["remaining_wall_seconds"], "reason": reason,
            "scope_stopped": budget["stopped"], "all_terminal_and_settled": True}

def verify_domain(record, domain, variant):
    db, trace = record["database"], record["trace"]
    count = 5 if variant == "default" else 3
    assert len(trace) and trace[-1]["decision"] == {"kind": "Stop", "reason": "confirmed_selection", "wakeup": None}
    assert [t["decision"]["kind"] for t in trace] == ["Propose", "Execute"] * (count - 1) + ["Replicate", "Execute", "Stop"]
    policy = CommonPolicy(record["cfg"]["action_policy"])
    for entry in trace:
        assert digest(entry["snapshot"]) == entry["snapshot_sha256"]
        assert entry["budget"]["remaining_wall_seconds"] is None
        assert canonical(policy._decide(copy.deepcopy(entry["snapshot"]), copy.deepcopy(entry["budget"]))) == canonical(entry["decision"])
        assert record["started_monotonic"] <= entry["monotonic"] <= record["finished_monotonic"]
    final = trace[-1]["snapshot"]["recorded_evidence"]
    assert final["unavailable"] == [] and final["more_available"] is False
    results = {r["ref"]["task_id"]: r for r in final["results"]}
    assert len(results) == count
    artifact_records = {r["artifact_id"]: json.loads(r["record_json"]) for r in db["research_artifacts"]}
    observation_records = {r["observation_id"]: json.loads(r["record_json"]) for r in db["research_observations"]}
    dataset = record["cfg"]["action_domain"]["config"]["dataset"]
    envelopes, observed = {}, {}
    for task, result in results.items():
        assert len(result["artifact_records"]) == len(result["observation_records"]) == 1
        artifact, obs = result["artifact_records"][0], result["observation_records"][0]
        assert artifact_records[artifact["artifact_id"]] == artifact
        assert observation_records[obs["observation_id"]] == obs
        assert artifact["producer"] == obs["evaluator"] == result["ref"]
        envelope = json.loads(record["artifact_bytes"][artifact["artifact_id"]])
        assert envelope["dataset_sha256"] == digest(dataset)
        assert obs["values"] == {k: envelope[k] for k in
            ("cost", "candidate", "operation", "dataset_sha256", "worker_cpu_seconds", "worker_wall_seconds")}
        valid = INDEPENDENT["domain_result"](domain, dataset, envelope)
        status = obs["validation"]["status"]
        assert status == ("unknown" if envelope["candidate"] == "unchecked" and envelope["operation"] == "measure"
                          else "valid" if valid else "invalid")
        envelopes[task], observed[task] = envelope, obs
    assert observed["idea-baseline"]["validation"]["status"] == "valid"
    assert observed["idea-challenger"]["validation"]["status"] == ("invalid" if variant == "default" else "valid")
    requests = [json.loads(r["record_json"]) for r in db["replication_requests"]]
    assert len(requests) == 1
    request = requests[0]
    selected = "idea-baseline" if variant == "default" else "idea-challenger"
    assert request["source_ref"] == results[selected]["ref"]
    replica = request["task_id"]
    assert results[replica]["ref"] != results[selected]["ref"]
    for key in ("values", "comparison_scope", "protocol_fingerprint", "validation"):
        left, right = observed[replica][key], observed[selected][key]
        if key == "values":  # New worker timings are not expected to be identical.
            left = {k: v for k, v in left.items() if not k.startswith("worker_")}
            right = {k: v for k, v in right.items() if not k.startswith("worker_")}
        assert left == right
    if variant == "default":
        assert observed["idea-unchecked"]["validation"]["status"] == "unknown"
        assert observed["idea-analysis"]["validation"]["status"] == "valid"
        assert observed["idea-analysis"]["values"]["cost"] > observed["idea-baseline"]["values"]["cost"]
        analysis = envelopes["idea-analysis"]
        ids = [results["idea-" + c]["artifact_records"][0]["artifact_id"] for c in ("baseline", "challenger", "unchecked")]
        assert analysis["source_artifact_ids"] == ids
        assert {c["artifact_id"] for c in analysis["details"]["source_checks"]} == set(ids)
        for check in analysis["details"]["source_checks"]:
            raw = json.loads(record["artifact_bytes"][check["artifact_id"]])
            truth = INDEPENDENT["domain_result"](domain, dataset, raw)
            assert check["cost"] == raw["cost"] and check["candidate"] == raw["candidate"]
            assert (check["valid"] if domain == "sorting" else check["status"] == "valid") is truth
        proposal = next(t["decision"] for t in trace if t["decision"]["kind"] == "Propose"
                        and t["decision"]["task_id"] == "idea-analysis")
        assert proposal["domain_request"]["input_artifact_ids"] == ids
    return {"domain": domain, "variant": variant, "selected_candidate": observed[selected]["values"]["candidate"],
            "cost": observed[selected]["values"]["cost"], "recorded_status_counts":
            dict(Counter(o["validation"]["status"] for o in observed.values())),
            "policy_trace_replayed": True, "source_bound_analysis": variant == "default",
            "independent_finite_dataset_result_checks": True, "actual_distinct_replica": True,
            "not_general_scientific_optimization": True}

def invoke(path, cfg, ordinal, count, reason, *, domain=None, variant=None, pause=False, guardian=45):
    invocation = path / ("invocation-" + str(ordinal))
    invocation.mkdir()
    if domain:
        bootstrap = "import sys;sys.path.insert(0," + repr(str(SOURCE)) + ");from examples.acceptance.__main__ import main;raise SystemExit(main())"
    elif pause:
        bootstrap = "import runpy;runpy.run_path(" + repr(str(ROOT / "pause_app.py")) + ",run_name='__main__')"
    else:
        bootstrap = "from orze.cli import main;raise SystemExit(main())"
    argv = [sys.executable, "-I", "-B", "-c", bootstrap, "-c", str(path / "orze.yaml")]
    env = {"PATH": str(Path(sys.executable).parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8",
           "CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}
    record = {"project": str(path), "cfg": cfg, "argv": argv, "cwd": str(path),
              "exit_code": None, "error": None, "guardian_seconds": guardian,
              "guardian_is_fault_safety_not_research_budget": True,
              "started_monotonic": time.monotonic()}
    proc = None
    with (invocation / "stdout.log").open("wb") as out, (invocation / "stderr.log").open("wb") as err:
        try:
            try:
                proc = prepare_supervised(argv, identity={"scope": str(path), "installed_validation": ordinal},
                    cwd=str(path), env=env, stdout=out, stderr=err)
            except SupervisionUncertain as exc:
                proc = exc.process
                raise
            record["controller_binding"] = proc.binding
            save(invocation / "controller-ready.json", proc.binding)
            proc.start()
            record["exit_code"] = proc.wait(timeout=guardian)
            record["controller_closure"] = proc.closure_receipt()
        except BaseException:
            record["error"] = traceback.format_exc()
            if proc is not None:
                try:
                    proc.stop(timeout=10)
                    record["controller_closure"] = proc.closure_receipt()
                except BaseException:
                    record["cleanup_error"] = traceback.format_exc()
    record["finished_monotonic"] = time.monotonic()
    record["wall_seconds"] = record["finished_monotonic"] - record["started_monotonic"]
    record["stdout"] = (invocation / "stdout.log").read_text(errors="replace")
    record["stderr"] = (invocation / "stderr.log").read_text(errors="replace")
    try:
        record["database"] = db_snapshot(path)
        record["artifact_bytes"] = {}
        record["effects"] = {}
        for row in record["database"]["research_artifacts"]:
            artifact = json.loads(row["record_json"])
            artifact_path = Path(artifact["path"])
            assert artifact_path.is_relative_to(path) and not artifact_path.is_symlink()
            record["artifact_bytes"][artifact["artifact_id"]] = artifact_path.read_text()
        for row in record["database"]["execution_attempts"]:
            folder = path / "results" / row["task_id"]
            effect = folder / "_execution_effects" / row["attempt_id"]
            record["effects"][row["task_id"]] = {name: (effect / (name + ".json")).read_text()
                                               for name in ("prepared", "committed")}
            record["effects"][row["task_id"]]["guard_absent"] = not (folder / "_attempt_effect.lock").exists()
        scope = json.loads(record["database"]["cpu_action_scopes"][0]["binding_json"])
        lake = IdeaLake(path / "lake.db")
        try:
            record["budget_after"] = cpu_action_budget.snapshot(lake, scope)
        finally:
            lake.close()
        marker = "ACCEPTANCE_DECISION=" if domain else "PAUSE_DECISION="
        record["trace"] = [json.loads(line[len(marker):]) for line in record["stdout"].splitlines() if line.startswith(marker)]
        record["qualification"] = verify_raw(record, count, reason, pause=pause)
        if domain:
            record["domain_qualification"] = verify_domain(record, domain, variant)
        else:
            for row in record["database"]["research_artifacts"]:
                a = json.loads(row["record_json"])
                answer = json.loads(record["artifact_bytes"][a["artifact_id"]])
                assert answer == {"ordinal": int(a["producer"]["task_id"].split("-")[-1]), "sum": 55}
            assert record["database"]["research_observations"] == []
        if pause:
            assert [t["decision"]["kind"] for t in record["trace"]] == ["Execute", "Pause"]
            assert all(t["budget"]["remaining_wall_seconds"] is None for t in record["trace"])
            assert record["trace"][-1]["snapshot"]["active"] is False
            assert record["trace"][-1]["budget"]["active_reservations"] == 0
        record["passed"] = True
    except BaseException:
        record["passed"] = False
        record["qualification_error"] = traceback.format_exc()
    pointer = save(invocation / "run.json", record)
    print("INSTALLED_VALIDATION=" + json.dumps({"project": path.name, "invocation": ordinal,
          "passed": record["passed"], "exit_code": record["exit_code"],
          "qualification": record.get("qualification"), "report": pointer}), flush=True)
    if not record["passed"]:
        raise RuntimeError("full failed attempt retained: " + str(invocation / "run.json"))
    return record, pointer

def main():
    assert not sys.flags.optimize
    assert sys.prefix == str(ROOT / "core-only-venv")
    assert Path(orze.__file__).is_relative_to(Path(sys.prefix))
    assert importlib.util.find_spec("orze_pro") is None
    installed = json.loads((ROOT / "installation-final/review.json").read_bytes())
    assert installed["status"] == "passed"
    package_root = Path(orze.__file__).parent.parent
    before = {n: sha((package_root / n).read_bytes()) for n in installed["package_files"]}
    assert before == installed["package_files"]
    apps_before = {n: sha((SOURCE / n).read_bytes()) for n in installed["application_files"]}
    assert apps_before == installed["application_files"]
    (ROOT / "projects").mkdir()
    records, pointers = [], []
    report = {"scope": "isolated installed CPU validation, not a speed comparison or production deployment",
              "core_commit": installed["commit"], "wheel": installed["wheel"],
              "wheel_sha256": installed["wheel_sha256"], "python": sys.executable,
              "pro_present": False, "license_read_or_patched": False, "research_total_deadline": None,
              "individual_action_wall_envelope_seconds": 2,
              "original_formal_and_environment_untouched": True}
    try:
        path, cfg = project("queue-v2-40")
        admissions = [enqueue(path, i) for i in range(40)]
        save(path / "admissions.json", admissions)
        record, pointer = invoke(path, cfg, 1, 40, "queue_drained", guardian=180)
        records.append(record); pointers.append(pointer)
        assert len(record["database"]["ideas"]) == 40
        path, cfg = project("queue-v1-control", capped=True)
        save(path / "admissions.json", [enqueue(path, i) for i in range(3)])
        record, pointer = invoke(path, cfg, 1, 2, "wall_envelope_exhausted")
        records.append(record); pointers.append(pointer)
        assert Counter(r["status"] for r in record["database"]["ideas"]) == {"completed": 2, "queued": 1}
        for domain in ("sorting", "compression"):
            for variant in ("default", "counterfactual"):
                path, cfg = project(domain + "-" + variant, domain=domain, variant=variant)
                record, pointer = invoke(path, cfg, 1, 5 if variant == "default" else 3,
                                          "confirmed_selection", domain=domain, variant=variant)
                records.append(record); pointers.append(pointer)
        path, cfg = project("pause-same-scope", pause=True)
        config_raw = (path / "orze.yaml").read_bytes()
        save(path / "admission-1.json", enqueue(path, 1))
        first, pointer = invoke(path, cfg, 1, 1, "quiescent_queue", pause=True)
        records.append(first); pointers.append(pointer)
        first_scope = first["database"]["cpu_action_scopes"][0]
        save(path / "admission-2.json", enqueue(path, 2))
        second, pointer = invoke(path, cfg, 2, 2, "quiescent_queue", pause=True)
        records.append(second); pointers.append(pointer)
        assert (path / "orze.yaml").read_bytes() == config_raw
        assert second["database"]["cpu_action_scopes"][0] == first_scope
        assert first_scope["stop_json"] is None
        assert second["database"]["cpu_action_reservations"][0] == first["database"]["cpu_action_reservations"][0]
        assert second["database"]["execution_attempts"][0] == first["database"]["execution_attempts"][0]
        decisions = [json.loads(r["record_json"]) for r in second["database"]["cpu_action_decisions"]]
        assert [d["kind"] for d in decisions] == ["Pause", "Pause"]
        assert second["budget_after"]["reserved_wall_seconds"] == 4
        # Pause's second snapshot contains cumulative history; don't double-count its first action.
        actual_native = sum(r["qualification"]["native_actions_in_database"] for r in records) - 1
        assert len(records) == 8 and actual_native == 60
        report.update(passed=True, actual_cli_invocations=8, actual_native_actions=actual_native,
            normal_reasons=dict(Counter(r["qualification"]["reason"] for r in records)),
            all_actual_controller_trees_closed=True, all_actual_actions_terminal_and_settled=True,
            queue_drained_is_not_scientific_convergence=True,
            common_policy_is_fixed_finite_application_not_universal_optimizer=True,
            same_scope_pause={"same_config_bytes": True, "same_scope_binding_and_database": True,
                "first_reservation_and_attempt_unchanged": True, "fresh_cli_invocations": 2,
                "cumulative_charge_seconds": 4, "settled": 2, "stop_json_always_null": True},
            domain_results=[r["domain_qualification"] for r in records if "domain_qualification" in r])
    except BaseException:
        report.update(passed=False, traceback=traceback.format_exc())
        raise
    finally:
        after = {n: sha((package_root / n).read_bytes()) for n in installed["package_files"]}
        apps_after = {n: sha((SOURCE / n).read_bytes()) for n in installed["application_files"]}
        report.update(runs=pointers, package_before=before, package_after=after,
            package_bytes_unchanged=before == after, application_before=apps_before, application_after=apps_after,
            application_bytes_unchanged=apps_before == apps_after,
            dependency_versions={d.metadata["Name"]: d.version for d in importlib.metadata.distributions()},
            script_hashes={p.name: sha(p.read_bytes()) for p in ROOT.glob("*.py")})
        pointer = save(ROOT / "validation-report.json", report)
        print("VALIDATION_REPORT=" + json.dumps(pointer), flush=True)
    assert before == after and apps_before == apps_after

if __name__ == "__main__":
    main()

