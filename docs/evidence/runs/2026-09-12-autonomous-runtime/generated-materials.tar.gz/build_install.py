"""Build one fixed commit and install only Core in a fresh offline venv."""
import argparse
import email
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path("/hot-data/fsx/workspace/erik/orze-production-validation-2026-09-12.UgS3uV/orze")
OLD = Path("/hot-data/fsx/workspace/erik/orze-release-candidate-6BUecCLP")

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--commit", required=True)
    args = parser.parse_args()
    if not re.fullmatch("[0-9a-f]{40}", args.commit):
        raise ValueError("an explicit full fixed Core commit is required")
    out = ROOT / "installation"
    out.mkdir()
    logs = out / "logs"
    logs.mkdir()
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    commands = []
    report = {"commit": args.commit, "root": str(ROOT), "status": "in_progress",
              "original_release": str(OLD), "offline_only": True,
              "original_environments_untouched": True, "production_switched": False,
              "pro_installed": False, "license_read_or_patched": False,
              "build_tools": {n: importlib.metadata.version(n) for n in ("build", "setuptools", "wheel")}}
    def run(label, argv, cwd=ROOT):
        begin = time.monotonic()
        proc = subprocess.run(list(map(str, argv)), cwd=cwd, env=env, capture_output=True, timeout=600)
        item = {"label": label, "argv": list(map(str, argv)), "cwd": str(cwd),
                "exit_code": proc.returncode, "wall_seconds": time.monotonic() - begin}
        for key, raw in (("stdout", proc.stdout), ("stderr", proc.stderr)):
            path = logs / (label + "." + key)
            path.write_bytes(raw)
            item[key] = {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}
        commands.append(item)
        save(out / "commands.json", commands)
        print(json.dumps({"label": label, "exit_code": proc.returncode}), flush=True)
        if proc.returncode:
            raise RuntimeError("command failed; see raw logs: " + label)
        return proc
    try:
        actual = run("fixed-commit", ["git", "-C", REPO, "rev-parse", args.commit + "^{commit}"]).stdout.decode().strip()
        assert actual == args.commit
        source = ROOT / "source"
        source.mkdir()
        archive = ROOT / "source.tar"
        run("git-archive", ["git", "-C", REPO, "archive", "--format=tar", "--output=" + str(archive), args.commit])
        with tarfile.open(archive) as tar:
            assert all(not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in tar.getmembers())
            payload = {m.name[4:]: tar.extractfile(m).read() for m in tar.getmembers()
                       if m.isfile() and m.name.startswith("src/orze/")}
        run("extract", ["tar", "-xf", archive, "-C", source])
        wheels = ROOT / "wheelhouse"
        wheels.mkdir()
        run("build-wheel", [sys.executable, "-m", "build", "--wheel", "--no-isolation", "--outdir", wheels, source])
        wheel, = wheels.glob("orze-*.whl")
        with zipfile.ZipFile(wheel) as z:
            members = {n: z.read(n) for n in z.namelist() if n.startswith("orze/") and not n.endswith("/")}
            assert members.keys() == payload.keys(), (members.keys() - payload.keys(), payload.keys() - members.keys())
            assert all(members[n] == payload[n] for n in members)
            assert "orze/SKILL.md" in members
            metadata, = [n for n in z.namelist() if n.endswith(".dist-info/METADATA")]
            message = email.message_from_bytes(z.read(metadata))
            version = message["Version"]
        old_lock = (OLD / "core-only.lock").read_text()
        assert sha((OLD / "core-only.lock").read_bytes()) == "9e9434ce726dd618e72c562dff1ca112899cee8bdeb853894569dfe0d63be96e"
        replacement = "orze==" + version + " --hash=sha256:" + sha(wheel.read_bytes())
        new_lock, changed = re.subn(r"^orze==[^\n]+$", replacement, old_lock, flags=re.MULTILINE)
        assert changed == 1
        lock = out / "core-only.lock"
        lock.write_text(new_lock)
        dependencies = json.loads((OLD / "dependency-lock.json").read_bytes())
        new_dependencies = []
        for dep in dependencies:
            if dep["name"] == "orze-pro":
                continue
            if dep["name"] == "orze":
                new_dependencies.append({**dep, "version": version, "sha256": sha(wheel.read_bytes()),
                                         "source_url": wheel.as_uri(), "source_commit": args.commit})
                continue
            matching = [p for p in (OLD / "wheelhouse").glob("*.whl") if sha(p.read_bytes()) == dep["sha256"]]
            assert len(matching) == 1
            shutil.copyfile(matching[0], wheels / matching[0].name)
            new_dependencies.append({**dep, "offline_wheel": str(wheels / matching[0].name)})
        save(out / "dependency-lock.json", new_dependencies)
        target = ROOT / "core-only-venv"
        run("create-venv", [sys.executable, "-I", "-B", "-m", "venv", "--without-pip", target])
        python = target / "bin/python"
        bootstrap, = (OLD / "bootstrap").glob("pip-*.whl")
        loader = "import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_module('pip',run_name='__main__')"
        run("bootstrap-pip", [python, "-I", "-B", "-c", loader, bootstrap, "--isolated",
            "--disable-pip-version-check", "--no-input", "install", "--no-index", bootstrap,
            "--report", out / "bootstrap-install.json"])
        pip = [python, "-I", "-B", "-m", "pip", "--isolated", "--disable-pip-version-check", "--no-input"]
        run("install-offline", pip + ["install", "--no-index", "--find-links", wheels, "--require-hashes",
            "-r", lock, "--report", out / "installed.json"])
        run("pip-check", pip + ["check"])
        run("pip-freeze", pip + ["freeze", "--all"])
        run("cli-help", [python, "-I", "-B", "-m", "orze.cli", "--help"])
        sites, = (target / "lib").glob("python*/site-packages")
        assert not (sites / "orze_pro").exists()
        for name, raw in members.items():
            assert (sites / name).read_bytes() == raw, name
        report.update(status="passed", wheel=str(wheel), wheel_sha256=sha(wheel.read_bytes()),
            wheel_bytes=wheel.stat().st_size, version=version, venv=str(target),
            source_archive_sha256=sha(archive.read_bytes()), source_archive_bytes=archive.stat().st_size,
            source_package_files=len(payload), python_files=sum(n.endswith(".py") for n in payload),
            resource_files=sum(not n.endswith(".py") for n in payload),
            package_files={n: sha(raw) for n, raw in sorted(payload.items())},
            application_files={str(p.relative_to(source)): sha(p.read_bytes())
                for p in sorted((source / "examples/acceptance").glob("*.py"))},
            dependency_lock_sha256=sha((out / "dependency-lock.json").read_bytes()),
            core_only_lock_sha256=sha(lock.read_bytes()),
            bootstrap_wheel={"path": str(bootstrap), "sha256": sha(bootstrap.read_bytes())},
            no_network_dependency_resolution=True)
    except BaseException:
        report.update(status="failed", traceback=traceback.format_exc())
        raise
    finally:
        report["commands"] = commands
        save(out / "review.json", report)
        print("INSTALLATION_REPORT=" + str(out / "review.json"), flush=True)

if __name__ == "__main__":
    main()

