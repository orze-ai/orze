"""Read-only package/current-DB/raw-report verification. No worker or product import."""
import ast
import hashlib
import json
from pathlib import Path
import sqlite3
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = Path("/hot-data/fsx/workspace/erik/orze-release-candidate-6BUecCLP")
FORMAL = Path("/hot-data/fsx/workspace/erik/orze-production-validation-2026-09-12.UgS3uV/formal-01")

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def main():
    review = load(ROOT / "installation-final/review.json")
    validation = load(ROOT / "validation-report.json")
    assert review["status"] == "passed" and validation["passed"] is True
    assert review["commit"] == "6007f6efe49964f14317cd620f0b177615c35da8"
    archive = ROOT / "source.tar"
    with tarfile.open(archive) as tar:
        blobs = {m.name: tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    pyproject = blobs["pyproject.toml"].decode().split("[tool.setuptools.package-data]", 1)[1].split("\n[", 1)[0]
    declared = ast.literal_eval(pyproject.split("=", 1)[1].strip())
    assert declared == review["package_data_patterns"]
    expected = {n[4:] for n in blobs if n.startswith("src/orze/") and n.endswith(".py")}
    expected |= {str(p.relative_to(ROOT / "source/src")) for pattern in declared
                 for p in (ROOT / "source/src/orze").glob(pattern) if p.is_file()}
    wheel = Path(review["wheel"])
    assert sha(wheel.read_bytes()) == review["wheel_sha256"] == validation["wheel_sha256"]
    sites, = (ROOT / "core-only-venv/lib").glob("python*/site-packages")
    with zipfile.ZipFile(wheel) as z:
        payload = {n: z.read(n) for n in z.namelist() if n.startswith("orze/") and not n.endswith("/")}
        assert set(payload) == expected
        for n, raw in payload.items():
            assert raw == blobs["src/" + n] == (sites / n).read_bytes()
            assert sha(raw) == review["package_files"][n]
    assert validation["package_before"] == validation["package_after"] == review["package_files"]
    assert not (sites / "orze_pro").exists()
    assert "orze-pro" not in validation["dependency_versions"]
    deps = load(ROOT / "installation-final/dependency-lock.json")
    old_deps = {d["name"]: d for d in load(OLD / "dependency-lock.json") if d["name"] not in ("orze", "orze-pro")}
    assert {d["name"] for d in deps} == set(old_deps) | {"orze"}
    for d in deps:
        assert validation["dependency_versions"][d["name"]] == d["version"]
        if d["name"] != "orze":
            assert all(d[key] == old_deps[d["name"]][key] for key in ("version", "sha256", "source_url"))
            assert sha(Path(d["offline_wheel"]).read_bytes()) == d["sha256"]
    old_lines = (OLD / "core-only.lock").read_text().splitlines()
    new_lines = (ROOT / "installation-final/core-only.lock").read_text().splitlines()
    assert [s for s in old_lines if not s.startswith("orze==")] == [s for s in new_lines if not s.startswith("orze==")]
    for n, value in validation["application_before"].items():
        assert sha((ROOT / "source" / n).read_bytes()) == value == validation["application_after"][n]
        assert (ROOT / "source" / n).read_bytes() == blobs[n]
    records, last, refs, controllers = [], {}, set(), set()
    for pointer in validation["runs"]:
        path = Path(pointer["path"]); raw = path.read_bytes()
        assert sha(raw) == pointer["sha256"] and len(raw) == pointer["bytes"]
        record = json.loads(raw)
        assert record["passed"] is True and record["exit_code"] == 0 and record["error"] is None
        for log in ("stdout", "stderr"):
            assert (path.parent / (log + ".log")).read_text() == record[log]
        binding = record["controller_binding"]
        controllers.add((binding["supervisor"]["pid"], binding["supervisor"]["start_ticks"], binding["nonce_sha256"]))
        assert record["controller_closure"]["binding"] == binding
        assert record["controller_closure"]["event"] == "TREE_CLOSED"
        records.append(record); last[record["project"]] = record
    assert len(records) == len(controllers) == 8
    for project, record in last.items():
        root = Path(project)
        conn = sqlite3.connect((root / "lake.db").as_uri() + "?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            names = {r[0] for r in conn.execute("SELECT name FROM main.sqlite_master WHERE type='table'")}
            for table, rows in record["database"].items():
                actual = [dict(r) for r in conn.execute("SELECT * FROM main." + table + " ORDER BY rowid")] if table in names else []
                assert actual == rows, (project, table)
        finally:
            conn.close()
        for row in record["database"]["execution_attempts"]:
            ref = tuple(row[k] for k in ("task_id", "phase", "attempt_id", "generation"))
            assert ref not in refs
            refs.add(ref)
            assert row["state"] == "TERMINAL"
        for row in record["database"]["cpu_action_reservations"]:
            assert row["state"] == "SETTLED"
        for row in record["database"]["research_artifacts"]:
            artifact = json.loads(row["record_json"])
            raw = Path(artifact["path"]).read_bytes()
            assert raw == record["artifact_bytes"][artifact["artifact_id"]].encode()
            assert sha(raw) == artifact["content_sha256"]
        for task, evidence in record["effects"].items():
            folder = root / "results" / task
            attempt, = [a for a in record["database"]["execution_attempts"] if a["task_id"] == task]
            for name in ("prepared", "committed"):
                assert (folder / "_execution_effects" / attempt["attempt_id"] / (name + ".json")).read_bytes() == evidence[name].encode()
            assert not (folder / "_attempt_effect.lock").exists()
    assert len(refs) == 60
    original_files = {
        OLD / "core-only.lock": "9e9434ce726dd618e72c562dff1ca112899cee8bdeb853894569dfe0d63be96e",
        OLD / "wheelhouse/orze-4.6.2-py3-none-any.whl": "8c2cbb4f3def9a22ecfb4990c2675a9c2f84ee0550c54aad2ccee9075bf8cc4c",
        FORMAL / "manifest.json": "b0a165ab2311deeb51ba4fd9c7b7200706683c495c0b3a55178e8d87f968c819",
        FORMAL / "summary.json": "4c586c565501fe45766c71ae827c44d121f4732adc9840660689fb071ac3e72e"}
    for path, expected in original_files.items():
        assert sha(path.read_bytes()) == expected
    with zipfile.ZipFile(OLD / "wheelhouse/orze-4.6.2-py3-none-any.whl") as z:
        old_sites, = (OLD / "core-only-venv/lib").glob("python*/site-packages")
        original_core_members = [n for n in z.namelist() if n.startswith("orze/") and not n.endswith("/")]
        assert len(original_core_members) == 251
        for n in original_core_members:
            assert (old_sites / n).read_bytes() == z.read(n)
    result = {"passed": True, "scope": "read-only after-run package/DB/artifact/receipt/log validation; no new CLI or worker",
        "core_commit": review["commit"], "wheel_sha256": review["wheel_sha256"],
        "wheel_git_installed_exact_members": len(payload), "python_files": sum(n.endswith(".py") for n in payload),
        "declared_resources": sum(not n.endswith(".py") for n in payload),
        "exact_dependency_wheels_reused": len(old_deps),
        "raw_reports": 8, "actual_distinct_controller_bindings": len(controllers),
        "latest_private_databases": len(last), "distinct_terminal_refs": len(refs),
        "all_current_relevant_database_rows_equal_final_raw_reports": True,
        "all_artifact_and_effect_receipt_bytes_equal_reports": True,
        "original_core_environment_package_members_exact": len(original_core_members),
        "original_selected_evidence_unchanged": {str(p): s for p, s in original_files.items()},
        "validation_report_sha256": sha((ROOT / "validation-report.json").read_bytes()),
        "installation_report_sha256": sha((ROOT / "installation-final/review.json").read_bytes()),
        "limitations": ["Not a production target switch or Pro authorization validation.",
            "Kernel closure evidence is the real captured supervisor receipt, not host PID scanning.",
            "Queue drained is not convergence; CommonPolicy uses fixed finite candidate sets.",
            "Not a repeat of the 48-run efficiency comparison and no general research speed claim.",
            "Original environment check covers Core package payload, not every environment metadata byte."]}
    out = ROOT / "independent-verification.json"
    with out.open("x") as f:
        f.write(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({**result, "report": str(out), "report_sha256": sha(out.read_bytes())}, sort_keys=True))

if __name__ == "__main__":
    main()

