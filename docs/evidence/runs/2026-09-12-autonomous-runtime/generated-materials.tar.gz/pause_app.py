"""A registered generic quiescent-queue policy; no scientific convergence claim."""
import copy
import hashlib
import json
import time

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

class QuiescentQueue:
    def __init__(self, declaration):
        if declaration.get("config") != {}:
            raise ValueError("this validation policy accepts no extra configuration")
        self.declaration = copy.deepcopy(declaration)

    def decide(self, snapshot, budget):
        if budget["stopped"]:
            raise ValueError("a previously stopped scope is not a resumable Pause")
        if snapshot["queue"] and budget["free_slots"] > 0:
            decision = {"kind": "Execute", "task_id": snapshot["queue"][0]["idea_id"]}
        elif snapshot["active"] or budget["active_reservations"] != 0:
            decision = {"kind": "Wait", "reason": "actual_work_active",
                        "wakeup": snapshot["now"] + self.declaration["wait_seconds"]}
        else:
            decision = {"kind": "Pause", "reason": "quiescent_queue", "wakeup": None}
        print("PAUSE_DECISION=" + canonical({"schema": 1, "monotonic": time.monotonic(),
              "snapshot": snapshot, "snapshot_sha256": hashlib.sha256(canonical(snapshot)).hexdigest(),
              "budget": budget, "decision": decision}).decode(), flush=True)
        return decision

def main():
    from orze.core.research_interfaces import register_policy
    import orze.cli
    register_policy("quiescent_queue_validation", "validation.quiescent_queue.v1", QuiescentQueue)
    return orze.cli.main()

if __name__ == "__main__":
    raise SystemExit(main())

